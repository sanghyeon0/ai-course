# RoomFit 3.1 · AR 가구 배치 개선판

**기반:** RoomFit 3.0 Android Studio 소스. 기존 2D/3D 수동 도면 편집은 기본 흐름에서 제외되어 있습니다.

## 주요 기능

1. 생활패턴 및 예산별 가구 조합 추천: 기존 `roomfit3.html` / `roomfit3.js` 유지 (60개 카탈로그).
2. AR 가구 위치 이동: 가구 선택 후 바닥을 터치해 위치 변경하거나 화면 하단에서 5cm 단위 이동.
3. AR 가구 회전: 15도 단위 회전. 이동·회전 시 다른 가구 점유면적, 관찰된 바닥 면적, 지원 기기의 Depth 검사 재실행.
4. 크기 표시: 선택한 가구의 등록 가로×깊이×높이를 cm로 표시하고 AR 바닥에 점유 면적 테두리를 렌더링.
5. 방 스캔 안내: 관찰 방향 수(8방향 구간), 바닥 감지 횟수, 유효 깊이 샘플 횟수 및 안내 메시지. **방 전체 스캔 완료율이 아님**.
6. 빈 위치 추천: `빈 위치 찾기` 버튼을 누르면 보이는 화면의 여러 바닥 후보를 순차 검사. 바닥 네 모서리, 다른 AR 가구 충돌, Depth 검사 모두 통과한 경우 녹색 윤곽선을 표시. 사용자가 `추천 위치에 배치`를 눌러 확정해야 함. 자동으로 방 전체를 측정하지는 않음.
7. 기존 Depth 경고, 촬영 후 결과 화면, 사진 저장/공유를 유지합니다.

## 구현 파일

- `app/src/main/java/kr/ac/roomfit/app/LockedArActivity.java`: AR UI, 이동/회전 후 검증, 스캔 안내, 추천 후보, 촬영 결과
- `app/src/main/java/kr/ac/roomfit/app/RoomScanGuide.java`: 방향/바닥/Depth 샘플 기반 안내
- `app/src/main/java/kr/ac/roomfit/app/EmptySpaceCandidates.java`: 화면의 후보 검사 좌표
- `app/src/main/java/kr/ac/roomfit/app/DepthPlacementChecker.java`: ARCore Depth 검사 및 샘플 가용성 확인
- `app/src/main/assets/web/roomfit3.html`, `roomfit3.js`: 생활패턴/예산/AR/결과 흐름

## 실행

1. Android Studio에서 ZIP 압축 해제 후 프로젝트 루트(`settings.gradle` 존재)를 열기.
2. Android SDK Platform 35, Java 17, Gradle 8.9, AR 서비스가 설치된 지원 휴대폰을 준비.
3. `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`; 이 프로젝트에는 `gradlew`만 있을 수 있음).
4. 빌드가 성공하면 `app/build/outputs/apk/debug/app-debug.apk`를 휴대폰에 설치.
5. 1단계 생활패턴 → 2단계 예산과 가구 → 3단계 AR → 4단계 촬영 결과 저장.

## 검사 및 제약

- 표준 JVM 테스트: `javac -d /tmp/rf31test app/src/main/java/kr/ac/roomfit/app/{ObstacleMath,RoomScanGuide,EmptySpaceCandidates}.java tools/RoomFit31LogicTest.java` 후 `java -cp /tmp/rf31test RoomFit31LogicTest`.
- 현재 작업 환경에는 Android SDK·Gradle·실기기가 없어 **Android Java 코드 컴파일, 설치, ARCore Depth 실측, 촬영/공유 실기기 검증은 완료하지 못했습니다**.
- Depth는 화면에 보이는 표면에 대한 추정이며 빈 공간이 안전하다는 보증이 아닙니다. 카메라가 가려진 공간, 얇은 물체, 유리, 조명 불량, 출입문·보행 통로는 놓칠 수 있습니다.
- 60개 모델 중 54개 가격은 **시연용 가상 가격**이고, 46개 이상의 모델은 사실적인 판매상품과 다를 수 있습니다. 치수는 모델 등록값으로 실제 판매 규격과 다를 수 있습니다.
- ARCore Depth 미지원 단말에서는 빈 위치 탐색 버튼은 작동하지 않으며 일반 AR 미리보기는 사용할 수 있습니다.
- 빈 공간 후보는 화면에 관측된 위치 중 검사에 통과한 한 점이며, 최적 위치를 보장하지 않습니다.

## 실기기 수동 검증 시나리오

- 바닥 인식 전: 안내 메시지, 배치 차단 동작
- 바닥 스캔: 방향과 깊이 샘플 카운터 증가 (실제 방 스캔률로 표시하지 않음)
- 배치: 바닥 터치로 가구 배치, 가구 선택 변경, 5cm 이동·15도 회전
- 겹침: 다른 가구와 충돌하는 위치로 이동 시 이동 취소
- 물체: 카메라에 보이는 실제 장애물 위치에 배치 시 경고; 장애물을 치운 뒤 다시 검사
- 빈 공간 추천: `빈 위치 찾기`→녹색 후보 표시→`추천 위치에 배치` 확정
- Depth 불가: 지원 불가 상태에서 빈 공간 추천 제한 및 안내
- 결과: 여러 가구 배치 후 AR 사진 저장, 4단계 결과 화면, 다운로드/공유
