# RoomFit 2.0 Preview — 3D 배치 + 다중 가구 AR

## 이번 수정 범위
- 기본 실행 화면: `roomfit2.html` (기존 AI 결과 화면으로 진입하지 않음)
- 가로/세로 방 크기 입력, 간이 입체 도면에서 가구 추가/드래그/회전/삭제, 10cm 조절
- 가구 52개 목록(기존 프로젝트의 6개 + 이번에 기본 도형으로 직접 만든 46개 GLB)
- 검색/카테고리 필터, 선택 가구 GLB 상세 보기
- 배치 정보 브라우저 localStorage 저장/복원
- Android WebView → 기존 LockedArActivity를 통한 여러 가구 AR 배치 전달
- AR에서 바닥 **한 곳**을 터치하면 해당 지점을 그룹 기준점으로 사용해 3D 배치의 상대 좌표를 적용
- AR 촬영 사진을 새 화면에서 확인 (AI 변환 없음)

## 중요한 구현 수준 / 제한
- **46개 모델은 외부 무료 다운로드 모델이 아닙니다.** 인터넷 다운로드가 불가능해 이번 수정에서 Blender·GLB 형태로 교체하기 쉬운 *직접 생성한 기본 도형 테스트 모델*입니다. 실제 상품 이미지 및 실측 치수와 동일하다는 주장은 하지 않습니다.
- 입체 방 도면은 HTML Canvas의 **등각 투영(간이 3D)**이며, 상세 가구 모델은 별도의 `<model-viewer>`에서 표시됩니다. 방 전체 가구를 GLB 메시로 렌더링하는 완성형 3D 편집기는 아닙니다.
- ARCore의 실제 바닥 추적 및 3D 좌표 연동 **코드는 연결되었지만 Android 기기 빌드/실기기 검증을 하지 못했습니다**. AR 지원 휴대폰에서 동작과 위치 정합을 확인해야 합니다.
- 위치 좌표는 미터 단위이며, 방을 스캔해 실제 벽을 자동으로 정렬하는 기능은 없습니다. AR에서는 사용자가 기준점을 정합니다.
- 겹침 감지는 회전한 가구의 2D 회전 사각형(SAT)으로 처리하며, 충돌 및 벽 이탈 이동을 취소합니다. 복잡한 실제 GLB 외곽 형상까지 검사하는 것은 아닙니다.
- 가구는 한 배치에 최대 12개입니다. 52개 모델은 선택 가능한 라이브러리 수량입니다.
- 기존 사진/AI 관련 파일은 호환 참고용으로 소스에 남아 있으나 새 메인 화면에서는 호출되지 않습니다.

## Android Studio에서 실행하기
1. Android Studio에서 이 폴더를 `Open`으로 선택합니다.
2. Android SDK Platform 35, Android Gradle Plugin 8.7.3 등을 설치하고 Gradle Sync 합니다.
3. `app` 실행 구성을 선택해 Android 8.0 이상 ARCore 지원 스마트폰에서 실행합니다.
4. `Build > Build APK(s)` 또는 Windows PowerShell에서 `./gradlew.bat assembleDebug`로 빌드합니다.
5. 생성 경로: `app/build/outputs/apk/debug/app-debug.apk`
6. AR은 카메라 권한과 Google Play Services for AR가 필요한 기기에서만 가능합니다.

## 웹 화면만 미리보기
```powershell
cd app/src/main/assets/web
python -m http.server 8000
```
브라우저에서 http://localhost:8000/roomfit2.html 을 열면 됩니다.
(웹 브라우저에는 Android NativeBridge가 없으므로 AR 기능은 실행되지 않습니다.)

## 수정 파일
- `app/src/main/assets/web/roomfit2.html`, `roomfit2.css`, `roomfit2.js`
- `app/src/main/assets/web/product-models.json` 및 `product-models/rf2-*.glb`
- `app/src/main/java/kr/ac/roomfit/app/MainActivity.java` — 새 시작 화면
- `app/src/main/java/kr/ac/roomfit/app/LockedArActivity.java` — 그룹 앵커/좌표 배치
- `app/build.gradle` — 개발 버전 2.0.0-preview

## 외부 무료 모델로 교체할 때
- 각 모델의 상업적 이용/앱 포함/재배포 라이선스를 반드시 확인하고 URL·저작자·라이선스를 기록하세요.
- 모델을 GLB로 내보내고 y=0이 바닥, +Y가 위, 실제 미터 크기를 확인하세요.
- `product-models.json`의 asset/id/name/category/kind/dimensionsCm을 새 GLB에 맞게 수정하세요.
- `ProductAssetStore.java`는 metadata 치수와 GLB 치수가 다르면 해당 모델을 거부합니다.
- 인터넷에서 가져온 glTF 확장(Draco 압축·스킨·애니메이션 등)은 현재 Android GLB 파서가 지원하지 않습니다.

## 2.0 개선판 추가 기능
- 가구 이동 시 겹침·벽 이탈을 방지하며 원래 배치로 되돌림
- 실행 취소/다시 실행 (최대 40회), 배치 변경 자동 임시 저장
- JSON 배치 내보내기/불러오기, 기존 모델 목록 및 방 크기 검증
- 회전된 가구 간 겹침을 2D SAT 충돌 검사로 개선
- 새로운 AI 결과 생성 기능은 포함하지 않음

## 남은 한계
- 등각 투영 Canvas는 실제 GLB 메쉬가 동시에 렌더링되는 3D 편집기가 아닙니다. 각 가구의 GLB는 상세 미리보기에서 확인합니다.
- 외부 CC0 가구 30~50종은 네트워크 접근 제한 때문에 직접 다운로드하지 못했습니다. 기존 모델 6종과 직접 생성한 단순 GLB 46종을 사용합니다.
- Android APK 빌드와 ARCore 실기기 검증은 현재 환경에서 수행하지 못했습니다.

보안: 배포 소스 ZIP에는 디버그 서명 keystore와 과거에 빌드된 APK를 제외했습니다. Android Studio 기본 디버그 서명을 사용하세요.

보안: 배포 소스 ZIP에는 디버그 서명 keystore와 과거에 빌드된 APK를 제외했습니다. Android Studio 기본 디버그 서명을 사용하세요.
