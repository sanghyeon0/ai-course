# RoomFit 2.4 변경 사항 (2026-11-19)

## 중간발표 PPT 5페이지 디자인·기능 반영
- 삭제: 기존 01 내 방 사진 업로드, 04 AI 결과 이미지 화면
- 새 4단계 흐름: ① 생활패턴 ② 예산·가구 ③ 2D·3D 배치 ④ AR 확인
- 기존 02 생활패턴 기능 복원: 공부·게임/취미·운동·수면·외출 시간 입력, 기존 `lifestyle-score.js`의 가중치 기반 공간 중요도 계산
- 기존 03 예산·맞춤 가구 유지: 예산 입력, 계획 가격 합계, 가구 카테고리 추천 힌트, 가구 52개 모델 표시
- 기존 2.3 가구 도면/배치/저장, AR 연결 코드 재사용
- 모바일 중심의 흰색·연녹색·진녹색 단계형 UI, 하단 이전/다음 버튼
- `roomfit-2.4.css`, `roomfit-2.4.js` 추가; `roomfit2.html`, `roomfit2.js`, `roomfit3d.js` 수정

## 중요 제한
- 기존 가구 52개 중 46개는 테스트용 간이 GLB 모델임
- 생활패턴 가중치는 프로젝트 내부 규칙이며 과학적으로 검증된 진단은 아님
- 정확한 실판매 가격이 없어 사용자 입력 계획 가격으로만 예산을 계산함
- 3D 에디터는 Canvas 기반 미리보기; 최신 ARCore Java 변경분 전부를 APK에 반영한 정식 Gradle 빌드는 아님
- APK는 기존 native 실행부의 바이너리에 수정된 웹 애셋을 넣어 v2 재서명한 호환성 시험판; Android Studio 소스 빌드가 필요함
- APK 무결성/서명/ZIP CRC/압축 정렬 검사 통과, 실제 휴대폰 설치 및 AR 동작 미검증

## Windows Android Studio 빌드
1. 이 폴더를 Android Studio로 열기
2. compileSdk 35 / Android Gradle Plugin 버전 및 Android SDK 설치
3. `gradlew.bat assembleDebug` 실행
4. `app/build/outputs/apk/debug/app-debug.apk` 사용

## 웹 테스트
`app/src/main/assets/web` 폴더에서 `python -m http.server 8000` 후 `http://localhost:8000/roomfit2.html` 열기
(웹에서는 Android 네이티브 AR 실행 불가)
