# RoomFit 2.3 소스 전달

## 반영 사항
- 2.2의 2D/3D 배치, 다중 AR 연결, 배치 저장, 모델 검색을 유지
- 방 크기에 맞는 가구 목록 필터 및 예산 잔액 표시(입력 가격 기준)
- AR 크기 오차 기록 UI: 기준 크기, 관찰 크기, cm/퍼센트 오차, 기기 로컬 보관
- AR 조작 패널을 240dp 높이 스크롤 영역으로 변경하여 카메라 시야 확보
- JSON 불러오기 시 색상 유지 및 프로젝트 모델 유효성 검사
- MODEL-AUDIT.json을 통한 52개 GLB 존재 여부와 기본 헤더 검증

## 검증 제한 및 미완료
- 이 작업 환경에는 Android SDK, aapt2, apksigner, zipalign이 없어 서명된 새 APK를 빌드하거나 검증하지 못함. 기존 APK를 패치해 배포하면 설치 오류 가능
- 실제 판매 가격은 수집/검증되지 않았음. 계획 가격과 예산 계산만 제공함
- 46개 가구 모델은 자체 제작 시험용이며 외부 무료 사실적 모델 50개를 확보한 것으로 볼 수 없음
- ARCore 추적, 실제 크기 오차 측정, 촬영, 색상 AR 동기화는 실기기 테스트가 필요
- RoomFit의 현재 3D 편집기는 Canvas 기반 GLB 메시 표시이며 Three.js 구현이 아님

## Windows 11에서 APK 만들기
1. Android Studio에서 이 폴더를 엽니다. Android SDK Platform 35와 Build Tools를 설치합니다.
2. Gradle Sync 후 메뉴 Build > Build APK(s), 또는 PowerShell에서 `.\gradlew.bat assembleDebug`를 실행합니다.
3. `app\build\outputs\apk\debug\app-debug.apk`를 휴대폰에 전달합니다.
4. 이미 설치한 룸핏과 개발 키가 다르면 서명 충돌이 날 수 있으므로 앱 데이터 백업 후 제거합니다.
5. ARCore 지원 Android 휴대폰에서 카메라 권한, 가구 다중 배치, 기준점 재설정, 촬영, 오차를 검증합니다.
