# RoomFit 2.6 · 가구 60개 + 예산 추천 + AR 결과 캡처

## 구현 내용

- 총 60개 GLB 가구 모델: 기존 52개 + 룸핏에서 만든 소파 4개, 옷장 2개, 수납가구 2개
- 60개에 예산 계산용 가격 연결: 기존 카탈로그 과거 가격 6개와 **시연용 가정 가격 54개**. 시연 가격은 **실제 판매가가 아니며 가상의 예시**입니다.
- 생활패턴에 따른 우선 카테고리, 예산·방 크기 필터, 충돌 확인 후 3종 추천(절약형/생활패턴/다양한 가구)
- 추천 조합의 2D·3D 자동 배치, 회전/이동/중복 방지/저장
- 새 5단계: 생활패턴 → 예산·가구 추천 → 2D·3D 배치 → AR 확인 → 결과 사진 캡처·저장
- Android AR 촬영 이후 JPEG 결과를 5단계에 보여주고 저장/공유. AR을 이용할 수 없을 때는 명확하게 구분되는 3D 배치 PNG 캡처를 제공

## Android APK에 대한 중요한 사항

- `RoomFit-2.6-Mobile-Compatibility.apk`는 **기존 RoomFit 2.5 APK의 Android 네이티브 실행부를 재사용하고, 앱에 포함된 웹 화면과 3D 데이터를 2.6으로 갱신한 호환 시험판**입니다.
- 새 Android Java 코드를 전체 컴파일한 버전은 아닙니다. 원본 프로젝트의 Java 소스는 필요 부분을 수정했지만 Android SDK가 없어 재빌드/실기기 설치 검증을 하지 못했습니다.
- APK v2 서명 및 파일 정렬과 ZIP 무결성은 검사했습니다. 실기기 Android 설치·ARCore 카메라·촬영 후 갤러리 저장 성공을 보장하는 검사는 진행하지 못했습니다.
- APK는 새 서명으로 생성되어 기존 앱과 설치 충돌이 날 수 있습니다. 기존 앱의 방 배치를 JSON으로 백업한 뒤 삭제·재설치를 진행하세요.
- Android Studio에서 정상 재빌드하려면 Android SDK 35와 Android Gradle Plugin 등 기존 프로젝트의 의존성이 필요합니다.

## 앱에서 사용하는 데이터

- `app/src/main/assets/web/product-models.json` : 모델 ID, GLB 경로, 참조 치수, 카테고리
- `app/src/main/assets/web/product-models/*.glb` : 60개 GLB
- `app/src/main/assets/web/roomfit-prices.json` : 60개 가격, `priceType`이 `historical`인지 `demo`인지 구분
- `app/src/main/assets/web/roomfit-bundle.js` : 예산/생활패턴/가구 종류/자동 배치 추천
- `app/src/main/assets/web/roomfit2.js` : 3D 배치 및 AR 브리지
- `app/src/main/assets/web/roomfit-2.4.js` : 5단계 화면과 결과 캡처/저장

## 휴대폰에서 확인할 순서

1. 1단계에서 시간 입력 후 2단계 이동
2. 예산 30만~50만원 입력 → 추천 조합 선택 → 3단계에서 실제 GLB 배치 확인
3. 4단계에서 **AR로 배치 확인하기** → 바닥 인식·기준점 지정 → **AR 배치 사진 저장**
4. 앱으로 돌아와 5단계에서 실제 AR 촬영 사진 확인 → 결과 이미지 저장 또는 공유
5. AR이 실행되지 않으면 5단계의 **3D 배치 이미지 만들기**를 이용하세요. 이 이미지는 AR 사진이 아닙니다.

## 자체 점검 내용

- GLB 60개 파일 존재·구조 및 신규 8개 GLB를 trimesh로 읽기 검사 통과
- 웹 브라우저: 예산 3만/10만/30만/50만/100만원의 추천 금액이 예산 이하인지 점검
- 60개 가구 리스트, 추천 조합→3D 자동 배치, AR에 전달되는 가구 JSON, 결과 이미지 PNG 저장, AR 반환 콜백의 화면 전환 테스트 통과
- APK ZIP CRC, 저장 파일 4바이트 및 네이티브 `.so` 4096바이트 정렬, SHA256 APK v2 서명 검증 통과
- 실제 Android 휴대폰에서 AR 기능은 **미검증**
