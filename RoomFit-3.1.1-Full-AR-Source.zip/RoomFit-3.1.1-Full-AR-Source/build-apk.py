"""Optional SDK-only build; Android Studio/Gradle is the normal development path."""
from pathlib import Path
import subprocess,sys,os,zipfile,xml.etree.ElementTree as ET
project=Path(__file__).resolve().parent
if len(sys.argv)!=3:
 print('Usage: python build-apk.py /path/to/android-build-tools /path/to/java');raise SystemExit(1)
tools=Path(sys.argv[1]).resolve();java=sys.argv[2]
sdk=tools/'platforms-android-35/android-35/android.jar';bt=tools/'build-tools-35.0.0/android-15'
build=project/'build-local';build.mkdir(exist_ok=True)
for binary in ['aapt2','zipalign']:(bt/binary).chmod(0o755)
def run(*args):subprocess.run([str(v) for v in args],cwd=project,check=True)
import shutil
lib=build/'arcore';lib.mkdir(exist_ok=True)
with zipfile.ZipFile(project/'app/libs/arcore-1.48.0.aar') as z:z.extractall(lib)
run(bt/'aapt2','compile','--dir',project/'app/src/main/res','-o',build/'resources.zip')
run(bt/'aapt2','compile','--dir',lib/'res','-o',build/'ar-resources.zip')
manifest=ET.parse(project/'app/src/main/AndroidManifest.xml');manifest.getroot().set('package','kr.ac.roomfit.app');manifest.write(build/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
generated=build/'generated';generated.mkdir(exist_ok=True)
run(bt/'aapt2','link','-o',build/'unsigned.apk','--manifest',build/'AndroidManifest.xml','-I',sdk,'-A',project/'app/src/main/assets','--auto-add-overlay','--java',generated,'--extra-packages','com.google.ar.core','-R',build/'ar-resources.zip','-R',build/'resources.zip')
classes=build/'classes';shutil.rmtree(classes,ignore_errors=True);classes.mkdir()
run(java,'-jar',tools/'ecj.jar','-1.8','-encoding','UTF-8','-proc:none','-classpath',os.pathsep.join([str(sdk),str(lib/'classes.jar')]),'-d',classes,*list((project/'app/src/main/java').rglob('*.java')),*generated.rglob('*.java'))
dex=build/'dex';dex.mkdir(exist_ok=True)
run(java,'-cp',bt/'lib/d8.jar','com.android.tools.r8.D8','--min-api','26','--lib',sdk,'--output',dex,*classes.rglob('*.class'),lib/'classes.jar')
with zipfile.ZipFile(build/'unsigned.apk','a') as z:
 for f in dex.glob('*.dex'):z.write(f,f.name)
 for f in (lib/'jni').rglob('*.so'):z.write(f,'lib/'+str(f.relative_to(lib/'jni')),compress_type=zipfile.ZIP_STORED)
run(bt/'zipalign','-f','4',build/'unsigned.apk',build/'aligned.apk')
key=project/'roomfit-debug.keystore'
if not key.exists():
 run(Path(java).parent/'keytool','-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','androiddebugkey','-dname','CN=RoomFit Demo,O=RoomFit,C=KR','-keyalg','RSA','-keysize','2048','-validity','10000')
output=project/'RoomFit-Android.apk'
run(java,'-jar',bt/'lib/apksigner.jar','sign','--ks',key,'--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--out',output,build/'aligned.apk')
run(java,'-jar',bt/'lib/apksigner.jar','verify','--verbose',output)
run(bt/'zipalign','-c','4',output)
run(bt/'aapt2','dump','badging',output)
print('APK:',output)
