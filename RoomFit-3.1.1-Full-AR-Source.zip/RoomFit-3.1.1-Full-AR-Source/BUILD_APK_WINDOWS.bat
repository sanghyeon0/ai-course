@echo off
setlocal
cd /d "%~dp0"
echo.
echo RoomFit 3.1.1 - Native ARCore Depth APK build
echo.
if not exist "%~dp0gradlew.bat" (
  echo ERROR: Missing gradlew.bat. Unzip all project files first.
  pause
  exit /b 1
)
call "%~dp0gradlew.bat" --no-daemon assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Open this project in Android Studio and install SDK Platform 35.
  echo Check JAVA_HOME (JDK 17 or the Android Studio JBR) and internet access.
  pause
  exit /b 1
)
if not exist "%~dp0app\build\outputs\apk\debug\app-debug.apk" (
  echo ERROR: Build finished, but APK was not found.
  pause
  exit /b 1
)
copy /y "%~dp0app\build\outputs\apk\debug\app-debug.apk" "%~dp0RoomFit-3.1.1-Full-AR-debug.apk" >nul
echo.
echo SUCCESS: %~dp0RoomFit-3.1.1-Full-AR-debug.apk
echo This is a DEBUG APK. Real-device Depth and camera tests are still required.
pause
