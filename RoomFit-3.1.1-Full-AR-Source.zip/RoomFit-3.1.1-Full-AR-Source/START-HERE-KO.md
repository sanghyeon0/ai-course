# 룸핏 3.1.1 · 실제 ARCore 기능 빌드용 원본

## 왜 이전 APK에 경고가 떴나요?

이전 `RoomFit-3.1-Mobile-Compatibility.apk`는 **기존 1.7.2 Android 실행부**에 새 웹 화면만 넣었으므로 3.1의 Java ARCore Depth 구현이 들어 있지 않았습니다. 이전 APK의 경고창을 지우는 것은 기능 구현이 아닙니다.

이번 프로젝트는 **RoomFit 3.1의 Android Java 원본을 사용한 정상 빌드 대상**입니다. 기능 코드가 들어 있는 파일은 `app/src/main/java/kr/ac/roomfit/app/LockedArActivity.java`, `DepthPlacementChecker.java`, `RoomScanGuide.java`, `EmptySpaceCandidates.java`입니다.

## 반영한 기능

- 3D·2D 수동 편집 없이 `생활패턴 → 예산 추천 → AR → 사진 저장` 흐름 유지
- ARCore `DepthMode.AUTOMATIC` 지원 여부 확인 및 바닥 추적
- Depth 기반 장애물 겹침 가능성 검사 (화면에 관측된 표면만)
- 배치한 **모든 가구**를 주기적으로 검사하고 사진 촬영 직전 재검사
- 불충분한 Depth 인식은 안전하다고 판단하지 않고 배치/촬영 제한
- 바닥 경계와 다른 AR 가구와의 겹침 검사
- 바닥 터치 위치 변경, 5cm 이동, 15도 회전 후 재검사
- 가구 실제 크기(등록 치수) 표시 및 바닥 점유 윤곽선
- 스캔 안내 및 관측 범위 내 빈 위치 후보 추천
- AR 촬영 후 앱의 결과 저장 화면으로 복귀

## Windows에서 APK 만드는 법

1. ZIP 전체를 압축 해제합니다.
2. **Android Studio**를 열고 `settings.gradle`이 있는 이 폴더를 엽니다.
3. SDK Manager에서 **Android SDK Platform 35** 및 관련 Build Tools를 설치하고 Gradle Sync를 수행합니다.
4. 프로젝트 폴더에서 `BUILD_APK_WINDOWS.bat`를 실행합니다. 또는 터미널에서 `gradlew.bat assembleDebug`를 실행합니다.
5. 성공하면 `RoomFit-3.1.1-Full-AR-debug.apk` (또는 `app\build\outputs\apk\debug\app-debug.apk`)가 생성됩니다.
6. 휴대폰에 설치하기 전에 기존 룸핏의 사진·저장 데이터를 백업하세요. 서명 차이로 기존 앱 제거가 필요할 수 있습니다.

## 주의 / 검증 상태

**이 작업 환경에는 Android SDK/Gradle 설치본이 없고 다운로드도 제한되어 APK를 컴파일하지 못했습니다.** 따라서 ZIP은 수정된 Android Studio **원본 프로젝트**이며 완성된 APK라고 표현할 수 없습니다. JVM 계산 로직과 JS 문법·화면 구조를 검사할 수 있지만 ARCore 네이티브 컴파일 및 휴대폰 카메라 테스트는 Android Studio에서 해야 합니다.

Depth는 카메라에 관측된 표면의 거리를 추정하는 기능입니다. 얇은 장애물·유리·가려진 물체·문·통로에 대한 안전한 배치 판정을 보장하지 않습니다. Depth 미지원 단말에서는 자동 장애물 인식과 빈 위치 추천을 제공하지 않습니다.

## 테스트할 동작

1. 카메라 권한 허용, Google Play AR 서비스 업데이트 확인
2. 수평 바닥을 천천히 비추어 `Depth 활성` 확인
3. 침대 앞/비어 있는 바닥에 가구를 각각 배치하여 경고 비교
4. `빈 위치 찾기 → 추천 위치에 배치` 동작 확인
5. 바닥 터치로 위치 변경 및 `5cm`·`15°` 조작 후 충돌 재검사 확인
6. 가구 2~5개 배치 후 사진 저장 → 결과 화면과 갤러리/공유 테스트

실측 확인 전에는 단순히 초록색이 표시되었다고 안전한 배치로 판단하지 마세요.

## Android Studio가 없어도 APK 빌드하는 방법 (GitHub Actions)

프로젝트를 GitHub 저장소에 올리고 `Actions` 탭에서 **Build RoomFit Android APK → Run workflow**를 실행하면 GitHub의 Android 빌드 환경에서 `app-debug.apk`를 만들 수 있도록 `.github/workflows/build-debug-apk.yml`을 포함했습니다. 빌드가 성공하면 해당 실행의 **Artifacts → RoomFit-3.1.1-Debug-APK**에서 파일을 받습니다. 이 과정은 **설정만 제공한 것**이며 이번 작업에서 GitHub에 저장소를 올리거나 원격 빌드를 실행한 것은 아닙니다. Actions 실행 결과에 따라 필요한 수정이 생길 수 있습니다.
