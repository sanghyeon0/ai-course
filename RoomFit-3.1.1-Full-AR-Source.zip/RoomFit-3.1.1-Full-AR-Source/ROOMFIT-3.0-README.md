# RoomFit 3.0 · ARCore Depth 중심 개편

## 실제 수정 내용
- 메인 앱: `roomfit3.html` / `roomfit3.js` / `roomfit3.css` (4단계 생활패턴→예산·60개 모델→AR→사진 저장)
- 수동 2D·3D 도면 편집 화면 진입 제거. 이전 URL `roomfit2.html`은 새 홈으로 이동합니다. 레거시 JS는 호환·참고 용도로 보관합니다.
- 가격: 6개 과거 참고가 + 54개 시연용 가상 가격, **실제 판매가 아님**.
- `LockedArActivity.java`: RoomFit 3 모드, AR 바닥 히트테스트, Depth 지원 확인·활성화, 실제 장애물 볼륨 검사, AR 가구 간 겹침 검사, 실패 시 배치 차단, 결과 사진 캡처.
- `DepthPlacementChecker.java`: 16-bit 깊이 이미지를 화면 좌표와 3D 좌표로 바꾸고, 가구의 바닥 점유 면적·높이 안쪽에 관측 장애물이 있는지 검사.
- `ObstacleMath.java`: 겹침 기초 검사 및 불확실 상태 구별, Java 단위 테스트 가능.

## 주의사항
- 실내 전체를 스캔하거나 기존 가구 종류를 AI로 인식하지는 않습니다. **카메라에 보이는 깊이 표면과 가상 가구의 점유 공간을 비교하는 충돌 가능성 경고**입니다.
- Depth API 미지원 단말: AR 미리보기는 가능하지만 자동 장애물 검사는 제공되지 않으며 화면에 안내합니다.
- 미관측/저조도/가려진 곳, 실제 가구의 복잡한 형상, 벽·문 열림·보행 통로는 정확하게 판정하지 못합니다.
- Google Play Services for AR 및 Depth 지원 안드로이드 단말이 필요합니다.
- 앱 제작 환경에서 Android SDK+Gradle 설치, `./gradlew assembleDebug`로 빌드해야 합니다. 이 ZIP은 **설치 검증된 APK가 아닌 수정 가능한 원본**입니다.

## 테스트
- `javac ObstacleMath.java`와 `ObstacleMathTest.java` (JDK 사용)
- 브라우저에서 `python -m http.server 8000 --directory app/src/main/assets/web`, `http://localhost:8000/roomfit3.html`
- 실제 AR 검증: 바닥 감지, 빈 공간 설치, 실제 장애물 있는 곳 차단, Depth 미지원/데이터 부족 상태 안내, 여러 가구 배치, 촬영 후 결과 화면 복귀.
