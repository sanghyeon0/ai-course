"""Original meshes from RoomFit's own geometry; product photo/spec reference, NOT manufacturer CAD.
Run python tools/build_product_models.py to regenerate GLB, manifest and JS. Units: metres, +Y up.
"""
from pathlib import Path
import math,json,struct,io
from collections import defaultdict
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];WEB=ROOT/'app/src/main/assets/web';OUT=WEB/'product-models';OUT.mkdir(exist_ok=True)
class Model:
 def __init__(self):self.data=defaultdict(list)
 def tri(self,mat,a,b,c,uv=None):
  a,b,c=map(lambda x:np.array(x,dtype=float),(a,b,c));n=np.cross(b-a,c-a);norm=np.linalg.norm(n)
  if norm<1e-10:return
  n/=norm
  for v,t in zip([a,b,c],uv or [(0,0),(1,0),(1,1)]):self.data[mat].append([*v,*n,*t])
 def quad(self,mat,a,b,c,d,uv=None):
  t=uv or [(0,0),(1,0),(1,1),(0,1)];self.tri(mat,a,b,c,[t[0],t[1],t[2]]);self.tri(mat,a,c,d,[t[0],t[2],t[3]])
 def box(self,mat,w,h,d,x,y,z):
  p=np.array([[x+sx*w/2,y+sy*h/2,z+sz*d/2] for sx,sy,sz in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]])
  for a,b,c,e in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:self.quad(mat,p[a],p[b],p[c],p[e])
 def rod(self,mat,a,b,r,segments=24):
  a,b=np.array(a,float),np.array(b,float);axis=b-a;axis/=np.linalg.norm(axis);v=np.cross(axis,[0,1,0] if abs(axis[1])<.9 else [1,0,0]);v/=np.linalg.norm(v);u=np.cross(v,axis)
  for i in range(segments):
   n1=u*math.cos(i*math.tau/segments)+v*math.sin(i*math.tau/segments);n2=u*math.cos((i+1)*math.tau/segments)+v*math.sin((i+1)*math.tau/segments)
   self.quad(mat,a+r*n1,b+r*n1,b+r*n2,a+r*n2);self.tri(mat,a,a+r*n2,a+r*n1);self.tri(mat,b,b+r*n1,b+r*n2)
 def lathe(self,mat,profile,segments=48,x=0,z=0):
  for (r1,y1),(r2,y2) in zip(profile,profile[1:]):
   for i in range(segments):
    t1=i*math.tau/segments;t2=(i+1)*math.tau/segments
    self.quad(mat,(x+r1*math.cos(t1),y1,z+r1*math.sin(t1)),(x+r2*math.cos(t1),y2,z+r2*math.sin(t1)),(x+r2*math.cos(t2),y2,z+r2*math.sin(t2)),(x+r1*math.cos(t2),y1,z+r1*math.sin(t2)))
 def rounded(self,mat,w,d,h,x,y,z,r=.02,vertical=False):
  points=[]
  for cx,cz,start in [(w/2-r,d/2-r,0),(-w/2+r,d/2-r,90),(-w/2+r,-d/2+r,180),(w/2-r,-d/2+r,270)]:
   for i in range(9):
    t=math.radians(start+i*90/8);points.append((cx+r*math.cos(t),cz+r*math.sin(t)))
  def p(a,b,c):return (x+a,y+c,z-b) if vertical else (x+a,y+b,z+c)
  for i,(a,c) in enumerate(points):
   b,e=points[(i+1)%len(points)];self.quad(mat,p(a,-h/2,c),p(b,-h/2,e),p(b,h/2,e),p(a,h/2,c));self.tri(mat,p(0,h/2,0),p(a,h/2,c),p(b,h/2,e),[(.5,.5),(a/w+.5,c/d+.5),(b/w+.5,e/d+.5)]);self.tri(mat,p(0,-h/2,0),p(b,-h/2,e),p(a,-h/2,c))
 def ring(self,mat,x,y,z,major=.014,minor=.003):
  for i in range(32):
   for j in range(8):
    def p(a,b):return (x+(major+minor*math.cos(b))*math.cos(a),y+(major+minor*math.cos(b))*math.sin(a),z+minor*math.sin(b))
    a=i*math.tau/32;b=j*math.tau/8;c=(i+1)*math.tau/32;d=(j+1)*math.tau/8;self.quad(mat,p(a,b),p(c,b),p(c,d),p(a,d))
 def export(self,path):
  chunks=bytearray();views=[];access=[];prims=[]
  def data(raw):
   while len(chunks)%4:chunks.append(0)
   ix=len(views);views.append({'buffer':0,'byteOffset':len(chunks),'byteLength':len(raw)});chunks.extend(raw);return ix
  mats=[];images=[];textures=[]
  for key,rows in self.data.items():
   values=np.array(rows,dtype='<f4');attrs={}
   for label,cols,typ in [('POSITION',slice(0,3),'VEC3'),('NORMAL',slice(3,6),'VEC3'),('TEXCOORD_0',slice(6,8),'VEC2')]:
    a=values[:,cols].copy();ix=len(access);ac={'bufferView':data(a.tobytes()),'componentType':5126,'count':len(a),'type':typ}
    if label=='POSITION':ac.update(min=a.min(0).tolist(),max=a.max(0).tolist())
    access.append(ac);attrs[label]=ix
   m=dict(MATERIALS[key]);m['name']=key
   if key in ['oak','dimple']:
    img=texture(key);view=data(img);images.append({'bufferView':view,'mimeType':'image/png'});textures.append({'source':len(images)-1});m['pbrMetallicRoughness']=dict(m['pbrMetallicRoughness'],baseColorTexture={'index':len(textures)-1})
   mats.append(m);prims.append({'attributes':attrs,'material':len(mats)-1,'mode':4})
  doc={'asset':{'version':'2.0','generator':'RoomFit original photo-reference model v1','extras':{'notManufacturerCAD':True}},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0}],'meshes':[{'primitives':prims}],'materials':mats,'accessors':access,'bufferViews':views,'buffers':[{'byteLength':len(chunks)}]}
  if images:doc.update(images=images,textures=textures)
  raw=json.dumps(doc,separators=(',',':')).encode();raw+=b' '*((-len(raw))%4);chunks+=b'\0'*((-len(chunks))%4);path.write_bytes(struct.pack('<III',0x46546c67,2,28+len(raw)+len(chunks))+struct.pack('<II',len(raw),0x4e4f534a)+raw+struct.pack('<II',len(chunks),0x004e4942)+chunks)
  a=np.array([r[:3] for vals in self.data.values() for r in vals]);return [a.min(0).tolist(),a.max(0).tolist()]
def material(rgb,rough=.6,metal=0,alpha=1):return {'pbrMetallicRoughness':{'baseColorFactor':[*rgb,alpha],'roughnessFactor':rough,'metallicFactor':metal},'doubleSided':True,**({'alphaMode':'BLEND'} if alpha<1 else {})}
MATERIALS={'white':material([.91,.915,.89]),'edge':material([.82,.84,.81]),'black':material([.045,.048,.046],.5),'metalwhite':material([.88,.90,.88],.4,.15),'plasticwhite':material([.94,.945,.92],.34),'drawer':material([.9,.92,.91],.5,alpha=.88),'grey':material([.5,.55,.53]),'oak':material([1,1,1],.8),'dimple':material([1,1,1],.7),'shade':material([.96,.96,.92],.7)}
def texture(kind):
 y,x=np.mgrid[:256,:256];rng=np.random.default_rng(42)
 if kind=='oak':
  wave=np.sin(y*.31+np.sin(x*.016)*2)+np.sin(y*.75+x*.001)*.3;noise=rng.normal(0,.6,(256,256));base=np.stack([224+wave*2+noise,220+wave*2+noise,207+wave*2+noise],-1)
 else:
  rr=((x%8)-4)**2+((y%8)-4)**2;base=np.repeat((36-4*np.exp(-rr/3))[...,None],3,axis=2)
 im=Image.fromarray(np.clip(base,0,255).astype('uint8'));out=io.BytesIO();im.save(out,format='PNG');return out.getvalue()
def desk(oak=False,d=.6):
 m=Model();m.rounded('oak' if oak else 'white',1,d,.034,0,.723,0,.004)
 for x in [-.44,.44]:
  for z in [-d/2+.065,d/2-.065]:
   m.rod('black',(x,0,z),(x,.008,z),.020,32);m.rod('metalwhite',(x,.008,z),(x,.706,z),.020,32);m.rod('metalwhite',(x,.702,z),(x,.706,z),.052,32)
 return m
def chair():
 m=Model()
 for x,z in [(.322,0),(-.322,0),(0,.322),(0,-.322)]:m.rod('black',(0,.07,0),(x,.018,z),.018)
 m.rod('black',(0,.065,0),(0,.48,0),.023);m.rod('black',(0,.46,0),(0,.505,0),.032)
 m.rounded('dimple',.4,.39,.025,0,.5075,0,.045)
 m.rounded('dimple',.38,.245,.012,0,.7175,-.202,.035,True)
 # Rounded tubular back supports and upper border, with actual four-foot base (no invented wheels).
 for x in [-.19,.19]:m.rod('black',(x,.505,-.16),(x,.78,-.212),.011)
 m.rod('black',(-.16,.839,-.212),(.16,.839,-.212),.011)
 for x in [-.16,.16]:m.rod('black',(x,.839,-.212),(math.copysign(.19,x),.81,-.212),.011)
 return m
def drawers():
 m=Model()
 for x in [-.2675,.2675]:
  for z in [-.1725,.1725]:m.box('metalwhite',.015,.59,.015,x,.295,z)
  m.box('metalwhite',.015,.015,.345,x,.6125,0)
  for z in [-.1725,.1725]:m.box('metalwhite',.015,.03,.015,x,.5975,z)
 m.box('white',.55,.014,.36,0,.568,0)
 for lo,hi in [(.036,.202),(.212,.378),(.388,.55)]:
  yc=(lo+hi)/2;hh=hi-lo;m.box('drawer',.506,hh,.004,0,yc,.166);m.box('drawer',.004,hh,.316,-.251,yc,0);m.box('drawer',.004,hh,.316,.251,yc,0);m.box('drawer',.506,.004,.32,0,lo,0);m.box('drawer',.506,hh,.004,0,yc,-.158);m.ring('plasticwhite',0,yc,.173);m.rod('grey',(0,yc,.168),(0,yc,.171),.011,32)
  for x in [-.2675,.2675]:m.box('metalwhite',.015,.007,.345,x,lo,0)
 for a,b in [((-.25,.04,-.174),(.25,.55,-.174)),((.25,.04,-.174),(-.25,.55,-.174))]:m.rod('metalwhite',a,b,.003,12)
 return m
def shelf():
 m=Model();t=.012
 for x in [-.244,.244]:m.box('white',t,.8,.3,x,.4,0)
 m.box('edge',.476,.692,.003,0,.446,-.1485)
 for y in [.106,.444,.794]:m.box('white',.476,t,.3,0,y,0)
 for x in [-.244,.244]:
  for y in [.11,.45,.777]:m.rod('grey',(x,y,.149),(x,y,.15),.0018,12)
 return m
def lamp():
 m=Model();m.lathe('plasticwhite',[(0,0),(.062,0),(.065,.005),(.061,.013),(.045,.028),(.028,.048),(.019,.075),(.016,.103),(.018,.128),(.027,.151),(.03,.155)],64)
 m.lathe('shade',[(.095,.15),(.077,.29),(.075,.29),(.093,.15),(.095,.15)],64)
 m.rod('plasticwhite',(0,.14,0),(0,.235,0),.012,32);return m
specs=[('research-0','linnmon-white',desk(),[100,60,74]),('research-1','linnmon-oak',desk(True),[100,60,74]),('budget-03','smallen-black',chair(),[65,65,85]),('budget-12','lote-white',drawers(),[55,36,62]),('budget-13','baggebo-white',shelf(),[50,30,80]),('budget-09','lampan-white',lamp(),[19,19,29])]
catalog=json.loads((WEB/'catalog.json').read_text());manifest={}
for pid,key,model,dims in specs:
 p=next(x for x in catalog if x['id']==pid);bounds=model.export(OUT/(key+'.glb'))
 manifest[pid]={'asset':key,'name':p['name'],'category':p['category'],'kind':{'책상':'desk','의자':'chair','조명':'lamp','수납장':'storage'}[p['category']],'type':'reference','label':'상품 참고 제작','manufacturerVerified':False,'dimensionsCm':dims,'url':'/product-models/'+key+'.glb','sourceUrl':p['url'],'referenceDate':'2026-10-21','bounds':bounds,'note':'사진과 외곽 치수를 참고해 직접 만든 모형입니다. 세부 형상·재질·색상은 실물과 다를 수 있어요.'}
 print(pid,key,len(model.data),'materials',sum(len(a) for a in model.data.values()),'vertices')
(WEB/'product-models.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(WEB/'product-models.js').write_text('/* Generated from product-models.json; run tools/build_product_models.py. */\nconst PRODUCT_MODELS='+json.dumps(manifest,ensure_ascii=False,separators=(',',':'))+';\n')
