import kr.ac.roomfit.app.ObstacleMath;
public class ObstacleMathTest {
    static void eq(boolean pass){if(!pass)throw new AssertionError();}
    public static void main(String[] args){
      eq(ObstacleMath.classify(2,0)==ObstacleMath.Verdict.UNKNOWN);
      eq(ObstacleMath.classify(10,5)==ObstacleMath.Verdict.BLOCKED);
      eq(ObstacleMath.classify(10,1)==ObstacleMath.Verdict.CLEAR);
      eq(ObstacleMath.inside(0,.3f,0,1,1,1));
      eq(!ObstacleMath.inside(2,.3f,0,1,1,1));
      float[] a={0,0,1,0,1,1,0,1}, b={.5f,.5f,1.5f,.5f,1.5f,1.5f,.5f,1.5f},c={2,2,3,2,3,3,2,3};
      eq(ObstacleMath.overlaps(a,b));eq(!ObstacleMath.overlaps(a,c));
      System.out.println("ObstacleMath tests PASS");
    }
}
