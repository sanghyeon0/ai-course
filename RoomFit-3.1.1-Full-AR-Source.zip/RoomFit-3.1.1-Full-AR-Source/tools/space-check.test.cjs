'use strict';
const assert=require('node:assert/strict');
const S=require('../app/src/main/assets/web/roomfit-space.js');
const models=[{asset:'desk',name:'새 책상',dimensionsCm:[120,60,70]}];
function scene(){return {room:{width:3,depth:4,door:{side:'front',offset:0},clearanceCm:60},existing:[],items:[]};}
const old={name:'기존 침대',x:-.8,z:-.9,width:1,depth:2,rotation:0};
let s=scene();s.existing.push(old);s.items.push({asset:'desk',x:-.8,z:-.9,rotation:0});
assert.match(S.audit(s,models).hard.join(' '),/겹칩니다/,'real vs virtual collision');
s.items[0].x=.8;s.items[0].z=.8;assert.equal(S.audit(s,models).hard.length,0,'move out of collision');
// Door reservation: virtual furniture must not block the entrance.
s=scene();s.items.push({asset:'desk',x:0,z:1.7,rotation:0});assert.match(S.audit(s,models).hard.join(' '),/출입문/);
// Blocked route: continuous cabinet strip across the room.
s=scene();s.existing.push({name:'장벽',x:0,z:0,width:3,depth:.6,rotation:0});assert.equal(S.audit(s,models).walkway.ok,false);
s=scene();assert.equal(S.audit(s,models).walkway.ok,true);
s=scene();s.room.door=null;assert.equal(S.audit(s,models).walkway.ok,null);
// Rotated rectangles overlap based on geometry, not only x/z axes.
assert.equal(S.overlap({x:0,z:0,width:1,depth:2,rotation:45},{x:.4,z:0,width:1,depth:.5,rotation:0}),true);
assert.equal(S.overlap({x:0,z:0,width:1,depth:2,rotation:45},{x:4,z:0,width:1,depth:.5,rotation:0}),false);
// Native payload/document data limits.
assert.equal(S.validExisting({...old,width:-1}),false);
assert.equal(S.inside(scene().room,{...old,x:2}),false);
console.log('PASS: overlap, boundary, doorway, walking route, missing door, rotation, validation');
