package kr.ac.roomfit.app;
public final class FurnitureShapeTest {
 public static void main(String[] args){int count=0;for(String k:new String[]{"desk","chair","bed","storage","table","lamp","rug","box"})for(float[] size:new float[][]{{1,.6f,.75f},{.4f,.35f,.9f},{.01f,.01f,.01f},{2,2,2}}){float w=size[0],d=size[1],h=size[2];for(FurnitureShape.Part p:FurnitureShape.parts(k,w,d,h)){check(p.w>0&&p.h>0&&p.d>0,"positive geometry");check(Math.abs(p.x)+p.w/2<=w/2+.0001f,"width bounds: "+k);check(Math.abs(p.z)+p.d/2<=d/2+.0001f,"depth bounds: "+k);check(p.y-p.h/2>=-.0001f&&p.y+p.h/2<=h+.0001f,"height bounds: "+k);check(p.material>=0&&p.material<3,"material");count++;}}System.out.println("PASS: "+count+" schematic parts preserve declared metric bounds across all 8 kinds");}
 static void check(boolean okay,String what){if(!okay)throw new AssertionError(what);}
}
