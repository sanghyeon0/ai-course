"""Internal geometric QA of the actual GLB triangle meshes (not generated imagery)."""
from pathlib import Path
import json,struct,io
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from PIL import Image
root=Path(__file__).resolve().parents[1]/'app/src/main/assets/web';manifest=json.loads((root/'product-models.json').read_text());fig=plt.figure(figsize=(15,10),facecolor='#f7f6f1')
for idx,(pid,spec) in enumerate(manifest.items()):
 raw=(root/spec['url'].lstrip('/')).read_bytes();jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);binary=raw[28+jl:];ax=fig.add_subplot(2,3,idx+1,projection='3d',facecolor='#f7f6f1')
 for p in doc['meshes'][0]['primitives']:
  ac=doc['accessors'][p['attributes']['POSITION']];v=doc['bufferViews'][ac['bufferView']];points=np.frombuffer(binary,dtype='<f4',count=ac['count']*3,offset=v.get('byteOffset',0)).reshape(-1,3,3);mat=doc['materials'][p['material']]['pbrMetallicRoughness'];base=np.array(mat['baseColorFactor'][:3],dtype=float)
  if 'baseColorTexture' in mat:
   tex=doc['textures'][mat['baseColorTexture']['index']];im=doc['images'][tex['source']];view=doc['bufferViews'][im['bufferView']];img=np.asarray(Image.open(io.BytesIO(binary[view['byteOffset']:view['byteOffset']+view['byteLength']])))/255;base*=np.mean(img,axis=(0,1))**2.2
  normals=np.cross(points[:,1]-points[:,0],points[:,2]-points[:,0]);normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-9);light=np.array([.3,.8,.5]);light/=np.linalg.norm(light);shade=.62+.38*np.abs(normals@light);col=np.clip(base[None,:]*shade[:,None],0,1)**(1/2.2);polys=points[:,:,[0,2,1]];collection=Poly3DCollection(polys,facecolors=col,edgecolors='none',alpha=doc['materials'][p['material']]['pbrMetallicRoughness']['baseColorFactor'][3]);ax.add_collection3d(collection)
 low,high=np.array(spec['bounds']);center=(low+high)/2;extent=max(high-low)*.65;ax.set_xlim(center[0]-extent,center[0]+extent);ax.set_ylim(center[2]-extent,center[2]+extent);ax.set_zlim(0,extent*2);ax.set_box_aspect([1,1,1]);ax.view_init(18,60);ax.set_axis_off();ax.set_title(spec['asset'],fontsize=13,color='#245d48')
fig.tight_layout();fig.savefig('/workspace/scratch/5481c7b91bc2/product-models-qa.png',dpi=120)
