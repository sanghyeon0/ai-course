"""룸핏 상품 가격 갱신 도우미.

판매처 사이트마다 구조가 달라 자동 수집은 깨지기 쉬우므로, '확인이 필요한 상품 목록 뽑기 → 사람이 판매처에서 확인 →
CSV로 한 번에 반영' 방식으로 관리합니다. 앱은 catalog.json 하나만 읽으므로 이 파일만 고치면 됩니다.

사용법
  python tools/price_check.py export --days 7 prices.csv
      확인일이 7일 넘었거나 priceNeedsCheck 표시가 있는 상품을 CSV로 저장합니다.
      new_price 칸에 확인한 가격을 적으세요. 그대로면 비워두고 confirm 칸에 y를 적으면 확인일만 갱신합니다.
  python tools/price_check.py apply prices.csv
      CSV 내용을 catalog.json에 반영하고 checkedAt을 오늘 날짜로 바꿉니다.
  python tools/price_check.py report
      품목별 상품 수·최저가와 오래된 가격 개수를 보여줍니다.
"""
import argparse, csv, json, sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

CATALOG = Path(__file__).resolve().parent.parent / 'app/src/main/assets/web/catalog.json'
KST = timezone(timedelta(hours=9))


def today():
    return datetime.now(KST).date()


def load():
    return json.loads(CATALOG.read_text(encoding='utf-8'))


def save(items):
    CATALOG.write_text(json.dumps(items, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')


def age(p):
    try:
        return (today() - date.fromisoformat(p.get('checkedAt', ''))).days
    except ValueError:
        return 10 ** 6


def export(days, out):
    items = [p for p in load() if p.get('priceNeedsCheck') or age(p) > days]
    with open(out, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['id', 'source', 'name', 'price', 'checkedAt', 'url', 'new_price', 'confirm'])
        for p in items:
            w.writerow([p['id'], p.get('source', ''), p['name'], p['price'], p.get('checkedAt', ''), p['url'], '', ''])
    print(f'{len(items)}개 상품을 {out}에 저장했어요.')


def apply(path):
    items = load()
    by_id = {p['id']: p for p in items}
    changed = confirmed = 0
    with open(path, newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            p = by_id.get(row['id'])
            if not p:
                print('알 수 없는 id:', row['id'], file=sys.stderr)
                continue
            new = (row.get('new_price') or '').replace(',', '').strip()
            if new:
                price = int(new)
                if not 100 <= price <= 50_000_000:
                    raise SystemExit(f"{row['id']}: 가격이 이상해요 ({price})")
                if price != p['price']:
                    print(f"{p['name']}: {p['price']:,} → {price:,}")
                    p['price'] = price
                    changed += 1
            elif (row.get('confirm') or '').strip().lower() not in ('y', 'yes', '1'):
                continue
            p['checkedAt'] = today().isoformat()
            p.pop('priceNeedsCheck', None)
            confirmed += 1
    save(items)
    print(f'가격 변경 {changed}개 · 확인일 갱신 {confirmed}개')


def report():
    items = load()
    cats = {}
    for p in items:
        cats.setdefault(p['category'], []).append(p['price'])
    for c, prices in sorted(cats.items(), key=lambda x: -len(x[1])):
        print(f'{c:8} {len(prices):3}개  최저 {min(prices):>9,}원')
    stale = [p for p in items if p.get('priceNeedsCheck') or age(p) > 7]
    print(f'\n전체 {len(items)}개 · 가격 재확인 필요 {len(stale)}개')


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    e = sub.add_parser('export'); e.add_argument('--days', type=int, default=7); e.add_argument('out')
    a = sub.add_parser('apply'); a.add_argument('csv')
    sub.add_parser('report')
    args = ap.parse_args()
    if args.cmd == 'export':
        export(args.days, args.out)
    elif args.cmd == 'apply':
        apply(args.csv)
    else:
        report()
