import kr.ac.roomfit.app.RoomScanGuide;
import kr.ac.roomfit.app.EmptySpaceCandidates;
import kr.ac.roomfit.app.ObstacleMath;
public final class RoomFit31LogicTest {
  private static void check(boolean v,String msg) { if(!v)throw new AssertionError(msg); }
  public static void main(String[] args){
    RoomScanGuide s=new RoomScanGuide();
    check(!s.hasEnoughForSearch(),"Initial scanning readiness");
    s.observe(0,1,true,true);s.observe(0,1,true,true);s.observe(1,0,true,true);
    check(s.hasEnoughForSearch(),"Scan samples");
    check(s.directions()>=2,"Orientation bins");
    check(s.guidance(true).contains("탐색"),"Guidance");
    check(s.guidance(false).contains("미지원"),"Unsupported message");
    for(int i=0;i<EmptySpaceCandidates.count();i++){
      check(EmptySpaceCandidates.x(i)>0&&EmptySpaceCandidates.x(i)<1,"Candidate X");
      check(EmptySpaceCandidates.y(i)>0&&EmptySpaceCandidates.y(i)<1,"Candidate Y");
    }
    check(ObstacleMath.classify(0,0)==ObstacleMath.Verdict.UNKNOWN,"unknown depth");
    check(ObstacleMath.classify(20,4)==ObstacleMath.Verdict.BLOCKED,"blocked depth");
    check(ObstacleMath.classify(20,0)==ObstacleMath.Verdict.CLEAR,"clear depth");
    System.out.println("RoomFit 3.1 logic tests PASS");
  }
}
