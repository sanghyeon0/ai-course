const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert'),site=process.argv[2];
const ts=require(path.join(site,'node_modules/typescript'));
const transpile=file=>ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;
function load(file,require){const mod={exports:{}};vm.runInNewContext(transpile(path.join(site,file)),{module:mod,exports:mod.exports,require});return mod.exports}
const life=load('lib/lifestyle-score.ts'),ar=load('lib/ar-placement.ts'),refs=JSON.parse(fs.readFileSync(path.join(site,'lib/product-references.json')));let apiCalls=0,posted,failStatus=0;
const mod={exports:{}};
vm.runInNewContext(transpile(path.join(site,'app/api/ar-result/route.ts')),{module:mod,exports:mod.exports,require:n=>n==='cloudflare:workers'?{env:{OPENAI_API_KEY:'mock-only'}}:n.includes('product-references')?refs:n.includes('ar-placement')?ar:life,Response,URL,Map,Set,Date,Number,JSON,Uint8Array,Blob,AbortSignal,atob,fetch:async(url,opt)=>{apiCalls++;assert.equal(url,'https://api.openai.com/v1/images/edits');posted=JSON.parse(opt.body);assert.equal(opt.headers['Content-Type'],'application/json');if(failStatus)return Response.json({error:{code:'insufficient_quota'}},{status:failStatus});return Response.json({data:[{b64_json:'/9j/AA=='}]})}});
const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],pose={id:'research-0',width:100,depth:60,height:74,yawDegrees:15,matrix:identity};
const payload={items:[{id:'research-0'}],style:'우드톤',lifestyle:life.defaultLifestyle,size:'1024x1536',photo:'data:image/jpeg;base64,/9j/AA==',photoFraming:{mode:'contain',x:80,y:0,width:864,height:1536,canvasWidth:1024,canvasHeight:1536},arPlacement:{captureId:'a7c283c5-995c-4b87-a854-260be2ae7123',width:720,height:1280,items:[pose],viewMatrix:identity,projectionMatrix:identity}};
let ip=0;async function send(b,address,origin){return mod.exports.POST(new Request('https://roomfit.example/api/ar-result',{method:'POST',headers:{'Content-Type':'application/json','cf-connecting-ip':address||String(++ip),...(origin?{origin}:{})},body:JSON.stringify(b)}))}
let checks=0;function check(name,fn){fn();checks++;console.log('PASS '+checks+': '+name)}
(async()=>{
let r=await send(payload);assert.equal(r.status,200);let data=await r.json();check('AR snapshot is first JSON image, appearance reference is second',()=>{assert.equal(posted.images[0].image_url,payload.photo);assert.equal(posted.images.length,2);assert(posted.images[1].image_url.endsWith(refs['research-0'].jpeg));assert.equal(posted.model,'gpt-image-2.5-sunburst');assert.equal(posted.quality,'medium');assert.equal(posted.n,1)});
check('saved placement and projection guide override styling rearrangements',()=>{assert(posted.prompt.includes('NOT a room redesign'));assert(posted.prompt.includes('Do not reposition furniture for lifestyle'));assert(posted.prompt.includes('"yawDegrees":15'));assert(posted.prompt.includes('"imageBounds"'));assert(posted.prompt.includes('width=864'));assert.equal(data.captureId,payload.arPlacement.captureId);assert.equal(data.geometryGuaranteed,false)});
check('known projection has bounded screen coordinates',()=>{const rect=ar.projectedBounds(pose,payload.arPlacement);assert.equal(rect.visible,true);assert.equal(rect.left,.25);assert.equal(rect.right,.75);assert.equal(rect.top,.13);assert.equal(rect.bottom,.5)});
check('offscreen furniture is not repositioned into frame',()=>{const p=structuredClone(pose);p.matrix[12]=100;assert.equal(ar.projectedBounds(p,payload.arPlacement).visible,false)});
for(const [name,edit]of [
 ['unknown product',x=>x.items=[{id:'unknown'}]],
 ['missing pose',x=>x.arPlacement.items=[]],
 ['duplicate products',x=>x.items.push({id:'research-0'})],
 ['bad matrix length',x=>x.arPlacement.items[0].matrix=[1,2]],
 ['invalid homogeneous matrix',x=>x.arPlacement.items[0].matrix[15]=0],
 ['impossible dimensions',x=>x.arPlacement.items[0].width=0],
 ['missing AR photo',x=>x.photo=''],
 ['non-JPEG photo',x=>x.photo='data:image/jpeg;base64,AAAA'],
 ['framing outside image',x=>x.photoFraming.width=2000],
 ['aspect mismatch',x=>x.arPlacement.width=1280],
 ['invalid lifestyle',x=>x.lifestyle={}],
 ['non-array products',x=>x.items={map:'invalid'}]
]){const bad=structuredClone(payload);edit(bad);r=await send(bad);assert.equal(r.status,400,name);}
check('12 malformed AR/photo/ID/lifestyle cases rejected before provider call',()=>{assert.equal(apiCalls,1)});
r=await send(payload,null,'https://other.example');check('foreign origin rejected',()=>assert.equal(r.status,403));
r=await mod.exports.POST(new Request('https://roomfit.example/api/ar-result',{method:'POST',body:'x'.repeat(2500001)}));check('oversized request rejected',()=>assert.equal(r.status,413));
failStatus=429;r=await send(payload);check('provider credit error returns an error, no fake AI image and no retry',async()=>{assert.equal(r.status,502);assert.equal(apiCalls,2)});failStatus=0;
for(let i=0;i<3;i++){r=await send(payload,'throttle');assert.equal(r.status,200)}r=await send(payload,'throttle');check('fourth request per minute blocked by isolate guard',()=>assert.equal(r.status,429));
console.log(`${checks} groups passed. Mock provider only; no paid API call or real image quality evaluation.`);
})().catch(e=>{console.error(e);process.exitCode=1});
