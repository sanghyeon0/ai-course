export type Lifestyle={study:number;hobby:number;exercise:number;sleep:number;outside:number;mode:'auto'|'study'|'hobby'|'rest'|'exercise'|'outside';noDrilling:boolean;noRenovation:boolean;keepFurniture:boolean};
export const defaultLifestyle:Lifestyle={study:4,hobby:2,exercise:1,sleep:7,outside:6,mode:'auto',noDrilling:true,noRenovation:true,keepFurniture:true};
export const baselines={study:4,hobby:3,exercise:1,sleep:8,outside:6};
export const spaceDefinitions=[
 {id:'desk',name:'공부·작업 공간',weights:[1,.7,0,0,.05],categories:['책상','의자','조명']},
 {id:'storage',name:'수납 공간',weights:[.25,.6,.25,.1,.7],categories:['수납장','선반','정리함','트롤리']},
 {id:'rest',name:'휴식 공간',weights:[.1,.3,.15,.35,.8],categories:['휴식용 의자','조명','러그']},
 {id:'exercise',name:'운동·빈 바닥 공간',weights:[0,.05,1,0,.05],categories:['정리함','트롤리']},
 {id:'sleep',name:'수면 공간',weights:[.1,.05,.15,1,.15],categories:['조명','러그']},
 {id:'entry',name:'외출·귀가 동선',weights:[0,.1,.1,.05,1],categories:['선반','정리함','보조테이블']}
];
const boosts:Record<string,Record<string,number>>={auto:{},study:{desk:1.5},hobby:{desk:1.35,storage:1.35},rest:{rest:1.5,sleep:1.2},exercise:{exercise:1.6},outside:{entry:1.5,storage:1.2}};
const methods=[
 {id:'desk-clear',space:'desk',text:'기존 책상 상판을 비우고 작업 조명을 한쪽에 두기',blockedBy:[]},
 {id:'desk-wall',space:'desk',text:'벽 선반으로 책상 위 물건을 올려 보관하기',blockedBy:['noDrilling']},
 {id:'desk-replace',space:'desk',text:'기존 책상을 더 넓은 책상으로 교체하기',blockedBy:['keepFurniture']},
 {id:'storage-box',space:'storage',text:'정리함으로 물건을 종류별로 나누고 자주 쓰는 것은 앞에 두기',blockedBy:[]},
 {id:'storage-wall',space:'storage',text:'벽에 고정하는 수납장을 설치하기',blockedBy:['noDrilling']},
 {id:'rest-light',space:'rest',text:'기존 휴식 자리 옆에 이동식 조명을 배치하기',blockedBy:[]},
 {id:'rest-paint',space:'rest',text:'휴식 공간 벽을 차분한 색으로 도색하기',blockedBy:['noRenovation']},
 {id:'exercise-clear',space:'exercise',text:'이동식 정리함에 물건을 모아 바닥의 빈 공간 확보하기',blockedBy:[]},
 {id:'sleep-textile',space:'sleep',text:'기존 침대는 유지하고 침구와 조명의 색감을 정돈하기',blockedBy:[]},
 {id:'sleep-floor',space:'sleep',text:'침실 바닥 마감재를 바꾸기',blockedBy:['noRenovation']},
 {id:'entry-drop',space:'entry',text:'출입문을 가리지 않는 곳에 작은 정리함을 두고 소지품 모으기',blockedBy:[]}
];
export function validateLifestyle(p:unknown):p is Lifestyle{if(!p||typeof p!=='object')return false;const x=p as Lifestyle;return Object.keys(baselines).every(k=>typeof x[k as keyof typeof baselines]==='number'&&Number.isFinite(x[k as keyof typeof baselines])&&x[k as keyof typeof baselines]>=0&&x[k as keyof typeof baselines]<=24)&&Object.keys(baselines).reduce((sum,k)=>sum+x[k as keyof typeof baselines],0)<=24.0001&&Object.hasOwn(boosts,x.mode)&&['noDrilling','noRenovation','keepFurniture'].every(k=>typeof (x as any)[k]==='boolean')}
export function scoreLifestyle(p:Lifestyle){if(!validateLifestyle(p))throw new Error('하루 활동 시간 합계는 24시간 이하여야 합니다.');const keys=Object.keys(baselines)as (keyof typeof baselines)[];const intensity=Object.fromEntries(keys.map(k=>[k,Math.min(2,p[k]/baselines[k])]))as Record<keyof typeof baselines,number>;
 const spaces=spaceDefinitions.map(s=>{const terms=keys.map((k,i)=>({activity:k,intensity:intensity[k],weight:s.weights[i],contribution:intensity[k]*s.weights[i]}));const boost=boosts[p.mode][s.id]||1;return {...s,terms,boost,score:terms.reduce((v,t)=>v+t.contribution,0)*boost,percent:0}});const total=spaces.reduce((s,x)=>s+x.score,0);spaces.forEach(s=>s.percent=total?s.score/total*100:0);spaces.sort((a,b)=>b.score-a.score||spaceDefinitions.findIndex(x=>x.id===a.id)-spaceDefinitions.findIndex(x=>x.id===b.id));
 const ordered=[...methods].sort((a,b)=>spaces.findIndex(s=>s.id===a.space)-spaces.findIndex(s=>s.id===b.space));const excluded=ordered.filter(m=>m.blockedBy.some(k=>(p as any)[k])).map(m=>({...m,reasons:m.blockedBy.filter(k=>(p as any)[k])}));const allowed=ordered.filter(m=>!m.blockedBy.some(k=>(p as any)[k]));const picked:typeof allowed=[];for(const m of allowed)if(picked.length<3&&!picked.some(x=>x.space===m.space))picked.push(m);
 const categoryWeights:Record<string,number>={};for(const c of new Set(spaceDefinitions.flatMap(s=>s.categories)))categoryWeights[c]=1+Math.max(0,...spaces.filter(s=>s.categories.includes(c)).map(s=>s.percent/100*3));
 return {version:'1.0',baselines,intensity,spaces,top:spaces.filter(s=>s.score>0).slice(0,3),selectedMethods:picked,excludedMethods:excluded,categoryWeights,formula:'활동 강도 = min(2, 활동 시간 ÷ 기준 시간); 공간 점수 = Σ(활동 강도 × 공간 가중치) × 모드 보정; 비율 = 공간 점수 ÷ 전체 점수 × 100',note:'프로젝트에서 정한 규칙과 가중치이며 과학적으로 검증된 생활 진단은 아닙니다.'}}
