// All files stay within the trusted app origin; native code owns Android document pickers.
document.addEventListener('click',async function(event){
 const a=event.target.closest&&event.target.closest('a[download]');
 if(!a||!window.RoomfitNative)return;
 const url=a.href;if(!url.startsWith('blob:')&&!url.startsWith('data:'))return;
 event.preventDefault();event.stopImmediatePropagation();
 try{const blob=await (await fetch(url)).blob();const reader=new FileReader();reader.onload=()=>window.RoomfitNative.saveDataUrl(reader.result,a.download||'roomfit-download');reader.readAsDataURL(blob)}catch(e){console.error('Native save failed',e)}
},true);
