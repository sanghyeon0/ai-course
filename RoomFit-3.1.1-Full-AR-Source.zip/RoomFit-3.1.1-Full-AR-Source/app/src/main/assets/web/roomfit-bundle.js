/* RoomFit 2.6: 60-model budget planner. DEMO prices are illustrative, never live retail offers. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const money=n=>Math.round(n).toLocaleString('ko-KR')+'원';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const catName={bed:'침대',desk:'책상',chair:'의자',storage:'수납장',table:'테이블',lamp:'조명',box:'정리함',sofa:'소파',wardrobe:'옷장'};
const group=m=>m.category==='소파'?'sofa':m.category==='옷장'?'wardrobe':m.kind;
const defaultOrder=['bed','desk','chair','storage','lamp','table','sofa','wardrobe','box'];
const lifestyleGroups={desk:['desk','chair'],chair:['chair','desk'],bed:['bed','storage'],storage:['storage','wardrobe'],table:['table','sofa'],lamp:['lamp'],box:['box']};
let priorities=['desk','chair'],prices=new Map(),ready=false,plans=[],renderInProgress=false;
const editor=()=>window.RoomFitBundleEditor;
const state=()=>editor()?.getState?.()||{room:{width:3,depth:4},items:[]};
const models=()=>editor()?.getModels?.()||[];
const fit=(m,room)=>{const d=m.dimensionsCm||[],w=Number(d[0]),z=Number(d[1]);return w>0&&z>0&&((w<=room.width*100&&z<=room.depth*100)||(z<=room.width*100&&w<=room.depth*100));};
function priceFor(id){const p=prices.get(id);return p?{...p}:null;}
function candidates(){const r=state().room;return models().filter(m=>prices.has(m.id)&&fit(m,r)).map(m=>({...m,...prices.get(m.id),group:group(m)}));}
function remainingBudget(s){let unknown=0,spend=0;for(const it of s.items){if(it.plannedPrice==null||it.plannedPrice===''){unknown++;continue}spend+=Number(it.plannedPrice)||0;}return {unknown,spend,remaining:Math.max(0,Math.floor(Number($('budget').value)||0)-spend)};}
function variant(pool,mode){const a=[...pool].sort((x,y)=>x.price-y.price||x.name.localeCompare(y.name,'ko'));if(mode==='economy')return a.slice(0,3);if(mode==='focus')return [a[Math.min(a.length-1,1)],a[0],a[Math.floor((a.length-1)/2)]].filter(Boolean);return [a[Math.floor((a.length-1)/2)],a[0],a[Math.min(a.length-1,3)]].filter(Boolean);}
function focusOrder(){const focus=[];priorities.forEach(kind=>(lifestyleGroups[kind]||[kind]).forEach(g=>{if(!focus.includes(g))focus.push(g)}));return [...new Set([...focus,...defaultOrder])];}
function sequence(mode){if(mode==='economy')return ['lamp','box','chair','storage','desk','bed','table','wardrobe','sofa'];if(mode==='focus')return focusOrder();return ['bed','desk','chair','storage','lamp','table','sofa','wardrobe','box'];}
function uniqueById(items){return items.map(p=>p.id).sort().join('|')}
function findPlan(mode,used){
 const s=state(),{remaining,unknown}=remainingBudget(s),installed=new Set(s.items.map(it=>{const m=models().find(p=>p.asset===it.asset);return m?group(m):null}));
 const pool=candidates().filter(p=>!installed.has(p.group)),order=sequence(mode),maxKinds=mode==='economy'?4:mode==='focus'?5:6;
 if(remaining<=0||s.items.length>=12)return null;
 const byGroup=new Map();for(const p of pool){if(!byGroup.has(p.group))byGroup.set(p.group,[]);byGroup.get(p.group).push(p)}
 let beam=[{chosen:[],price:0,score:0}];
 for(let j=0;j<order.length;j++){
  const g=order[j],options=variant(byGroup.get(g)||[],mode),next=[];
  for(const rec of beam){next.push(rec);if(rec.chosen.length>=Math.min(maxKinds,12-s.items.length))continue;
   for(const p of options){if(!p||rec.price+p.price>remaining)continue;
    const major=mode==='focus'&&j<priorities.length+1?45:mode==='balance'&&['bed','desk','chair'].includes(g)?22:0;
    const priceBonus=mode==='economy'?Math.max(0,45-p.price/10000):mode==='focus'?Math.min(20,p.price/15000):Math.min(15,p.price/20000);
    next.push({chosen:[...rec.chosen,p],price:rec.price+p.price,score:rec.score+100+major+priceBonus-j*.6});}
  }
  next.sort((a,b)=>b.score-a.score||a.price-b.price);
  const dedup=new Set();beam=[];for(const r of next){const sig=uniqueById(r.chosen);if(dedup.has(sig))continue;dedup.add(sig);beam.push(r);if(beam.length>=110)break;}
 }
 beam.sort((a,b)=>b.chosen.length-a.chosen.length||b.score-a.score||(mode==='economy'?a.price-b.price:b.price-a.price));
 for(const item of beam){if(!item.chosen.length)continue;const signature=uniqueById(item.chosen);if(used.has(signature))continue;
  const rows=item.chosen.map(p=>({asset:p.asset,price:p.price,priceType:p.priceType}));
  const check=editor()?.canPlaceBundle?.(rows);
  if(check?.ok){used.add(signature);return {mode,chosen:item.chosen,cost:item.price,remaining:remaining-item.price,unknown};}
 }
 return null;
}
function planCandidates(){const used=new Set(),results=[];for(const mode of ['economy','focus','balance']){const p=findPlan(mode,used);if(p)results.push(p)}return results;}
function render(){if(renderInProgress)return;renderInProgress=true;
 try{
  const out=$('bundle-results'),status=$('bundle-status');if(!out||!status||$('stage-2')?.hidden)return;
  if(!ready){status.textContent='가구 가격 정보를 읽는 중입니다.';return;}
  const s=state(),budget=Number($('budget').value),r=remainingBudget(s),all=candidates();
  if(!Number.isFinite(budget)||budget<=0){status.textContent='예산을 1원 이상으로 설정해주세요.';out.replaceChildren();return;}
  const demos=all.filter(p=>p.priceType==='demo').length,history=all.length-demos;
  status.textContent=`방에 들어가는 가구 ${all.length}개 · 과거 등록 참고가 ${history}개 · 시연용 가정 가격 ${demos}개. ${r.unknown?`기존 배치의 가격 미등록 ${r.unknown}개는 예산에서 제외됩니다.`:''}`;
  plans=planCandidates();
  if(!plans.length){out.innerHTML='<p class="minor">현재 예산과 빈 공간으로 자동 배치할 가구 조합이 없습니다. 예산·방 크기 또는 기존 배치를 조정해 주세요.</p>';return;}
  const labels={economy:['절약형','기본적으로 필요한 종류를 낮은 가정 가격부터'],focus:['생활패턴 맞춤','내 활동에 중요한 종류부터'],balance:['다양한 가구 구성','여러 가구 종류를 폭넓게']};
  out.innerHTML=plans.map((p,i)=>`<div class="bundle-item ${p.mode==='focus'?'best':''}"><h3>${labels[p.mode][0]}</h3><div class="bundle-meta">${labels[p.mode][1]}</div><strong>${money(p.cost)}</strong><div class="bundle-meta">적용 후 남는 예산 ${money(p.remaining)} · ${p.chosen.length}종</div><ul>${p.chosen.map(c=>`<li>${esc(c.name)} · ${money(c.price)} <small>${c.priceType==='demo'?'(시연 가격)':'(과거 참고가)'}</small></li>`).join('')}</ul><button type="button" class="primary" data-apply-bundle="${i}">이 조합 3D 방에 배치</button></div>`).join('');
 }finally{renderInProgress=false;}}
async function init(){try{
 const response=await fetch('/roomfit-prices.json',{cache:'no-store'});if(!response.ok)throw Error('가격 데이터');const data=await response.json();
 if(!Array.isArray(data))throw Error('목록 형식');
 prices=new Map(data.filter(row=>typeof row.id==='string'&&Number.isSafeInteger(row.price)&&row.price>0&&row.price<100000000&&['historical','demo'].includes(row.priceType)).map(row=>[row.id,row]));
 ready=true;window.RoomFitCatalogRefresh?.();render();
 }catch(e){$('bundle-status').textContent='가격 파일을 읽지 못했습니다. 직접 가구 배치는 계속 가능합니다.';}}
function apply(index){render();const plan=plans[Number(index)];if(!plan)return;
 const rows=plan.chosen.map(p=>({asset:p.asset,price:p.price,priceType:p.priceType}));
 const result=editor()?.addBundle?.(rows);
 if(result?.ok){render();alert(`${result.count}개 가구를 방에 배치했습니다. 시연 가격은 실제 판매가가 아닙니다. 3단계에서 위치를 확인하세요.`);}
 else{render();alert(result?.message||'배치를 완료하지 못했습니다.');}}
$('bundle-results').addEventListener('click',event=>{const btn=event.target.closest('[data-apply-bundle]');if(btn)apply(btn.dataset.applyBundle)});
$('bundle-recalculate').addEventListener('click',render);
$('budget').addEventListener('input',render);
window.RoomFitBudget={refresh:render,priceFor,setPriorities(list){priorities=Array.isArray(list)?list.slice(0,4):priorities;if(ready)render();},get priceCount(){return prices.size},get recommendationCount(){return plans.length}};
init();
})();
