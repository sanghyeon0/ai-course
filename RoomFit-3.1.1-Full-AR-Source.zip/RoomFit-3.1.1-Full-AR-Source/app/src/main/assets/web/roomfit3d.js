/* RoomFit 2.1 lightweight offline GLB room renderer. Uses actual triangles from bundled glTF 2.0 GLB meshes. */
(()=>{'use strict';
const cache=new Map(), loading=new Set();
let az=.76, el=.69, zoom=1, topView=false;
const root=()=>document.getElementById('room');
const num=(n,d=0)=>Number.isFinite(n)?n:d;
function readGLB(buffer){
 const dv=new DataView(buffer);if(dv.getUint32(0,true)!==0x46546c67)throw Error('GLB header');
 let offset=12,json=null,bin=null;
 while(offset+8<=buffer.byteLength){let size=dv.getUint32(offset,true),type=dv.getUint32(offset+4,true);offset+=8;if(offset+size>buffer.byteLength)throw Error('GLB chunk');if(type===0x4e4f534a)json=JSON.parse(new TextDecoder().decode(new Uint8Array(buffer,offset,size)));if(type===0x004e4942)bin=new DataView(buffer,offset,size);offset+=size;}
 if(!json||!bin)throw Error('GLB missing chunks');
 const comp={5120:[1,'getInt8'],5121:[1,'getUint8'],5122:[2,'getInt16'],5123:[2,'getUint16'],5125:[4,'getUint32'],5126:[4,'getFloat32']},ncomp={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT4:16};
 function access(id){const a=json.accessors[id],v=json.bufferViews[a.bufferView],c=comp[a.componentType];if(!c||!v)throw Error('Unsupported accessor');let out=[],stride=v.byteStride||c[0]*ncomp[a.type],start=(v.byteOffset||0)+(a.byteOffset||0);for(let i=0;i<a.count;i++){let vals=[];for(let j=0;j<ncomp[a.type];j++)vals.push((()=>{let raw=bin[c[1]](start+i*stride+j*c[0],true);return a.normalized&&a.componentType!==5126?raw/(a.componentType===5121?255:a.componentType===5123?65535:1):raw})());out.push(ncomp[a.type]===1?vals[0]:vals)}return out}
 const tris=[];let total=0;
 function visit(id, parent){const node=json.nodes[id],local=node.matrix?node.matrix:compose(node.translation||[0,0,0],node.rotation||[0,0,0,1],node.scale||[1,1,1]),mat=mult(parent,local);
 if(node.mesh!==undefined){const mesh=json.meshes[node.mesh];for(const p of mesh.primitives){if(p.mode!==undefined&&p.mode!==4)continue;const pos=access(p.attributes.POSITION),ind=p.indices!==undefined?access(p.indices):pos.map((_,i)=>i);let col=p.attributes.COLOR_0!==undefined?access(p.attributes.COLOR_0):null;let base=[.65,.78,.69];const material=json.materials?.[p.material];if(material?.pbrMetallicRoughness?.baseColorFactor)base=material.pbrMetallicRoughness.baseColorFactor.slice(0,3);let stride=Math.max(1,Math.ceil(ind.length/3/550));for(let i=0;i+2<ind.length;i+=3*stride){const idx=[ind[i],ind[i+1],ind[i+2]];const pts=idx.map(k=>transform(mat,pos[k]));let c=col?idx.reduce((acc,k)=>acc.map((x,j)=>x+(col[k]?.[j]??.72)/3),[0,0,0]):base;tris.push({v:pts,color:c});total++;}}}
 for(const child of node.children||[])visit(child,mat)}
 const identity=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];for(const index of json.scenes?.[json.scene||0]?.nodes||[])visit(index,identity);
 return tris;
 }
 function compose(t,q,s){let [x,y,z,w]=q;return [(1-2*y*y-2*z*z)*s[0],(2*x*y+2*z*w)*s[0],(2*x*z-2*y*w)*s[0],0,(2*x*y-2*z*w)*s[1],(1-2*x*x-2*z*z)*s[1],(2*y*z+2*x*w)*s[1],0,(2*x*z+2*y*w)*s[2],(2*y*z-2*x*w)*s[2],(1-2*x*x-2*y*y)*s[2],0,...t,1]}
 function mult(a,b){const out=new Array(16).fill(0);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)out[c*4+r]+=a[k*4+r]*b[c*4+k];return out}
 function transform(m,p){return [m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]]}
 function request(product,rerender){if(!product?.url||cache.has(product.asset)||loading.has(product.asset))return;loading.add(product.asset);fetch(product.url).then(r=>{if(!r.ok)throw Error('fetch');return r.arrayBuffer()}).then(buf=>cache.set(product.asset,readGLB(buf))).catch(()=>cache.set(product.asset,null)).finally(()=>{loading.delete(product.asset);rerender()});}
 function options(){const a=topView?0:az,e=topView?1.5703:el;return {right:[Math.cos(a),0,-Math.sin(a)],up:[-Math.sin(a)*Math.sin(e),Math.cos(e),-Math.cos(a)*Math.sin(e)],depth:[Math.sin(a)*Math.cos(e),Math.sin(e),Math.cos(a)*Math.cos(e)]}}
 function draw(state,catalogue,selected){const canvas=root();if(!canvas)return;const box=canvas.getBoundingClientRect(),w=Math.max(260,Math.round(box.width)),h=Math.max(260,Math.round(box.height)),ratio=Math.min(2,window.devicePixelRatio||1);canvas.width=w*ratio;canvas.height=h*ratio;const ctx=canvas.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,w,h);ctx.fillStyle='#f7faf6';ctx.fillRect(0,0,w,h);const basis=options(),scale=Math.min(w/(state.room.width+2),h/(state.room.depth+2))*zoom*.95, cx=w/2,cy=h*.62;
 function project(p){return {x:cx+scale*(p[0]*basis.right[0]+p[2]*basis.right[2]),y:cy-scale*(p[0]*basis.up[0]+p[1]*basis.up[1]+p[2]*basis.up[2]),z:p[0]*basis.depth[0]+p[1]*basis.depth[1]+p[2]*basis.depth[2]}}
 function fill(verts,paint,stroke){const v=verts.map(project);ctx.beginPath();v.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=paint;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke()}}
 const W=state.room.width/2,D=state.room.depth/2,H=num(state.room.height,2.4);fill([[-W,0,-D],[W,0,-D],[W,0,D],[-W,0,D]],'#ebf4e9','#bdcfc1');
 ctx.strokeStyle='#d8e4d9';ctx.lineWidth=.8;for(let x=-W;x<=W+.01;x+=.5){let a=project([x,.005,-D]),b=project([x,.005,D]);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}for(let z=-D;z<=D+.01;z+=.5){let a=project([-W,.005,z]),b=project([W,.005,z]);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}
 if(!topView){fill([[-W,0,-D],[-W,H*.7,-D],[W,H*.7,-D],[W,0,-D]],'rgba(197,217,204,.14)','#c2d7c7');fill([[-W,0,-D],[-W,H*.7,-D],[-W,H*.7,D],[-W,0,D]],'rgba(213,230,217,.13)','#c2d7c7')}
 // Entry clearance is shown on the 2D/3D floor (not a physical obstacle).
 if(state.room.door&&window.RoomFitSpace){const zone=window.RoomFitSpace.doorArea(state.room);
  if(zone){const points=window.RoomFitSpace.polygon(zone).map(p=>[p[0],.015,p[1]]);fill(points,'rgba(240,158,97,.22)','#df936e');}}
 // Drawing is depth-sorted across the entire room. Models include real GLB triangles, not footprint boxes.
 const tris=[],centers=[];
 // Draw registered *real* furniture as neutral, semi-transparent boxes;
 // their positions are user-entered estimates, not detected by the camera.
 (state.existing||[]).forEach((box,i)=>{
  if(!window.RoomFitSpace?.validExisting(box))return;
  const w=box.width/2,d=box.depth/2,h=.55,t=(box.rotation||0)*Math.PI/180,c=Math.cos(t),s=Math.sin(t);
  const transformPoint=(x,y,z)=>[box.x+x*c-z*s,y,box.z+x*s+z*c];
  const faces=[[[-w,0,-d],[w,0,-d],[w,h,-d],[-w,h,-d]],[[w,0,-d],[w,0,d],[w,h,d],[w,h,-d]],[[-w,0,d],[-w,0,-d],[-w,h,-d],[-w,h,d]],[[-w,h,-d],[w,h,-d],[w,h,d],[-w,h,d]],[[w,0,d],[-w,0,d],[-w,h,d],[w,h,d]]];
  faces.forEach((face,k)=>{const verts=face.map(q=>transformPoint(...q));tris.push({verts,avg:verts.reduce((n,p)=>n+p[0]*basis.depth[0]+p[1]*basis.depth[1]+p[2]*basis.depth[2],0)/verts.length,color:k===3?'#d0a691':'#a98e82',sel:false});});
 });
 state.items.forEach((item,i)=>{const prod=catalogue.find(p=>p.asset===item.asset);if(!prod)return;request(prod,()=>draw(state,catalogue,selected));const a=(item.rotation||0)*Math.PI/180,c=Math.cos(a),s=Math.sin(a);centers.push({i,...project([item.x,0,item.z])});const model=cache.get(prod.asset);if(model?.length){for(const tri of model){const verts=tri.v.map(p=>[p[0]*c+p[2]*s+item.x,p[1],-p[0]*s+p[2]*c+item.z]);const avg=verts.reduce((sum,p)=>sum+p[0]*basis.depth[0]+p[1]*basis.depth[1]+p[2]*basis.depth[2],0)/3;const ux=verts[1][0]-verts[0][0],uy=verts[1][1]-verts[0][1],uz=verts[1][2]-verts[0][2],vx=verts[2][0]-verts[0][0],vy=verts[2][1]-verts[0][1],vz=verts[2][2]-verts[0][2];const ny=uz*vx-ux*vz,shade=Math.max(.46,Math.min(1, .76+ny*.09));let cc=tri.color;const tint=item.tint||null;if(tint){let tr=parseInt(tint.slice(1,3),16)/255,tg=parseInt(tint.slice(3,5),16)/255,tb=parseInt(tint.slice(5,7),16)/255;cc=[cc[0]*.4+tr*.6,cc[1]*.4+tg*.6,cc[2]*.4+tb*.6]};const color='#'+cc.slice(0,3).map(x=>Math.max(0,Math.min(255,Math.round(x*255*shade))).toString(16).padStart(2,'0')).join('');tris.push({verts,avg,color,sel:i===selected})}}
 else{const d=prod.dimensionsCm.map(x=>x/100),[ww,dd,hh]=d,faces=[[[ -ww/2,0,-dd/2],[ww/2,0,-dd/2],[ww/2,hh,-dd/2],[-ww/2,hh,-dd/2]], [[-ww/2,0,dd/2],[ww/2,0,dd/2],[ww/2,hh,dd/2],[-ww/2,hh,dd/2]], [[-ww/2,hh,-dd/2],[ww/2,hh,-dd/2],[ww/2,hh,dd/2],[-ww/2,hh,dd/2]]];for(let j=0;j<faces.length;j++){let verts=faces[j].map(p=>[p[0]*c+p[2]*s+item.x,p[1],-p[0]*s+p[2]*c+item.z]);tris.push({verts,avg:verts.reduce((r,p)=>r+p[0]*basis.depth[0]+p[1]*basis.depth[1]+p[2]*basis.depth[2],0)/verts.length,color:j===2?'#b4d6bd':'#8ea89a',sel:i===selected})}}});
 tris.sort((a,b)=>b.avg-a.avg);for(const tri of tris)fill(tri.verts,tri.color,tri.sel?'rgba(22,139,88,.5)':null);
 centers.forEach(p=>{if(p.i!==selected)return;ctx.strokeStyle='#1e9b6b';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(p.x,p.y,13,8,0,0,Math.PI*2);ctx.stroke()});
 if(state.room.door){const side=state.room.door.side||'front',offset=num(state.room.door.offset,0),widthDoor=.8;const start=side==='front'?[offset-widthDoor/2,0,D]:side==='back'?[offset-widthDoor/2,0,-D]:side==='right'?[W,0,offset-widthDoor/2]:[-W,0,offset-widthDoor/2],end=side==='front'?[offset+widthDoor/2,0,D]:side==='back'?[offset+widthDoor/2,0,-D]:side==='right'?[W,0,offset+widthDoor/2]:[-W,0,offset+widthDoor/2];let p=project(start),q=project(end);ctx.lineWidth=5;ctx.strokeStyle='#dc956b';ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.stroke()}
 if(state.room.window){let p=project([0,H*.37,-D]),q=project([Math.min(.9,W),H*.37,-D]);ctx.strokeStyle='#59b6ce';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.stroke()}
 // Existing-furniture labels remain visible in the plan.
 (state.existing||[]).forEach(e=>{const q=project([e.x,.59,e.z]);ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillStyle='#784d38';ctx.fillText(e.name.slice(0,12),q.x,q.y-4)});
 ctx.fillStyle='#546c5f';ctx.font='12px system-ui';ctx.textAlign='center';ctx.fillText('ROOMFIT · 3D 배치 참고 이미지 (AR 사진 아님)',w/2,h-14);
 window.Roomfit3D._hit=centers;window.Roomfit3D._proj={cx,cy,scale,basis};}
 function pick(x,y){let best=-1,dist=1e7;for(const p of window.Roomfit3D._hit||[]){let d=(x-p.x)**2+(y-p.y)**2;if(d<dist&&d<2400){dist=d;best=p.i}}return best}
 function coordinate(px,py){let {cx,cy,scale,basis}=window.Roomfit3D._proj,dx=(px-cx)/scale,dy=-(py-cy)/scale,rx=basis.right[0],rz=basis.right[2],ux=basis.up[0],uz=basis.up[2],det=rx*uz-rz*ux;return Math.abs(det)<.001?{x:0,z:0}:{x:(dx*uz-rz*dy)/det,z:(rx*dy-dx*ux)/det}}
 window.Roomfit3D={draw,pick,coordinate,orbit(step){az+=step;topView=false},elevation(step){el=Math.max(.23,Math.min(1.52,el+step));topView=false},zoom(step){zoom=Math.max(.5,Math.min(2.4,zoom*step))},top(){topView=!topView},setTop(value){topView=!!value},get topView(){return topView},_hit:[],_proj:null};
})();
