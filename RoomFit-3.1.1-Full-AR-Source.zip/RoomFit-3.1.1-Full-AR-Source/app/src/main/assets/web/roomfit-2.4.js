/* RoomFit 2.4 stepper + life-pattern integration. Retains existing roomfit2.js editor. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const KEYS=['study','hobby','exercise','sleep','outside'];
const DEFAULT={study:4,hobby:2,exercise:1,sleep:7,outside:6};
const STORE='roomfit-2.4-lifestyle';
const CATEGORIES={desk:{label:'책상',kind:'desk'},storage:{label:'수납장',kind:'storage'},rest:{label:'의자',kind:'chair'},exercise:{label:'수납장',kind:'storage'},sleep:{label:'침대',kind:'bed'},entry:{label:'수납장',kind:'storage'}};
let stage=1, lifestyle={...DEFAULT}, assessment=null;
try{const saved=JSON.parse(localStorage.getItem(STORE)||'null');if(saved&&KEYS.every(k=>Number.isInteger(saved[k])&&saved[k]>=0&&saved[k]<=24))lifestyle=Object.fromEntries(KEYS.map(k=>[k,saved[k]]));}catch{}
function read(){return Object.fromEntries(KEYS.map(k=>[k,Number(document.querySelector(`[data-hours="${k}"]`).value)]));}
function sync(){KEYS.forEach(k=>document.querySelector(`[data-hours="${k}"]`).value=String(lifestyle[k]));}
function evaluate(){const total=KEYS.reduce((sum,k)=>sum+lifestyle[k],0),info=$('routine-total');info.textContent=`선택한 시간 ${total}시간 / 24시간 · 기타 활동 ${Math.max(0,24-total)}시간`;info.classList.toggle('invalid',total>24);const out=$('routine-ranking'),summary=$('lifestyle-short'),tags=$('recommended-filters');
  if(total>24){out.innerHTML='<p class="minor">하루 시간 합계가 24시간을 넘었습니다.</p>';summary.textContent='시간 합계를 24시간 이내로 조정해 주세요.';tags.innerHTML='';assessment=null;return false;}
  try{assessment=LifestyleEngine.scoreLifestyle({...lifestyle,noDrilling:true,noRenovation:true,keepFurniture:true});}catch(err){out.textContent='생활패턴을 다시 확인해주세요.';assessment=null;return false;}
  const top=assessment.top.slice(0,3);out.innerHTML=top.map((v,i)=>`<div class="ranking"><span>${i+1}. ${v.name}</span><div class="rankbar"><span style="width:${Math.max(4,Math.min(100,v.percent*3))}%"></span></div><small>${Math.round(v.percent)}%</small></div>`).join('')||'<p class="minor">활동 시간을 입력해 주세요.</p>';
  summary.textContent=top.length?`중요도가 높은 공간: ${top.map(s=>s.name).join(' · ')}. 아래 종류별로 가구를 살펴보세요.`:'활동 시간을 입력하면 추천 가구 종류가 표시됩니다.';
  tags.innerHTML=top.map(v=>{const c=CATEGORIES[v.id]||CATEGORIES.desk;return `<button class="filter-tag" type="button" data-kind="${c.kind}">${c.label} 보기</button>`}).join('');
  try{localStorage.setItem(STORE,JSON.stringify(lifestyle));}catch{}window.RoomFitBudget?.setPriorities?.(top.map(v=>(CATEGORIES[v.id]||CATEGORIES.desk).kind));return true;
}
function show(next){if(next<1||next>5)return;if(next>=2&&!evaluate()){alert('생활패턴 시간의 합계를 24시간 이내로 입력해 주세요.');show(1);return;}stage=next;
  for(let i=1;i<=5;i++){$('stage-'+i).hidden=i!==stage;const tab=document.querySelector(`[data-stage="${i}"]`);tab.classList.toggle('active',i===stage);tab.classList.toggle('passed',i<stage);if(i===stage)tab.setAttribute('aria-current','step');else tab.removeAttribute('aria-current');}
  $('wizard-prev').disabled=stage===1;$('wizard-next').textContent=({1:'예산·가구 선택하기 →',2:'2D·3D 배치하기 →',3:'AR 확인하기 →',4:'결과 캡처·저장 →',5:'AR 다시 확인하기 ↶'})[stage];$('wizard-progress').textContent=`${stage} / 5 단계`;$('stage-live').textContent=`${stage}단계로 이동했습니다.`;
  if(stage===4){const count=$('placed').querySelectorAll('[data-index]').length;const cash=$('budget-summary').textContent;$('final-summary').textContent=count?`배치된 가구 ${count}개 · ${cash}`:'아직 배치된 가구가 없습니다. 2단계에서 가구를 추가해 주세요.';}
  if(stage===2){updateQuick();window.RoomFitBudget?.refresh?.();window.RoomFitCatalogRefresh?.();}if(stage===5)updateResult();window.scrollTo({top:0,behavior:'instant'});
  if(stage===3)requestAnimationFrame(()=>window.dispatchEvent(new Event('resize')));
}
function updateQuick(){const name=$('selectedname').textContent;const input=$('plannedprice');$('quick-selected').textContent=name==='선택 없음'?'가구 목록에서 배치하기 버튼을 눌러주세요.':`선택: ${name}`;$('quick-plannedprice').value=input.value||'';}
function refreshQuickSoon(){setTimeout(updateQuick,40)}
$('routine-list').addEventListener('click',event=>{const b=event.target.closest('[data-adjust]');if(!b)return;const [key,diff]=b.dataset.adjust.split(':');if(!KEYS.includes(key))return;lifestyle[key]=Math.min(24,Math.max(0,lifestyle[key]+Number(diff)));sync();evaluate();});
$('routine-list').addEventListener('change',event=>{const k=event.target.dataset.hours;if(!KEYS.includes(k))return;const n=Number(event.target.value);lifestyle[k]=Number.isFinite(n)?Math.min(24,Math.max(0,Math.round(n))):0;sync();evaluate();});
$('wizard-next').addEventListener('click',()=>show(stage===5?4:stage+1));$('wizard-prev').addEventListener('click',()=>show(stage-1));
document.querySelectorAll('[data-stage]').forEach(b=>b.addEventListener('click',()=>show(Number(b.dataset.stage))));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>show(Number(b.dataset.go))));
$('recommended-filters').addEventListener('click',event=>{const kind=event.target.closest('[data-kind]')?.dataset.kind;if(!kind)return;const select=$('category');const opt=[...select.options].find(o=>o.value===({desk:'책상',chair:'의자',storage:'수납장',bed:'침대',lamp:'조명',table:'테이블',box:'정리함'}[kind]||kind));if(opt){select.value=kind;select.dispatchEvent(new Event('change'));$('catalog').scrollIntoView({behavior:'smooth',block:'start'});}});
$('catalog').addEventListener('click',event=>{if(event.target.closest('[data-add]'))refreshQuickSoon()});
$('quick-applyprice').addEventListener('click',()=>{$('plannedprice').value=$('quick-plannedprice').value;$('applyprice').click();refreshQuickSoon();});
$('budget').addEventListener('input',()=>{if(stage===4)show(stage);window.RoomFitBudget?.refresh?.();});
// Only native AR capture returns a real camera image. A 3D screenshot is clearly labeled separately.
let actualAR=false, last3D='';
const formatWon=n=>Math.round(n).toLocaleString('ko-KR')+'원';
function updateResult(){
 const items=window.RoomFitBundleEditor?.getState?.()?.items||[],models=window.RoomFitBundleEditor?.getModels?.()||[];
 const budget=Number($('budget').value)||0,total=items.reduce((a,v)=>a+(Number(v.plannedPrice)||0),0),missing=items.filter(v=>v.plannedPrice==null).length;
 $('result-stats').textContent=`가구 ${items.length}개 · 계획 합계 ${formatWon(total)} · 남은 예산 ${formatWon(budget-total)}${missing?' · 가격 미등록 '+missing+'개':''}`;
 $('result-placed-count').textContent=items.length+'개';
 $('result-products').innerHTML=items.map((it,i)=>{const m=models.find(x=>x.asset===it.asset);return `<div class="result-product"><span>${i+1}. ${m?.name||'가구'}</span><strong>${it.plannedPrice!=null?formatWon(it.plannedPrice):'가격 미등록'}</strong></div>`}).join('')||'<p class="minor">아직 배치된 가구가 없습니다.</p>';
 const src=$('ar-photo').getAttribute('src')||'';
 $('ar-photo').hidden=!src.startsWith('data:image/');$('result-placeholder').hidden=!$('ar-photo').hidden;
 $('result-type').textContent=actualAR?'실제 AR 촬영 사진':src?'3D 편집 화면 캡처':'아직 결과 사진 없음';
 $('result-disclaimer').textContent=actualAR?'AR 화면에서 직접 촬영한 결과입니다. 측정 정확도를 보장하지 않습니다.':'3D 편집 화면을 캡처한 참고 이미지입니다. 실제 카메라 AR 사진이 아닙니다.';
}
$('capture-3d').addEventListener('click',()=>{
 const canvas=$('room');try{const img=canvas.toDataURL('image/png');if(!img.startsWith('data:image/png'))throw Error();
 actualAR=false;last3D=img;$('ar-photo').src=img;updateResult();
 }catch{alert('3D 화면을 캡처하지 못했어요. 먼저 3단계에서 방을 확인한 후 다시 시도해 주세요.');}
});
$('save-photo').addEventListener('click',()=>{
 const data=$('ar-photo').getAttribute('src')||'';
 if(!data.startsWith('data:image/')){alert('저장할 사진이 없습니다. AR 촬영 또는 3D 캡처를 먼저 진행하세요.');return;}
 const name=actualAR?'RoomFit-AR-Result.jpg':'RoomFit-3D-Preview.png';
 if(window.RoomfitNative?.saveDataUrl){window.RoomfitNative.saveDataUrl(data,name);}else{
 const a=document.createElement('a');a.href=data;a.download=name;document.body.appendChild(a);a.click();a.remove();
 }
});
$('restore-photo').addEventListener('click',()=>{if(window.RoomfitNative?.restoreLockedAR)window.RoomfitNative.restoreLockedAR();else alert('마지막 AR 사진 불러오기는 Android 앱에서만 가능합니다.');});
const previousReceive=window.receiveLockedARResult;
window.receiveLockedARResult=result=>{
 if(previousReceive)previousReceive(result);
 if(result&&typeof result.image==='string'&&result.image.startsWith('data:image/jpeg;base64,')){
   actualAR=true;$('ar-photo').src=result.image;show(5);$('result-image-frame').scrollIntoView({behavior:'smooth',block:'center'});
 }else show(4);
};
$('share-photo').addEventListener('click',()=>{
 const src=$('ar-photo').getAttribute('src')||'';
 if(!src.startsWith('data:image/')){alert('공유할 결과 사진이 없습니다.');return;}
 if(src.startsWith('data:image/jpeg')&&window.RoomfitNative?.shareDataUrl)window.RoomfitNative.shareDataUrl(src);
 else if(src.startsWith('data:image/png')&&window.RoomfitNative?.shareImage)window.RoomfitNative.shareImage(src,'RoomFit 3D 배치 참고 이미지');
 else {const a=document.createElement('a');a.href=src;a.download=actualAR?'RoomFit-AR-Result.jpg':'RoomFit-3D-Preview.png';a.click();}
});
sync();evaluate();show(1);
})();
