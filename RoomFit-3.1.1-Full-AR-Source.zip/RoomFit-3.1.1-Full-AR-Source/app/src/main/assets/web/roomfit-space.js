/* RoomFit 2.7: conservative 2D floor-footprint assessment.
   Existing furniture is entered by the user; this is NOT camera/depth detection.
   Units: metres. An entry door is assumed on the +Z (front) wall. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.RoomFitSpace = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const finite = x => typeof x === 'number' && Number.isFinite(x);
  const round = n => Math.round(n * 100) / 100;
  function polygon(b) {
    const t = (Number(b.rotation) || 0) * Math.PI / 180, c=Math.cos(t), s=Math.sin(t);
    const w=Number(b.width)/2, d=Number(b.depth)/2, x=Number(b.x), z=Number(b.z);
    return [[-w,-d],[w,-d],[w,d],[-w,d]].map(([a,k])=>[x+a*c-k*s,z+a*s+k*c]);
  }
  function overlap(a,b) {
    const A=polygon(a),B=polygon(b);
    for(const P of [A,B]) for(let i=0;i<4;i++) {
      const e=[P[(i+1)%4][0]-P[i][0],P[(i+1)%4][1]-P[i][1]],axis=[-e[1],e[0]];
      const pa=A.map(p=>p[0]*axis[0]+p[1]*axis[1]),pb=B.map(p=>p[0]*axis[0]+p[1]*axis[1]);
      if(Math.max(...pa)<=Math.min(...pb)+1e-7||Math.max(...pb)<=Math.min(...pa)+1e-7)return false;
    }
    return true;
  }
  function inside(room,box) {
    return polygon(box).every(p=>Math.abs(p[0])<=room.width/2+0.0001&&Math.abs(p[1])<=room.depth/2+0.0001);
  }
  function toBoxes(state,models) {
    const byAsset = new Map((models||[]).map(p=>[p.asset,p]));
    return (state.items||[]).map((v,i)=>{
      const p=byAsset.get(v.asset);
      if(!p||!Array.isArray(p.dimensionsCm))return null;
      return {id:'item-'+i,name:p.name||'배치 가구',x:Number(v.x),z:Number(v.z),width:Number(p.dimensionsCm[0])/100,depth:Number(p.dimensionsCm[1])/100,rotation:Number(v.rotation)||0};
    }).filter(Boolean);
  }
  function validExisting(e) {
    return e&&typeof e.name==='string'&&e.name.length<=40&&e.name.trim().length>0&&
      [e.x,e.z,e.width,e.depth,e.rotation].every(finite)&&e.width>=.1&&e.width<=5&&e.depth>=.1&&e.depth<=5&&
      Math.abs(e.x)<=8&&Math.abs(e.z)<=8&&Math.abs(e.rotation)<=360;
  }
  function doorArea(room) {
    if(!room.door)return null;
    const side=room.door.side||'front', offset=Number(room.door.offset)||0, width=.8, depth=.85;
    if(side==='front')return {x:offset,z:room.depth/2-depth/2,width,depth,rotation:0};
    if(side==='back')return {x:offset,z:-room.depth/2+depth/2,width,depth,rotation:0};
    if(side==='left')return {x:-room.width/2+depth/2,z:offset,width:depth,depth:width,rotation:0};
    return {x:room.width/2-depth/2,z:offset,width:depth,depth:width,rotation:0};
  }
  // True if a circle around a walking person at (x,z) would touch a rectangle.
  function circleTouchesBox(x,z,r,b) {
    const t=-(Number(b.rotation)||0)*Math.PI/180,c=Math.cos(t),s=Math.sin(t);
    const dx=x-b.x,dz=z-b.z,localX=dx*c-dz*s,localZ=dx*s+dz*c;
    const nearX=Math.max(-b.width/2,Math.min(b.width/2,localX)),nearZ=Math.max(-b.depth/2,Math.min(b.depth/2,localZ));
    return (localX-nearX)**2+(localZ-nearZ)**2 <= r*r;
  }
  function findRoute(room, boxes, clearCm) {
    if(!room.door)return {ok:null,reason:'출입문 위치를 설정해야 이동 통로를 검사할 수 있어요.',points:[]};
    const step=.12,r=clearCm/200,cols=Math.floor(room.width/step)+1,rows=Math.floor(room.depth/step)+1;
    const xAt=i=>-room.width/2+i*room.width/(cols-1),zAt=j=>-room.depth/2+j*room.depth/(rows-1);
    const map=new Uint8Array(cols*rows), seen=new Uint8Array(cols*rows);
    for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){
      const x=xAt(i),z=zAt(j),index=j*cols+i;
      if(Math.abs(x)>room.width/2-r||Math.abs(z)>room.depth/2-r||boxes.some(b=>circleTouchesBox(x,z,r,b)))map[index]=1;
    }
    const door=room.door, side=door.side||'front', off=Number(door.offset)||0;
    // Start from a cell near the entry, but allow a tiny search in a 40cm radius.
    const seed=side==='front'?[off,room.depth/2-r-.09]:side==='back'?[off,-room.depth/2+r+.09]:side==='left'?[-room.width/2+r+.09,off]:[room.width/2-r-.09,off];
    const candidates=[];
    for(let j=0;j<rows;j++)for(let i=0;i<cols;i++)if(!map[j*cols+i]){
      const dist=Math.hypot(xAt(i)-seed[0],zAt(j)-seed[1]);if(dist<=.30)candidates.push({index:j*cols+i,dist});
    }
    candidates.sort((a,b)=>a.dist-b.dist);
    if(!candidates.length)return {ok:false,reason:`출입문 안쪽에 ${clearCm}cm 폭의 진입 공간이 없어요.`,points:[]};
    const parent=new Int32Array(cols*rows).fill(-1),queue=new Int32Array(cols*rows);let head=0,tail=0;
    for(const c of candidates.slice(0,5)){seen[c.index]=1;queue[tail++]=c.index;}
    let end=-1;
    while(head<tail){const id=queue[head++],i=id%cols,j=Math.floor(id/cols),x=xAt(i),z=zAt(j);
      const far=side==='front'?z<=-room.depth*.2:side==='back'?z>=room.depth*.2:side==='left'?x>=room.width*.2:x<=-room.width*.2;
      if(far){end=id;break;}
      for(const [di,dj] of [[-1,0],[1,0],[0,-1],[0,1]]){
        const ni=i+di,nj=j+dj;if(ni<0||nj<0||ni>=cols||nj>=rows)continue;
        const nxt=nj*cols+ni;if(map[nxt]||seen[nxt])continue;seen[nxt]=1;parent[nxt]=id;queue[tail++]=nxt;
      }
    }
    if(end<0)return {ok:false,reason:`출입문에서 방 안쪽까지 ${clearCm}cm 이상의 연속 통로가 확보되지 않아요.`,points:[]};
    const path=[];while(end>=0){path.push({x:round(xAt(end%cols)),z:round(zAt(Math.floor(end/cols)))});end=parent[end];}
    return {ok:true,reason:`${clearCm}cm 통로 확보 가능 (입력한 배치 기준)`,points:path.reverse()};
  }
  function audit(state,models,opt={}) {
    const room=state.room||{},existing=Array.isArray(state.existing)?state.existing:[],planned=toBoxes(state,models);
    const hard=[],warnings=[],clearCm=Math.max(40,Math.min(100,Math.round(Number(room.clearanceCm)||60)));
    if(!(finite(room.width)&&finite(room.depth)&&room.width>=1.5&&room.width<=8&&room.depth>=1.5&&room.depth<=8)){
      hard.push('방 가로·세로 크기가 올바르지 않습니다.');return {hard,warnings,walkway:{ok:null,points:[]},clearCm};
    }
    for(const e of existing){if(!validExisting(e))hard.push('기존 가구 정보에 잘못된 값이 있습니다.');else if(!inside(room,e))hard.push(`${e.name}: 기존 가구가 방 바깥으로 나가요.`);}
    for(const p of planned) {
      if(!inside(room,p))hard.push(`${p.name}: 방 크기를 벗어나요.`);
      for(const e of existing)if(validExisting(e)&&overlap(p,e))hard.push(`새 가구 「${p.name}」와 기존 가구 「${e.name}」가 겹칩니다.`);
    }
    for(let i=0;i<existing.length;i++)for(let j=i+1;j<existing.length;j++){
      if(validExisting(existing[i])&&validExisting(existing[j])&&overlap(existing[i],existing[j]))warnings.push(`${existing[i].name}과(와) ${existing[j].name}의 실제 위치가 겹쳐 등록됐어요.`);
    }
    const door=doorArea(room);
    if(door) {
      for(const p of planned)if(overlap(p,door))hard.push(`${p.name}이(가) 출입문 앞 약 85cm 공간을 막습니다.`);
      for(const e of existing)if(validExisting(e)&&overlap(e,door))warnings.push(`기존 가구 「${e.name}」가 출입문 쪽 공간을 차지합니다.`);
    } else warnings.push('출입문 위치를 입력하면 출입문 및 이동 통로를 검사할 수 있어요.');
    if(existing.length===0)warnings.push('기존 가구를 등록하지 않아 실제 방 가구와의 겹침은 확인하지 못했어요.');
    let walkway={ok:null,points:[],reason:'통로 검사 대기'};
    if(!opt.skipWalkway){walkway=findRoute(room,[...planned,...existing.filter(validExisting)],clearCm);if(walkway.ok===false)warnings.push(walkway.reason);}
    return {hard:[...new Set(hard)],warnings:[...new Set(warnings)],walkway,clearCm,plannedCount:planned.length,existingCount:existing.length};
  }
  return {polygon,overlap,inside,validExisting,doorArea,findRoute,audit};
});
