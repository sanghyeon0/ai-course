/* Main CTA generates from the uploaded room + selected products. AR stays optional per product. */
renderImageStep=DirectImageBase.render;
showGeneratedImage=DirectImageBase.show;
stepNames.splice(2,2,'맞춤 가구','AI 결과');
function startDirectImage(){if(imageBusy||photoBusy)return;if(!makePlans())return;if(generatedSignature!==signature()){generatedImage='';generatedBefore='';generatedSignature='';generatedDemo='';comparisonOpen=false}wizardStep=3;maxStep=3;wizardScreen();return generateRoomImage()}
const nextBeforeDirectImage=thirdNext;
thirdNext=function(){if(thirdPane==='picks')return startDirectImage();return nextBeforeDirectImage()};
// Old in-page action names also bypass main AR placement.
startLockedAR=function(){return startDirectImage()};
const picksBeforeDirectImage=picksScreen;
picksScreen=function(){return picksBeforeDirectImage().replace(/<div class="locked-intro">[\s\S]*?<\/div>/,'<div class="locked-intro"><b>추천 가구로 내 방의 변화를 미리 봐요</b><p>아래 AI 이미지 생성 버튼을 누르면 방 사진과 추천 가구를 참고해 바로 만들어요. 생성 시 API 비용이 발생해요.</p></div>')};
// A leftover native callback from an older version must not relabel an AR snapshot as an AI result.
receiveLockedARResult=function(){toast('추천 화면의 AI 이미지 생성 버튼으로 결과를 만들 수 있어요.')};
