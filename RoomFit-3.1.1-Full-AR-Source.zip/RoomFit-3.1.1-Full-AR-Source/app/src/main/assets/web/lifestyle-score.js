const LifestyleEngine=(()=>{const exports={};"use strict";
/*
 * 생활패턴 → 공간 중요도 계산.
 * mode / noRenovation / keepFurniture 값은 기존 서버 API 형식과 맞추기 위해 기본값으로만 남겨 두었고,
 * 자취생은 공사·가구 교체가 어렵다고 보고 해당 방법은 추천 목록에서 아예 뺐습니다.
 */
exports.defaultLifestyle = { study: 4, hobby: 2, exercise: 1, sleep: 7, outside: 6, mode: 'auto', noDrilling: true, noRenovation: true, keepFurniture: true };
exports.baselines = { study: 4, hobby: 3, exercise: 1, sleep: 8, outside: 6 };
exports.spaceDefinitions = [
    { id: 'desk', name: '공부·작업 공간', weights: [1, .7, 0, 0, .05], categories: ['책상', '의자', '조명'] },
    { id: 'storage', name: '수납 공간', weights: [.25, .6, .25, .1, .7], categories: ['수납장', '선반', '정리함', '트롤리'] },
    { id: 'rest', name: '휴식 공간', weights: [.1, .3, .15, .35, .8], categories: ['휴식용 의자', '조명', '러그'] },
    { id: 'exercise', name: '운동·빈 바닥 공간', weights: [0, .05, 1, 0, .05], categories: ['정리함', '트롤리'] },
    { id: 'sleep', name: '수면 공간', weights: [.1, .05, .15, 1, .15], categories: ['조명', '러그'] },
    { id: 'entry', name: '외출·귀가 동선', weights: [0, .1, .1, .05, 1], categories: ['선반', '정리함', '보조테이블'] }
];
const methods = [
    { id: 'desk-clear', space: 'desk', text: '기존 책상 상판을 비우고 작업 조명을 한쪽에 두기', blockedBy: [] },
    { id: 'desk-wall', space: 'desk', text: '벽 선반으로 책상 위 물건을 올려 보관하기', blockedBy: ['noDrilling'] },
    { id: 'storage-box', space: 'storage', text: '정리함으로 물건을 종류별로 나누고 자주 쓰는 것은 앞에 두기', blockedBy: [] },
    { id: 'storage-wall', space: 'storage', text: '벽에 고정하는 수납장을 설치하기', blockedBy: ['noDrilling'] },
    { id: 'rest-light', space: 'rest', text: '기존 휴식 자리 옆에 이동식 조명을 배치하기', blockedBy: [] },
    { id: 'exercise-clear', space: 'exercise', text: '이동식 정리함에 물건을 모아 바닥의 빈 공간 확보하기', blockedBy: [] },
    { id: 'sleep-textile', space: 'sleep', text: '기존 침대는 유지하고 침구와 조명의 색감을 정돈하기', blockedBy: [] },
    { id: 'entry-drop', space: 'entry', text: '출입문을 가리지 않는 곳에 작은 정리함을 두고 소지품 모으기', blockedBy: [] }
];
function validateLifestyle(p) {
    if (!p || typeof p !== 'object') return false;
    const keys = Object.keys(exports.baselines);
    return keys.every(k => typeof p[k] === 'number' && Number.isFinite(p[k]) && p[k] >= 0 && p[k] <= 24)
        && keys.reduce((sum, k) => sum + p[k], 0) <= 24.0001
        && typeof p.noDrilling === 'boolean';
}
function scoreLifestyle(p) {
    if (!validateLifestyle(p)) throw new Error('하루 활동 시간 합계는 24시간 이하여야 합니다.');
    const keys = Object.keys(exports.baselines);
    const intensity = Object.fromEntries(keys.map(k => [k, Math.min(2, p[k] / exports.baselines[k])]));
    const spaces = exports.spaceDefinitions.map(s => {
        const terms = keys.map((k, i) => ({ activity: k, intensity: intensity[k], weight: s.weights[i], contribution: intensity[k] * s.weights[i] }));
        return { ...s, terms, score: terms.reduce((v, t) => v + t.contribution, 0), percent: 0 };
    });
    const total = spaces.reduce((s, x) => s + x.score, 0);
    spaces.forEach(s => s.percent = total ? s.score / total * 100 : 0);
    const order = id => exports.spaceDefinitions.findIndex(x => x.id === id);
    spaces.sort((a, b) => b.score - a.score || order(a.id) - order(b.id));
    const ordered = [...methods].sort((a, b) => spaces.findIndex(s => s.id === a.space) - spaces.findIndex(s => s.id === b.space));
    const excluded = ordered.filter(m => m.blockedBy.some(k => p[k])).map(m => ({ ...m, reasons: m.blockedBy.filter(k => p[k]) }));
    const allowed = ordered.filter(m => !m.blockedBy.some(k => p[k]));
    const picked = [];
    for (const m of allowed) if (picked.length < 3 && !picked.some(x => x.space === m.space)) picked.push(m);
    const categoryWeights = {};
    for (const c of new Set(exports.spaceDefinitions.flatMap(s => s.categories)))
        categoryWeights[c] = 1 + Math.max(0, ...spaces.filter(s => s.categories.includes(c)).map(s => s.percent / 100 * 3));
    return { version: '1.1', baselines: exports.baselines, intensity, spaces, top: spaces.filter(s => s.score > 0).slice(0, 3), selectedMethods: picked, excludedMethods: excluded, categoryWeights,
        formula: '활동 강도 = min(2, 활동 시간 ÷ 기준 시간); 공간 점수 = Σ(활동 강도 × 공간 가중치); 비율 = 공간 점수 ÷ 전체 점수 × 100',
        note: '프로젝트에서 정한 규칙과 가중치이며 과학적으로 검증된 생활 진단은 아닙니다.' };
}
exports.validateLifestyle = validateLifestyle;
exports.scoreLifestyle = scoreLifestyle;
return exports;})();
