package kr.ac.roomfit.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PointF;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.*;
import com.google.ar.core.*;
import org.json.JSONObject;
import java.nio.*;
import java.util.Locale;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Two tracked points on the same horizontal plane; returns a width, never room geometry. */
public final class ArMeasureActivity extends Activity {
 private Session session;
 private GLSurfaceView surface;
 private MeasureScene renderer;
 private TextView status,distance;
 private Button use;
 private String category,lastStatus="";
 private boolean installRequested=false,permissionRequested=false,running=false;
 private volatile boolean confirming=false;
 private volatile float currentCm=Float.NaN;
 private volatile long lastTrackedAt=0;
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  category=getIntent().getStringExtra("category");if(category==null||category.length()<1||category.length()>40){finish();return;}
  FrameLayout root=new FrameLayout(this);setContentView(root);root.setBackgroundColor(Color.BLACK);
  root.setOnApplyWindowInsetsListener((v,insets)->{if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets b=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());v.setPadding(b.left,b.top,b.right,b.bottom);}else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
  surface=new GLSurfaceView(this);surface.setEGLContextClientVersion(2);surface.setPreserveEGLContextOnPause(true);surface.setEGLConfigChooser(8,8,8,8,16,0);renderer=new MeasureScene();surface.setRenderer(renderer);root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
  surface.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP&&!confirming)renderer.tap=new PointF(e.getX(),e.getY());return true;});
  LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.VERTICAL);top.setPadding(dp(16),dp(12),dp(16),dp(12));top.setBackgroundColor(0xeb203c32);
  TextView title=new TextView(this);title.setText(category+" 놓을 자리의 폭 재기");title.setTextSize(19);title.setTextColor(Color.WHITE);top.addView(title);
  status=new TextView(this);status.setText("바닥을 천천히 비춰 인식해주세요.");status.setTextSize(14);status.setTextColor(0xffe4eed9);top.addView(status);
  TextView help=new TextView(this);help.setText("같은 바닥의 시작점과 끝점을 차례로 터치하세요.\n책상 위가 아닌 실제 바닥을 선택해주세요.");help.setTextSize(12);help.setTextColor(Color.WHITE);top.addView(help);root.addView(top,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));
  LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);bottom.setPadding(dp(16),dp(12),dp(16),dp(12));bottom.setBackgroundColor(0xf5f7f6f1);
  distance=new TextView(this);distance.setText("시작점 → 끝점");distance.setTextSize(30);distance.setTextColor(0xff245e48);bottom.addView(distance);
  TextView note=new TextView(this);note.setText("가로 폭만 확인해요. AR 오차가 있으니 줄자로 재확인하고 필요하면 수정하세요. 여유 공간은 기본 5cm예요.");note.setTextSize(12);note.setTextColor(0xff586658);bottom.addView(note);
  LinearLayout buttons=new LinearLayout(this);Button reset=new Button(this);reset.setText("다시 재기");buttons.addView(reset,new LinearLayout.LayoutParams(0,dp(50),1));reset.setOnClickListener(v->{if(!confirming)surface.queueEvent(()->renderer.clear());});
  use=new Button(this);use.setText("이 폭으로 추천하기");use.setEnabled(false);buttons.addView(use,new LinearLayout.LayoutParams(0,dp(50),2));use.setOnClickListener(v->confirmWidth());bottom.addView(buttons);root.addView(bottom,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
 }
 private void showState(String text,float cm){currentCm=cm;boolean ready=Float.isFinite(cm);String state=text+":"+(ready?String.format(Locale.US,"%.1f",cm):"?");if(state.equals(lastStatus))return;lastStatus=state;runOnUiThread(()->{status.setText(text);distance.setText(ready?String.format(Locale.KOREA,"%.1f cm",cm):"시작점 → 끝점");use.setEnabled(ready&&!confirming);});}
 private void confirmWidth(){float measured=currentCm;if(confirming||!Float.isFinite(measured)||android.os.SystemClock.elapsedRealtime()-lastTrackedAt>1500){Toast.makeText(this,"두 지점이 다시 인식될 때까지 기다려주세요.",Toast.LENGTH_SHORT).show();return;}confirming=true;use.setEnabled(false);
  LinearLayout fields=new LinearLayout(this);fields.setOrientation(LinearLayout.VERTICAL);fields.setPadding(dp(16),0,dp(16),0);
  TextView first=new TextView(this);first.setText("자리 폭 (cm) · 줄자로 확인한 값으로 수정 가능");fields.addView(first);EditText width=new EditText(this);width.setInputType(8194);width.setText(String.format(Locale.US,"%.1f",measured));fields.addView(width);
  TextView second=new TextView(this);second.setText("남겨둘 여유 공간 (cm)");fields.addView(second);EditText margin=new EditText(this);margin.setInputType(8194);margin.setText("5");fields.addView(margin);
  TextView hint=new TextView(this);hint.setText("추천 가능한 가구 가로 폭 = 자리 폭 − 여유 공간\n깊이·높이·문 열림은 따로 확인해주세요.");fields.addView(hint);
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("측정값 확인 · "+category).setView(fields).setNegativeButton("돌아가기",null).setPositiveButton("추천에 적용",null).create();
  dialog.setOnDismissListener(d->{confirming=false;lastStatus="";});dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{float w=Float.parseFloat(width.getText().toString()),m=Float.parseFloat(margin.getText().toString());if(!FloorMeasure.validInput(w,m))throw new Exception();JSONObject result=new JSONObject();result.put("version",1);result.put("category",category);result.put("widthCm",Math.round(w*10)/10.0);result.put("marginCm",Math.round(m*10)/10.0);result.put("measuredCm",Math.round(measured*10)/10.0);result.put("source",Math.abs(w-Math.round(measured*10)/10f)>.051f?"ar-corrected":"ar");result.put("capturedAt",System.currentTimeMillis());setResult(RESULT_OK,new Intent().putExtra("measurement",result.toString()));dialog.dismiss();finish();}catch(Exception ex){width.setError("폭 10~1000cm, 여유 0~100cm를 확인하세요.");}}));dialog.show();
 }
 @Override protected void onResume(){super.onResume();if(surface==null)return;if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){if(!permissionRequested){permissionRequested=true;requestPermissions(new String[]{Manifest.permission.CAMERA},42);}return;}
  try{if(session==null){if(ArCoreApk.getInstance().requestInstall(this,!installRequested)==ArCoreApk.InstallStatus.INSTALL_REQUESTED){installRequested=true;return;}session=new Session(this);Config c=new Config(session);c.setPlaneFindingMode(Config.PlaneFindingMode.HORIZONTAL);session.configure(c);}session.resume();surface.onResume();running=true;}
  catch(Exception ex){new AlertDialog.Builder(this).setTitle("AR 측정을 시작하지 못했어요").setMessage(ex.getClass().getSimpleName()+"\n카메라·AR 서비스를 확인하거나 이전 화면에서 폭을 직접 입력해주세요.").setPositiveButton("돌아가기",(d,w)->finish()).setOnCancelListener(d->finish()).show();}
 }
 @Override public void onRequestPermissionsResult(int code,String[] p,int[] r){super.onRequestPermissionsResult(code,p,r);if(code==42){if(r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)recreate();else new AlertDialog.Builder(this).setMessage("AR 측정에는 카메라 권한이 필요해요. 이전 화면에서 직접 입력할 수도 있어요.").setPositiveButton("돌아가기",(d,w)->finish()).setOnCancelListener(d->finish()).show();}}
 @Override protected void onPause(){currentCm=Float.NaN;lastTrackedAt=0;if(running){surface.onPause();running=false;}if(session!=null)session.pause();super.onPause();}
 @Override protected void onDestroy(){if(session!=null){renderer.clear();session.close();session=null;}super.onDestroy();}
 private static Plane rootPlane(Plane p){for(int i=0;i<20&&p.getSubsumedBy()!=null;i++)p=p.getSubsumedBy();return p;}
 private final class MeasureScene implements GLSurfaceView.Renderer {
  private Anchor start,end;private Plane floor;
  private int texture,bg,marks,w=1,h=1;private FloatBuffer quad,uv;private volatile PointF tap;
  private final float[] view=new float[16],proj=new float[16],pv=new float[16];
  void clear(){if(start!=null)start.detach();if(end!=null)end.detach();start=end=null;floor=null;tap=null;showState("바닥의 시작점을 터치하세요.",Float.NaN);}
  @Override public void onSurfaceCreated(GL10 gl,EGLConfig config){GLES20.glClearColor(.08f,.1f,.08f,1);int[] a=new int[1];GLES20.glGenTextures(1,a,0);texture=a[0];GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
   bg=program("attribute vec2 aPosition;attribute vec2 aUv;varying vec2 vUv;void main(){gl_Position=vec4(aPosition,0.,1.);vUv=aUv;}","#extension GL_OES_EGL_image_external : require\nprecision mediump float;uniform samplerExternalOES uCamera;varying vec2 vUv;void main(){gl_FragColor=texture2D(uCamera,vUv);}");
   marks=program("attribute vec3 aPosition;uniform mat4 uPv;uniform float uSize;void main(){gl_Position=uPv*vec4(aPosition,1.);gl_PointSize=uSize;}","precision mediump float;uniform vec4 uColor;void main(){gl_FragColor=uColor;}");quad=buf(new float[]{-1,-1,1,-1,-1,1,1,1});uv=buf(new float[8]);
  }
  @Override public void onSurfaceChanged(GL10 gl,int width,int height){w=width;h=height;GLES20.glViewport(0,0,w,h);}
  @Override public void onDrawFrame(GL10 gl){GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);Session active=session;if(active==null)return;try{active.setDisplayGeometry(getWindowManager().getDefaultDisplay().getRotation(),w,h);active.setCameraTextureName(texture);Frame frame=active.update();if(frame.getTimestamp()==0)return;drawBackground(frame);Camera camera=frame.getCamera();if(camera.getTrackingState()!=TrackingState.TRACKING){tap=null;showState("인식이 잠시 끊겼어요. 바닥을 천천히 비춰주세요.",Float.NaN);return;}
   camera.getViewMatrix(view,0);camera.getProjectionMatrix(proj,0,.05f,30);Matrix.multiplyMM(pv,0,proj,0,view,0);
   if(start!=null&&start.getTrackingState()==TrackingState.STOPPED||end!=null&&end.getTrackingState()==TrackingState.STOPPED)clear();
   PointF point=tap;tap=null;if(point!=null&&!confirming){if(start!=null&&end!=null){ToastMessage("다른 폭을 재려면 다시 재기를 눌러주세요.");}else accept(frame,point);}
   if(start==null){showState("① 바닥의 시작점을 터치하세요.",Float.NaN);return;}
   if(start.getTrackingState()!=TrackingState.TRACKING||end!=null&&end.getTrackingState()!=TrackingState.TRACKING){showState("측정 지점을 다시 비춰주세요.",Float.NaN);return;}
   Pose a=start.getPose();drawPoints(new float[]{a.tx(),a.ty()+.012f,a.tz()},GLES20.GL_POINTS,1,22,1,.9f,.4f);
   if(end==null){showState("② 같은 바닥의 끝점을 터치하세요.",Float.NaN);return;}
   Pose b=end.getPose();float cm=FloorMeasure.distanceCm(a.tx(),a.ty(),a.tz(),b.tx(),b.ty(),b.tz());if(!Float.isFinite(cm)){showState("같은 바닥에서 10~1000cm 폭을 다시 재주세요.",Float.NaN);return;}
   float dx=b.tx()-a.tx(),dz=b.tz()-a.tz(),len=cm/100,nx=-dz/len*.008f,nz=dx/len*.008f,y=(a.ty()+b.ty())/2+.01f;
   drawPoints(new float[]{a.tx()+nx,y,a.tz()+nz,a.tx()-nx,y,a.tz()-nz,b.tx()+nx,y,b.tz()+nz,b.tx()-nx,y,b.tz()-nz},GLES20.GL_TRIANGLE_STRIP,4,1,.4f,.95f,.65f);drawPoints(new float[]{b.tx(),b.ty()+.012f,b.tz()},GLES20.GL_POINTS,1,22,1,.9f,.4f);lastTrackedAt=android.os.SystemClock.elapsedRealtime();showState("측정 완료 · 확인하고 추천에 적용하세요.",cm);
  }catch(Exception ex){tap=null;showState("AR 상태를 확인 중이에요 · "+ex.getClass().getSimpleName(),Float.NaN);}}
  private void accept(Frame f,PointF p){for(HitResult hit:f.hitTest(p.x,p.y)){Trackable t=hit.getTrackable();if(!(t instanceof Plane))continue;Plane plane=(Plane)t;if(plane.getType()!=Plane.Type.HORIZONTAL_UPWARD_FACING||!plane.isPoseInPolygon(hit.getHitPose()))continue;
    if(start==null){Anchor a=hit.createAnchor();start=a;floor=plane;return;}
    if(start.getTrackingState()!=TrackingState.TRACKING){ToastMessage("시작점을 다시 비춰주세요.");return;}
    if(!rootPlane(floor).equals(rootPlane(plane))){ToastMessage("시작점과 같은 바닥 영역을 선택해주세요.");return;}
    Pose a=start.getPose(),b=hit.getHitPose();if(!Float.isFinite(FloorMeasure.distanceCm(a.tx(),a.ty(),a.tz(),b.tx(),b.ty(),b.tz()))){ToastMessage("같은 바닥에서 10~1000cm 떨어진 끝점을 선택해주세요.");return;}end=hit.createAnchor();return;
   }ToastMessage("아직 바닥을 찾지 못했어요. 천천히 움직여주세요.");}
  private void drawBackground(Frame f){quad.position(0);uv.position(0);f.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,quad,Coordinates2d.TEXTURE_NORMALIZED,uv);quad.position(0);uv.position(0);GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glUseProgram(bg);int p=GLES20.glGetAttribLocation(bg,"aPosition"),u=GLES20.glGetAttribLocation(bg,"aUv");GLES20.glEnableVertexAttribArray(p);GLES20.glEnableVertexAttribArray(u);GLES20.glVertexAttribPointer(p,2,GLES20.GL_FLOAT,false,0,quad);GLES20.glVertexAttribPointer(u,2,GLES20.GL_FLOAT,false,0,uv);GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glUniform1i(GLES20.glGetUniformLocation(bg,"uCamera"),0);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glDisableVertexAttribArray(p);GLES20.glDisableVertexAttribArray(u);}
  private void drawPoints(float[] points,int mode,int count,float size,float r,float g,float b){GLES20.glUseProgram(marks);int p=GLES20.glGetAttribLocation(marks,"aPosition");GLES20.glEnableVertexAttribArray(p);GLES20.glVertexAttribPointer(p,3,GLES20.GL_FLOAT,false,0,buf(points));GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(marks,"uPv"),1,false,pv,0);GLES20.glUniform1f(GLES20.glGetUniformLocation(marks,"uSize"),size);GLES20.glUniform4f(GLES20.glGetUniformLocation(marks,"uColor"),r,g,b,1);GLES20.glDrawArrays(mode,0,count);GLES20.glDisableVertexAttribArray(p);}
 }
 private void ToastMessage(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
 private static FloatBuffer buf(float[] x){FloatBuffer b=ByteBuffer.allocateDirect(x.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(x).position(0);return b;}
 private static int shader(int type,String s){int p=GLES20.glCreateShader(type);GLES20.glShaderSource(p,s);GLES20.glCompileShader(p);int[] okay={0};GLES20.glGetShaderiv(p,GLES20.GL_COMPILE_STATUS,okay,0);if(okay[0]==0)throw new IllegalStateException(GLES20.glGetShaderInfoLog(p));return p;}
 private static int program(String v,String f){int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,v));GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,f));GLES20.glLinkProgram(p);int[] okay={0};GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,okay,0);if(okay[0]==0)throw new IllegalStateException(GLES20.glGetProgramInfoLog(p));return p;}
}
