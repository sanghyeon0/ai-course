package kr.ac.roomfit.app;

/** Guidance from camera motion, observed floor and valid depth frames.
 * These counters are NOT a percentage of the physical room scanned.
 * This class does not claim complete obstacle coverage.
 */
public final class RoomScanGuide {
    private int directionMask = 0;
    private int floorSamples = 0;
    private int depthSamples = 0;

    public void observe(float cameraForwardX, float cameraForwardZ, boolean floor, boolean depth) {
        if (!Float.isFinite(cameraForwardX) || !Float.isFinite(cameraForwardZ)) return;
        float radians = (float) Math.atan2(cameraForwardX, cameraForwardZ);
        int sector = (int) Math.floor(((radians + Math.PI) / (Math.PI * 2)) * 8) % 8;
        if (sector < 0) sector += 8;
        directionMask |= (1 << sector);
        if (floor) floorSamples = Math.min(1000, floorSamples + 1);
        if (depth) depthSamples = Math.min(1000, depthSamples + 1);
    }
    public int directions() { return Integer.bitCount(directionMask); }
    public int floorSamples() { return floorSamples; }
    public int depthSamples() { return depthSamples; }
    public boolean hasEnoughForSearch() { return directions() >= 2 && floorSamples >= 2 && depthSamples >= 3; }
    public String guidance(boolean depthSupported) {
        if (!depthSupported) return "Depth 미지원 · 실제 장애물 자동 검사 불가";
        if (floorSamples < 2) return "바닥을 천천히 비춰 수평면을 찾으세요";
        if (directions() < 2) return "좌우로 카메라를 움직여 다른 각도도 비춰주세요";
        if (depthSamples < 3) return "거리 정보가 부족합니다 · 밝은 곳에서 카메라를 천천히 움직이세요";
        return "관찰한 영역에서 빈 위치를 탐색할 수 있습니다";
    }
    public String countText() { return "관찰 방향 " + directions() + "/8 · 바닥 " + floorSamples + "회 · 거리 " + depthSamples + "회 (방 전체 스캔률 아님)"; }
}
