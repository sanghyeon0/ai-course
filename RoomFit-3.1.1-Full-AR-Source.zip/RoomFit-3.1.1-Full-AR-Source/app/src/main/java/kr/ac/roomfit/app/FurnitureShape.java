package kr.ac.roomfit.app;
import java.util.ArrayList;
import java.util.List;
/** Original schematic furniture; centimetres in the catalogue, metres in AR. */
final class FurnitureShape {
 static final class Part {final float w,h,d,x,y,z;final int material;Part(float w,float h,float d,float x,float y,float z,int m){this.w=w;this.h=h;this.d=d;this.x=x;this.y=y;this.z=z;material=m;}}
 static List<Part> parts(String kind,float w,float d,float h){List<Part>a=new ArrayList<>();float t=Math.min(.035f,Math.min(h/12,Math.min(w/10,d/10))),leg=Math.min(.045f,Math.min(w/8,d/8));
  if(kind.equals("desk")||kind.equals("table")){add(a,w,t,d,0,h-t/2,0,0);for(int x:new int[]{-1,1})for(int z:new int[]{-1,1})add(a,leg,h-t,leg,x*(w/2-leg),(h-t)/2,z*(d/2-leg),2);}
  else if(kind.equals("chair")){float seat=h*.45f,st=h*.06f;add(a,w,st,d,0,seat,0,1);add(a,w,h-seat-st/2,t,0,(h+seat+st/2)/2,-d/2+t/2,1);for(int x:new int[]{-1,1})for(int z:new int[]{-1,1})add(a,leg,seat-st/2,leg,x*(w/2-leg),(seat-st/2)/2,z*(d/2-leg),2);}
  else if(kind.equals("bed")){add(a,w,h*.25f,d,0,h*.225f,0,0);add(a,w*.96f,h*.25f,d*.94f,0,h*.475f,d*.015f,1);add(a,w,h,t,0,h/2,-d/2+t/2,0);for(int x:new int[]{-1,1})for(int z:new int[]{-1,1})add(a,leg,h*.1f,leg,x*(w/2-leg),h*.05f,z*(d/2-leg),2);}
  else if(kind.equals("storage")){add(a,t,h,d,-w/2+t/2,h/2,0,0);add(a,t,h,d,w/2-t/2,h/2,0,0);add(a,w,h,t,0,h/2,-d/2+t/2,0);for(int i=0;i<=3;i++)add(a,Math.max(.005f,w-2*t),t,Math.max(.005f,d-t),0,t/2+(h-t)*i/3,t/2,0);}
  else if(kind.equals("lamp")){add(a,w,h*.04f,d,0,h*.02f,0,2);add(a,Math.min(w*.12f,.04f),h*.8f,Math.min(d*.12f,.04f),0,h*.44f,0,2);add(a,w*.85f,h*.2f,d*.85f,0,h*.9f,0,1);}
  else add(a,w,h,d,0,h/2,0,kind.equals("rug")?1:0);return a;
 }
 private static void add(List<Part>a,float w,float h,float d,float x,float y,float z,int m){a.add(new Part(w,h,d,x,y,z,m));}
}
