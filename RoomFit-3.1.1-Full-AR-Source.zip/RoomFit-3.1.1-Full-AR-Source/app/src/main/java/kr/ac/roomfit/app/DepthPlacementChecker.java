package kr.ac.roomfit.app;

import android.media.Image;
import com.google.ar.core.Camera;
import com.google.ar.core.Coordinates2d;
import com.google.ar.core.Frame;
import com.google.ar.core.Pose;
import com.google.ar.core.exceptions.NotYetAvailableException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Samples a depth map as world-space points and checks the volume above a floor hit pose.
 *  Does NOT detect hidden objects, identify furniture categories, or reconstruct the complete room.
 *  Must run on the AR GL thread, while the current frame is valid. Always close the depth image.
 */
public final class DepthPlacementChecker {
    public static final class Result {
        public final ObstacleMath.Verdict verdict;
        public final int observed, obstructions;
        Result(ObstacleMath.Verdict v, int a, int b){verdict=v;observed=a;obstructions=b;}
        public String message(){switch(verdict){
            case BLOCKED:return "🔴 감지한 장애물과 겹칠 가능성이 높아요. 다른 위치를 선택하세요.";
            case CLEAR:return "🟢 현재 카메라에 보이는 공간에서는 큰 장애물이 감지되지 않았어요.";
            case UNSUPPORTED:return "🟠 이 휴대폰은 Depth API를 지원하지 않아 자동 장애물 검사가 불가능합니다.";
            default:return "🟠 공간 정보가 부족해요. 방을 천천히 여러 방향에서 비춰주세요.";
        }}
    }
    /** Probe only a few pixels: this indicates current depth availability, not room coverage. */
    public static boolean hasUsableDepth(Frame frame){
        Image image=null;
        try{
            image=frame.acquireDepthImage16Bits();
            Image.Plane plane=image.getPlanes()[0];
            ByteBuffer b=plane.getBuffer().order(ByteOrder.nativeOrder());
            int good=0;
            for(int y=1;y<=5;y++)for(int x=1;x<=5;x++){
                int xx=image.getWidth()*x/6, yy=image.getHeight()*y/6;
                int pos=yy*plane.getRowStride()+xx*plane.getPixelStride();
                if(pos<0||pos+1>=b.limit())continue;
                int mm=b.getShort(pos)&0xffff;
                if(mm>=250&&mm<=8000)good++;
            }
            return good>=4;
        }catch(NotYetAvailableException|RuntimeException ignored){return false;}
        finally{if(image!=null)image.close();}
    }
    public static Result unsupported(){return new Result(ObstacleMath.Verdict.UNSUPPORTED,0,0);}
    public static Result inspect(Frame frame,Camera camera,Pose floorPose,float width,float depth,float height,int viewportWidth,int viewportHeight){
        Image image=null;
        try{
            image=frame.acquireDepthImage16Bits();
            final Image.Plane plane=image.getPlanes()[0];
            ByteBuffer pixels=plane.getBuffer().order(ByteOrder.nativeOrder());
            int imgW=image.getWidth(),imgH=image.getHeight();
            Pose inverse=floorPose.inverse(),cameraPose=camera.getPose();
            float[] projection=new float[16];camera.getProjectionMatrix(projection,0,.05f,30f);
            // Per ARCore docs depth values represent camera-axis Z, not 3D ray length.
            int observed=0,blocked=0;
            final int stepsX=32,stepsY=24;
            float[] textureCoords=new float[stepsX*stepsY*2];
            for(int y=0;y<stepsY;y++)for(int x=0;x<stepsX;x++){
                int i=(y*stepsX+x)*2;
                textureCoords[i]=(x+.5f)/stepsX;
                textureCoords[i+1]=(y+.5f)/stepsY;
            }
            float[] ndc=new float[textureCoords.length];
            frame.transformCoordinates2d(Coordinates2d.TEXTURE_NORMALIZED,textureCoords,Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,ndc);
            for(int i=0;i<textureCoords.length;i+=2){
                int px=Math.min(imgW-1,Math.max(0,(int)(textureCoords[i]*imgW)));
                int py=Math.min(imgH-1,Math.max(0,(int)(textureCoords[i+1]*imgH)));
                int at=px*plane.getPixelStride()+py*plane.getRowStride();
                if(at<0||at+1>=pixels.limit())continue;
                int mm=pixels.getShort(at)&0xffff;
                if(mm<200||mm>8000)continue;
                float d=mm/1000f;
                // OpenGL projection: ndc.x = m00*(x/d) - m[8] (camera looks down -Z).
                float rx=(ndc[i]+projection[8])/projection[0]*d;
                float ry=(ndc[i+1]+projection[9])/projection[5]*d;
                float[] world=cameraPose.transformPoint(new float[]{rx,ry,-d});
                float[] relative=inverse.transformPoint(world);
                if(Math.abs(relative[0])>width/2+.07f||Math.abs(relative[2])>depth/2+.07f)continue;
                observed++;
                if(ObstacleMath.inside(relative[0],relative[1],relative[2],width,depth,height))blocked++;
            }
            return new Result(ObstacleMath.classify(observed,blocked),observed,blocked);
        }catch(NotYetAvailableException e){return new Result(ObstacleMath.Verdict.UNKNOWN,0,0);}
         catch(RuntimeException e){return new Result(ObstacleMath.Verdict.UNKNOWN,0,0);}
        finally{if(image!=null)image.close();}
    }
}
