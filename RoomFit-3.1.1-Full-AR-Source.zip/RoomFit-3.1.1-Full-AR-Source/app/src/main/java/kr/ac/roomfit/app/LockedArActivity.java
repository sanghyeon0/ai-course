package kr.ac.roomfit.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PointF;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import com.google.ar.core.*;
import org.json.*;
import java.io.*;
import java.nio.*;
import java.util.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Own ARCore scene. Saves an authoritative framebuffer capture before the optional web AI edit. */
public final class LockedArActivity extends Activity {
    private Session session;
    private GLSurfaceView surface;
    private Scene renderer;
    private TextView status, dimensions, scanNote;
    private Button capture, suggestButton, applySuggestion;
    private boolean installRequested=false,surfaceRunning=false,permissionRequested=false;
    private JSONObject request;
    private boolean roomfit2Mode=false,roomfit3Mode=false,depthSupported=false;
    private volatile float groupYaw=0,groupX=0,groupZ=0;
    private final ArrayList<Item> items=new ArrayList<>();
    private String lastStatus="";
    private boolean lastReady=false;
    private ProductAssetStore assetStore;
    private final float[] gain={1,1,1};
    private final float[][] colors={{.65f,.45f,.26f},{.77f,.8f,.7f},{.16f,.2f,.18f}};
    static final String[] KINDS={"desk","chair","bed","storage","table","lamp","rug","box"};
    static final class Item {
        final JSONObject product; final String kind,name; float width,depth,height,yaw=0,dx=0,dz=0; Anchor anchor; ProductAssetStore.Entry entry; GlbRenderer mesh; boolean modelFailed=false;
        Item(JSONObject p)throws JSONException {product=new JSONObject(p.toString());kind=p.getString("kind");name=p.getString("name");width=(float)p.getDouble("width")/100;depth=(float)p.getDouble("depth")/100;height=(float)p.getDouble("height")/100;dx=(float)p.optDouble("x",0);dz=(float)p.optDouble("z",0);yaw=(float)p.optDouble("rotation",0);}
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        try{String raw=getIntent().getStringExtra("scene");if(raw==null||raw.length()>32000)throw new Exception();request=new JSONObject(raw);roomfit2Mode=request.optBoolean("roomfit2",false);roomfit3Mode=request.optBoolean("roomfit3",false);JSONArray products=request.getJSONArray("items");if(products.length()<1||products.length()>12)throw new Exception();
            try{assetStore=new ProductAssetStore(this);}catch(Exception ignored){}
            for(int i=0;i<products.length();i++){JSONObject p=products.getJSONObject(i);Item x=new Item(p);if(!Arrays.asList(KINDS).contains(x.kind)||x.name.length()>160||!size(x.width)||!size(x.depth)||!size(x.height))throw new Exception();try{if(assetStore!=null)x.entry=assetStore.load(p.optString("id"));}catch(Exception ex){x.modelFailed=true;}if(x.entry!=null){x.width=x.entry.model.width();x.depth=x.entry.model.depth();x.height=x.entry.model.height();x.product.put("modelSource",x.entry.type);x.product.put("modelAsset",x.entry.key);x.product.put("modelLabel",x.entry.label);x.product.put("estimated",false);x.product.put("heightEstimated",false);}else{x.product.put("modelSource","schematic");x.product.put("modelLabel",x.modelFailed?"파일 오류 · 단순 모형":"크기 참고용 단순 모형");}items.add(x);}
            JSONObject style=request.getJSONObject("style");String[] roles={"surface","fabric","frame"};for(int i=0;i<3;i++){JSONArray rgb=style.getJSONArray(roles[i]);for(int j=0;j<3;j++)colors[i][j]=clamp((float)rgb.getDouble(j),.05f,.95f);}JSONArray rgb=style.getJSONArray("gain");for(int j=0;j<3;j++)gain[j]=clamp((float)rgb.getDouble(j),.9f,1.1f);
        }catch(Exception ex){new AlertDialog.Builder(this).setMessage("추천 가구 정보를 다시 선택해주세요.").setPositiveButton("닫기",(d,w)->finish()).setOnCancelListener(d->finish()).show();return;}
        FrameLayout root=new FrameLayout(this);setContentView(root);root.setBackgroundColor(Color.BLACK);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        surface=new GLSurfaceView(this);surface.setEGLContextClientVersion(2);surface.setPreserveEGLContextOnPause(true);surface.setEGLConfigChooser(8,8,8,8,16,0);renderer=new Scene();surface.setRenderer(renderer);root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        surface.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP){renderer.tap=new PointF(e.getX(),e.getY());return true;}return true;});
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.VERTICAL);top.setPadding(16,12,16,12);top.setBackgroundColor(0xde203c32);
        TextView title=new TextView(this);title.setText(roomfit3Mode?"룸핏 3.1 · 스마트 AR 배치":roomfit2Mode?"룸핏 2.7 · 전체 가구 AR 배치":"가구 배치 → 저장 → AI 결과 사진");title.setTextColor(Color.WHITE);title.setTextSize(17);top.addView(title);
        status=new TextView(this);status.setText("카메라 권한을 확인하고 있어요.");status.setTextColor(0xffddebd2);status.setTextSize(12);top.addView(status);
        TextView help=new TextView(this);help.setText(roomfit3Mode?"방을 여러 방향에서 비춰 Depth 정보를 확보하세요. 가구를 선택하고 바닥을 터치하면 장애물 겹침을 점검합니다. 카메라 사각지대는 검사할 수 없습니다.":roomfit2Mode?"바닥을 비추고 기준점 한 곳을 터치하세요.\n3D의 가구가 함께 나타납니다. 기존 가구 충돌·통로 검사는 앱에 직접 입력한 정보 기준이며 카메라 자동 인식이 아닙니다. 직접 확인하세요.":"바닥을 천천히 비추고 터치 → 가구별 배치 · 크기 고정\n상품 참고 제작 모델과 단순 모형이 섞여 있어요. 실물과 차이가 있을 수 있어요.");help.setTextColor(0xfff5f3db);help.setTextSize(10);top.addView(help);
        if(roomfit3Mode){scanNote=new TextView(this);scanNote.setText("바닥과 거리 정보 탐색 준비 중");scanNote.setTextColor(0xffdbeedb);scanNote.setTextSize(11);top.addView(scanNote);}
        root.addView(top,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);bottom.setPadding(12,8,12,10);bottom.setBackgroundColor(0xeef7f6f1);
        Spinner picker=new Spinner(this);ArrayList<String> labels=new ArrayList<>();for(Item x:items)labels.add((x.entry!=null?"[상품 참고] ":"[단순 모형] ")+x.name);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);picker.setAdapter(adapter);bottom.addView(picker);picker.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?>p){}public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){if(roomfit3Mode){surface.queueEvent(()->renderer.selectItem(pos));updateDimension(pos);}else renderer.selected=pos;}});
        if(roomfit3Mode){dimensions=new TextView(this);dimensions.setTextColor(0xff28523e);dimensions.setTextSize(13);dimensions.setPadding(dp(4),dp(4),dp(4),dp(9));bottom.addView(dimensions);updateDimension(0);}
        LinearLayout tools=new LinearLayout(this);addButton(tools,"↶ 15°",()->surface.queueEvent(()->renderer.rotateSelected(-15)));addButton(tools,"15° ↷",()->surface.queueEvent(()->renderer.rotateSelected(15)));if(!roomfit3Mode)addButton(tools,"치수 확인",this::editSize);if(!roomfit2Mode)addButton(tools,"선택 삭제",()->surface.queueEvent(()->{Item x=items.get(renderer.selected);if(x.anchor!=null)x.anchor.detach();x.anchor=null;x.dx=x.dz=0;}));bottom.addView(tools);
        LinearLayout move=new LinearLayout(this);addButton(move,"← 5cm",()->nudge(-.05f,0));addButton(move,"앞 5cm",()->nudge(0,-.05f));addButton(move,"뒤 5cm",()->nudge(0,.05f));addButton(move,"5cm →",()->nudge(.05f,0));bottom.addView(move);
        if(roomfit3Mode){
            LinearLayout suggestions=new LinearLayout(this);
            suggestButton=new Button(this);suggestButton.setText("🔎 빈 위치 찾기");suggestButton.setTextSize(12);suggestions.addView(suggestButton,new LinearLayout.LayoutParams(0,dp(44),1));
            applySuggestion=new Button(this);applySuggestion.setText("✓ 추천 위치에 배치");applySuggestion.setTextSize(12);applySuggestion.setEnabled(false);suggestions.addView(applySuggestion,new LinearLayout.LayoutParams(0,dp(44),1));
            suggestButton.setOnClickListener(v->{applySuggestion.setEnabled(false);surface.queueEvent(()->renderer.startSearch());});
            applySuggestion.setOnClickListener(v->{applySuggestion.setEnabled(false);surface.queueEvent(()->renderer.applySuggested=true);});
            bottom.addView(suggestions);
        }
        if(roomfit2Mode){
            LinearLayout align=new LinearLayout(this);
            addButton(align,"전체 ↶ 15°",()->surface.queueEvent(()->groupYaw-=15));
            addButton(align,"전체 15° ↷",()->surface.queueEvent(()->groupYaw+=15));
            addButton(align,"전체 ← 10cm",()->surface.queueEvent(()->groupX=clamp(groupX-.1f,-2,2)));
            addButton(align,"전체 10cm →",()->surface.queueEvent(()->groupX=clamp(groupX+.1f,-2,2)));
            bottom.addView(align);
            LinearLayout align2=new LinearLayout(this);
            addButton(align2,"전체 앞 10cm",()->surface.queueEvent(()->groupZ=clamp(groupZ-.1f,-2,2)));
            addButton(align2,"전체 뒤 10cm",()->surface.queueEvent(()->groupZ=clamp(groupZ+.1f,-2,2)));
            addButton(align2,"위치 초기화",()->surface.queueEvent(()->{groupYaw=groupX=groupZ=0;}));
            bottom.addView(align2);
        }
        TextView styleNote=new TextView(this);styleNote.setText(roomfit3Mode?"가구 선택 → 바닥 터치로 놓기·이동, 방향 버튼으로 15° 회전, 화살표로 5cm 이동, 빈 위치 찾기로 후보 탐색. 위험·불확실한 이동은 차단합니다. 감지 범위 밖은 반드시 직접 확인하세요.":roomfit2Mode?"전체 회전·이동으로 방과 정렬하세요. 다시 바닥을 터치하면 기준점이 변경됩니다. 실측 정확도를 보장하지 않습니다.":request.optJSONObject("style").optString("title","선택한 스타일")+" · "+("ai".equals(request.optJSONObject("style").optString("source"))?"AI 배경 톤 적용":"기본 배경 톤")+" · 촬영본 저장 후 AI 이미지 생성(비용 발생) · 배치 오차 가능");styleNote.setTextColor(0xff697c5f);styleNote.setTextSize(10);bottom.addView(styleNote);
        capture=new Button(this);capture.setText((roomfit3Mode||roomfit2Mode)?"AR 배치 사진 저장":"배치 저장·촬영 후 AI 결과 만들기");capture.setEnabled(false);capture.setOnClickListener(v->{capture.setEnabled(false);renderer.captureRequested=true;});bottom.addView(capture);
        android.widget.ScrollView scrollControls=new android.widget.ScrollView(this);scrollControls.setFillViewport(false);scrollControls.setVerticalScrollBarEnabled(true);scrollControls.setBackgroundColor(0xeef7f6f1);scrollControls.addView(bottom);FrameLayout.LayoutParams controlsLayout=new FrameLayout.LayoutParams(-1,dp(240),Gravity.BOTTOM);root.addView(scrollControls,controlsLayout);
    }
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private static boolean size(float x){return Float.isFinite(x)&&x>=.01f&&x<=6;}
    private static float clamp(float x,float lo,float hi){return Float.isFinite(x)?Math.max(lo,Math.min(hi,x)):lo;}
    private void addButton(LinearLayout row,String title,Runnable action){Button b=new Button(this);b.setText(title);b.setTextSize(10);b.setMinWidth(0);b.setPadding(2,0,2,0);row.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));b.setOnClickListener(v->action.run());}
    private void nudge(float x,float z){surface.queueEvent(()->renderer.moveSelected(x,z));}
    private void updateDimension(int index){if(dimensions==null||index<0||index>=items.size())return;Item it=items.get(index);dimensions.setText(String.format(java.util.Locale.KOREA,"선택 가구: %s  ·  가로 %.0f × 깊이 %.0f × 높이 %.0f cm\n등록 모델 치수 기준이며 실측 오차가 있을 수 있습니다.",it.name,it.width*100,it.depth*100,it.height*100));}
    private void editSize(){final int index=renderer.selected;final Item it=items.get(index);if(it.entry!=null&&it.mesh!=null){editUniformSize(it);return;}LinearLayout fields=new LinearLayout(this);fields.setOrientation(LinearLayout.VERTICAL);final EditText[] input=new EditText[3];String[] titles={"가로 cm","깊이 cm","높이 cm"};float[] values={it.width,it.depth,it.height};for(int i=0;i<3;i++){TextView label=new TextView(this);label.setText(titles[i]);fields.addView(label);input[i]=new EditText(this);input[i].setInputType(8194);input[i].setText(String.format(java.util.Locale.US,"%.1f",values[i]*100));fields.addView(input[i]);}new AlertDialog.Builder(this).setTitle("판매처·실측 치수로 수정").setView(fields).setNegativeButton("취소",null).setPositiveButton("적용",(d,w)->{try{float a=Float.parseFloat(input[0].getText().toString())/100,b=Float.parseFloat(input[1].getText().toString())/100,c=Float.parseFloat(input[2].getText().toString())/100;if(!size(a)||!size(b)||!size(c))throw new Exception();surface.queueEvent(()->{it.width=a;it.depth=b;it.height=c;try{it.product.put("estimated",false);it.product.put("heightEstimated",false);it.product.put("manualSize",true);}catch(Exception ignored){}});}catch(Exception ex){Toast.makeText(this,"1~600cm 사이 값을 입력해주세요.",Toast.LENGTH_SHORT).show();}}).show();}
    private void editUniformSize(final Item it){final EditText input=new EditText(this);input.setInputType(8194);input.setText(String.format(java.util.Locale.US,"%.1f",it.width*100));new AlertDialog.Builder(this).setTitle("비율을 유지하며 크기 보정").setMessage("가로 폭(cm)을 바꾸면 깊이와 높이도 같은 비율로 바뀝니다. 등록 상품의 실제 치수와 달라질 수 있어요.").setView(input).setNegativeButton("취소",null).setPositiveButton("적용",(d,w)->{try{float next=Float.parseFloat(input.getText().toString())/100,ratio=next/it.width;if(!size(next)||!size(it.depth*ratio)||!size(it.height*ratio))throw new Exception();surface.queueEvent(()->{it.width=next;it.depth*=ratio;it.height*=ratio;try{it.product.put("manualSize",true);it.product.put("uniformScale",true);}catch(Exception ignored){}});}catch(Exception ex){Toast.makeText(this,"각 치수가 1~600cm 안에 들어가도록 입력해주세요.",Toast.LENGTH_SHORT).show();}}).show();}
    @Override protected void onResume(){super.onResume();if(surface==null)return;
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){if(!permissionRequested){permissionRequested=true;requestPermissions(new String[]{Manifest.permission.CAMERA},41);}return;}
        try{if(session==null){if(ArCoreApk.getInstance().requestInstall(this,!installRequested)==ArCoreApk.InstallStatus.INSTALL_REQUESTED){installRequested=true;return;}session=new Session(this);Config config=new Config(session);config.setPlaneFindingMode(Config.PlaneFindingMode.HORIZONTAL);config.setLightEstimationMode(Config.LightEstimationMode.AMBIENT_INTENSITY);depthSupported=roomfit3Mode&&session.isDepthModeSupported(Config.DepthMode.AUTOMATIC);if(depthSupported)config.setDepthMode(Config.DepthMode.AUTOMATIC);session.configure(config);}session.resume();surface.onResume();surfaceRunning=true;}
        catch(Exception ex){new AlertDialog.Builder(this).setTitle("앱 안 AR을 시작하지 못했어요").setMessage(ex.getClass().getSimpleName()+"\n카메라 사용 중인 앱을 닫고 AR 서비스 업데이트를 확인해주세요. 기존 Google AR 보기는 가구 상세에서 계속 사용할 수 있어요.").setPositiveButton("돌아가기",(d,w)->finish()).setOnCancelListener(d->finish()).show();}
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==41){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED){recreate();}else new AlertDialog.Builder(this).setMessage("배치 화면을 촬영하려면 카메라 권한이 필요해요.").setPositiveButton("돌아가기",(d,w)->finish()).show();}}
    @Override protected void onPause(){if(surfaceRunning){surface.onPause();surfaceRunning=false;}if(session!=null)session.pause();super.onPause();}
    @Override protected void onDestroy(){if(session!=null){if(renderer!=null && renderer.candidateAnchor!=null){renderer.candidateAnchor.detach();renderer.candidateAnchor=null;}for(Item x:items)if(x.anchor!=null)x.anchor.detach();session.close();session=null;}super.onDestroy();}
    private void updateStatus(String text,boolean ready){if(!text.equals(lastStatus)||ready!=lastReady){lastStatus=text;lastReady=ready;runOnUiThread(()->{status.setText(text);capture.setEnabled(ready);});}}
    private void showScanText(String text){if(scanNote!=null)runOnUiThread(()->scanNote.setText(text));}
    private void suggestionReady(boolean available){if(applySuggestion!=null)runOnUiThread(()->applySuggestion.setEnabled(available));}
    private final class Scene implements GLSurfaceView.Renderer {
        private int backgroundProgram,cubeProgram,texture,width=1,height=1;
        private FloatBuffer quad,uv,cube;
        private volatile PointF tap;
        volatile int selected=0;
        volatile boolean captureRequested=false;
        private boolean saving=false;
        private String placementWarning="";
        private long warningUntil=0;
        private int depthFrames=0;
        private ObstacleMath.Verdict lastDepthVerdict=ObstacleMath.Verdict.UNKNOWN;
        private int depthBlocked=0,depthUnknown=0;
        private final RoomScanGuide scanGuide=new RoomScanGuide();
        private int scanFrame=0;
        private float pendingX=0,pendingZ=0,pendingAngle=0;
        private boolean pendingTransform=false;
        private Anchor candidateAnchor=null;
        private int candidateIndex=-1,searchIndex=-1;
        private volatile boolean applySuggested=false;
        private void selectItem(int index){
            selected=Math.max(0,Math.min(items.size()-1,index));
            discardCandidate();
        }
        private void rotateSelected(float degrees){pendingAngle+=degrees;pendingTransform=true;}
        private void moveSelected(float x,float z){pendingX+=x;pendingZ+=z;pendingTransform=true;}
        private void startSearch(){
            discardCandidate();searchIndex=0;
            warn("🟠 관찰된 바닥에서 배치 가능한 위치를 검색합니다.");
        }
        private void discardCandidate(){if(candidateAnchor!=null){candidateAnchor.detach();candidateAnchor=null;}candidateIndex=-1;searchIndex=-1;suggestionReady(false);}
        private Pose placedPose(Item it){return placedPose(it,it.dx,it.dz);}
        private Pose placedPose(Item it,float dx,float dz){return it.anchor.getPose().compose(Pose.makeTranslation(dx,0,dz));}
        private Pose yawPose(Pose pose,float yaw){double rad=Math.toRadians(yaw)*.5;return pose.compose(Pose.makeRotation(0,(float)Math.sin(rad),0,(float)Math.cos(rad)));}
        /** Ensure the complete footprint, not just the center hit, is on the observed plane polygon. */
        private boolean fitsObservedFloor(Plane plane,Pose pose,Item item,float padding){return fitsObservedFloor(plane,pose,item,padding,item.yaw);}
        private boolean fitsObservedFloor(Plane plane,Pose pose,Item item,float padding,float yaw){
            Pose rotated=yawPose(pose,yaw);
            float hw=item.width/2+padding,hd=item.depth/2+padding;
            for(float x:new float[]{-hw,hw})for(float z:new float[]{-hd,hd}){
                float[] point=rotated.transformPoint(new float[]{x,0,z});
                if(!plane.isPoseInPolygon(Pose.makeTranslation(point[0],point[1],point[2])))return false;
            }
            return true;
        }
        private boolean onObservedFloor(Pose pose,Item item,float yaw){
            if(session==null)return false;
            for(Plane p:session.getAllTrackables(Plane.class)){
                if(p.getTrackingState()!=TrackingState.TRACKING||p.getType()!=Plane.Type.HORIZONTAL_UPWARD_FACING)continue;
                if(Math.abs(p.getCenterPose().ty()-pose.ty())>.20f)continue;
                if(fitsObservedFloor(p,pose,item,.015f,yaw))return true;
            }
            return false;
        }
        private boolean footprintConflict(Pose pose,Item current,float yaw){
            float[] trial=rectangleFor(pose,current.width,current.depth,yaw);
            for(Item other:items){if(other==current||other.anchor==null)continue;
                if(ObstacleMath.overlaps(trial,rectangleFor(placedPose(other),other.width,other.depth,other.yaw)))return true;
            }
            return false;
        }
        private boolean validPlacement(Frame frame,Camera camera,Pose pose,Item item,float yaw){
            if(footprintConflict(pose,item,yaw)){
                warn("🔴 다른 AR 가구와 배치 영역이 겹칩니다. 위치나 방향을 바꿔주세요.");return false;
            }
            if(roomfit3Mode && !onObservedFloor(pose,item,yaw)){
                warn("🟠 감지된 바닥 경계 밖으로 이동할 수 없습니다. 바닥을 다시 비춰주세요.");return false;
            }
            if(depthSupported){
                DepthPlacementChecker.Result check=DepthPlacementChecker.inspect(frame,camera,yawPose(pose,yaw),item.width,item.depth,item.height,width,height);
                if(check.verdict!=ObstacleMath.Verdict.CLEAR){warn(check.message());return false;}
                lastDepthVerdict=ObstacleMath.Verdict.UNKNOWN;depthUnknown=1;
            }else{
                lastDepthVerdict=ObstacleMath.Verdict.UNSUPPORTED;
                warn("🟠 Depth 미지원 · 장애물 자동 검사 없이 미리보기만 가능합니다.");
            }
            return true;
        }
        private void handleTransform(Frame frame,Camera camera){
            if(!pendingTransform)return;
            float x=pendingX,z=pendingZ,angle=pendingAngle;
            pendingX=pendingZ=pendingAngle=0;pendingTransform=false;
            Item it=items.get(selected);
            if(it.anchor==null){warn("🟠 먼저 바닥을 터치해 가구를 배치하세요.");return;}
            float nx=clamp(it.dx+x,-3,3),nz=clamp(it.dz+z,-3,3),nyaw=it.yaw+angle;
            if(roomfit3Mode&&!validPlacement(frame,camera,placedPose(it,nx,nz),it,nyaw))return;
            it.dx=nx;it.dz=nz;it.yaw=nyaw;
            discardCandidate();lastDepthVerdict=depthSupported?ObstacleMath.Verdict.UNKNOWN:ObstacleMath.Verdict.UNSUPPORTED;depthUnknown=depthSupported?1:0;
        }
        /** Rechecks ALL placed furniture, not merely the selected item.  Nothing here claims
         *  to detect unseen obstacles outside the camera's observed depth coverage. */
        private void inspectAllPlaced(Frame frame,Camera camera){
            int blocked=0,unknown=0;
            for(Item it:items){
                if(it.anchor==null || it.anchor.getTrackingState()!=TrackingState.TRACKING)continue;
                DepthPlacementChecker.Result result=DepthPlacementChecker.inspect(
                    frame,camera,yawPose(placedPose(it),it.yaw),it.width,it.depth,it.height,width,height);
                if(result.verdict==ObstacleMath.Verdict.BLOCKED)blocked++;
                else if(result.verdict!=ObstacleMath.Verdict.CLEAR)unknown++;
            }
            depthBlocked=blocked;depthUnknown=unknown;
            lastDepthVerdict=blocked>0?ObstacleMath.Verdict.BLOCKED:
                unknown>0?ObstacleMath.Verdict.UNKNOWN:ObstacleMath.Verdict.CLEAR;
            if(blocked>0)warn("🔴 배치된 가구 "+blocked+"개가 실제 장애물과 겹칠 가능성이 있습니다. 위치를 바꿔주세요.");
            else if(unknown>0)warn("🟠 가구 "+unknown+"개의 거리 정보가 부족합니다. 다른 방향에서 다시 비춰주세요.");
        }
        private void observeScan(Frame frame,Camera camera){
            if(!roomfit3Mode || ++scanFrame%18!=0)return;
            boolean floor=false;
            for(HitResult hit:frame.hitTest(width*.5f,height*.59f)){
                Trackable t=hit.getTrackable();
                if(t instanceof Plane&&((Plane)t).getType()==Plane.Type.HORIZONTAL_UPWARD_FACING&&((Plane)t).isPoseInPolygon(hit.getHitPose())){floor=true;break;}
            }
            boolean depth=depthSupported&&DepthPlacementChecker.hasUsableDepth(frame);
            float[] z=camera.getPose().getZAxis();scanGuide.observe(z[0],z[2],floor,depth);
            showScanText("스캔 안내: "+scanGuide.guidance(depthSupported)+"\n"+scanGuide.countText());
        }
        private void scanCandidates(Frame frame,Camera camera){
            if(!roomfit3Mode||searchIndex<0||candidateAnchor!=null)return;
            if(!depthSupported){warn("🟠 이 기기에서는 Depth 기반 빈 위치 자동 추천을 사용할 수 없습니다.");searchIndex=-1;return;}
            if(!scanGuide.hasEnoughForSearch()){
                warn("🟠 먼저 방을 여러 방향에서 비춰 바닥·거리 정보를 확보하세요.");searchIndex=-1;return;
            }
            Item item=items.get(selected);
            int checked=0;
            while(searchIndex<EmptySpaceCandidates.count() && checked++<2){
                int i=searchIndex++;
                for(HitResult hit:frame.hitTest(width*EmptySpaceCandidates.x(i),height*EmptySpaceCandidates.y(i))){
                    Trackable t=hit.getTrackable();
                    if(!(t instanceof Plane)||((Plane)t).getType()!=Plane.Type.HORIZONTAL_UPWARD_FACING||!((Plane)t).isPoseInPolygon(hit.getHitPose()))continue;
                    Pose pose=hit.getHitPose();
                    if(!fitsObservedFloor((Plane)t,pose,item,.08f))break;
                    if(footprintConflict(pose,item,item.yaw))break;
                    DepthPlacementChecker.Result check=DepthPlacementChecker.inspect(frame,camera,yawPose(pose,item.yaw),item.width+.15f,item.depth+.15f,item.height,width,height);
                    if(check.verdict==ObstacleMath.Verdict.CLEAR){
                        candidateAnchor=hit.createAnchor();candidateIndex=selected;searchIndex=-1;
                        warn("🟢 현재 관측된 영역에 배치 가능한 후보가 있습니다. 추천 위치에 배치를 눌러 확인하세요.");
                        suggestionReady(true);
                    }
                    break;
                }
                if(candidateAnchor!=null)break;
            }
            if(searchIndex>=EmptySpaceCandidates.count() && candidateAnchor==null){searchIndex=-1;warn("🟠 확실한 빈 위치를 찾지 못했습니다. 각도를 바꿔 다시 스캔하세요.");}
        }
        private void commitSuggestion(Frame frame,Camera camera){
            if(!applySuggested)return;applySuggested=false;
            if(candidateAnchor==null||candidateIndex!=selected){warn("추천 위치가 만료됐습니다. 다시 검색하세요.");discardCandidate();return;}
            Item it=items.get(selected);
            if(!validPlacement(frame,camera,candidateAnchor.getPose(),it,it.yaw)){discardCandidate();return;}
            Anchor previous=it.anchor;it.anchor=candidateAnchor;it.dx=it.dz=0;
            candidateAnchor=null;candidateIndex=-1;searchIndex=-1;suggestionReady(false);
            if(previous!=null)previous.detach();
            warn("🟢 추천 후보 위치에 배치했습니다. 주변과 통로는 직접 확인해주세요.");
        }
        private void drawFootprint(Pose pose,Item item,float[] color){
            pose.toMatrix(base,0);Matrix.rotateM(base,0,item.yaw,0,1,0);
            float w=item.width+.03f,d=item.depth+.03f;
            drawPart(new FurnitureShape.Part(w,.012f,.018f,0,.02f,d/2,0),base,color,1);
            drawPart(new FurnitureShape.Part(w,.012f,.018f,0,.02f,-d/2,0),base,color,1);
            drawPart(new FurnitureShape.Part(.018f,.012f,d,-w/2,.02f,0,0),base,color,1);
            drawPart(new FurnitureShape.Part(.018f,.012f,d,w/2,.02f,0,0),base,color,1);
        }
        private void warn(String text){placementWarning=text;warningUntil=System.currentTimeMillis()+4000;}
        private float[] rectangleFor(Pose pose,float width,float depth,float yaw){
            float[] m=new float[16];pose.toMatrix(m,0);Matrix.rotateM(m,0,yaw,0,1,0);
            float[] corners=new float[8];int t=0;
            for(float z:new float[]{-depth/2,depth/2})for(float x:new float[]{-width/2,width/2}){
                // Reorder corners cyclically below for SAT.
                float wx=m[0]*x+m[8]*z+m[12], wz=m[2]*x+m[10]*z+m[14];
                corners[t++]=wx;corners[t++]=wz;
            }
            // enumerated [BL,BR,TL,TR] => [BL,BR,TR,TL]
            float tmpX=corners[4],tmpZ=corners[5];corners[4]=corners[6];corners[5]=corners[7];corners[6]=tmpX;corners[7]=tmpZ;
            return corners;
        }
        private boolean overlapsPlaced(Pose pose,Item current){return footprintConflict(pose,current,current.yaw);}
        final float[] view=new float[16],projection=new float[16],model=new float[16],object=new float[16],mvp=new float[16],pv=new float[16],base=new float[16];
        @Override public void onSurfaceCreated(GL10 gl,EGLConfig cfg){
            GLES20.glClearColor(.1f,.12f,.1f,1);int[] textures=new int[1];GLES20.glGenTextures(1,textures,0);texture=textures[0];GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
            backgroundProgram=program("attribute vec2 aPosition;attribute vec2 aUv;varying vec2 vUv;void main(){gl_Position=vec4(aPosition,0.,1.);vUv=aUv;}","#extension GL_OES_EGL_image_external : require\nprecision mediump float;uniform samplerExternalOES uCamera;uniform vec3 uGain;varying vec2 vUv;void main(){vec3 c=texture2D(uCamera,vUv).rgb;gl_FragColor=vec4(clamp(c*uGain,0.,1.),1.);}");
            cubeProgram=program("attribute vec3 aPosition;attribute vec3 aNormal;uniform mat4 uMvp;uniform mat4 uModel;varying float vShade;void main(){vec3 n=normalize(mat3(uModel)*aNormal);vShade=.55+.45*max(dot(n,normalize(vec3(.3,.8,.5))),0.);gl_Position=uMvp*vec4(aPosition,1.);}","precision mediump float;uniform vec3 uColor;uniform vec3 uGain;uniform float uLight;varying float vShade;void main(){gl_FragColor=vec4(clamp(uColor*uGain*vShade*uLight,0.,1.),1.);}");
            quad=buffer(new float[]{-1,-1,1,-1,-1,1,1,1});uv=buffer(new float[8]);cube=makeCube();
            for(Item it:items)if(it.entry!=null){try{it.mesh=new GlbRenderer(it.entry.model);}catch(Exception ex){it.mesh=null;it.modelFailed=true;try{it.product.put("modelSource","schematic");it.product.put("modelLabel","불러오기 실패 · 단순 모형");}catch(Exception ignored){}}}
        }
        @Override public void onSurfaceChanged(GL10 gl,int w,int h){width=w;height=h;GLES20.glViewport(0,0,w,h);}
        @Override public void onDrawFrame(GL10 gl){
            if(saving)return;GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);Session active=session;if(active==null)return;
            try{active.setDisplayGeometry(getWindowManager().getDefaultDisplay().getRotation(),width,height);active.setCameraTextureName(texture);Frame frame=active.update();if(frame.getTimestamp()==0)return;drawBackground(frame);Camera camera=frame.getCamera();if(camera.getTrackingState()!=TrackingState.TRACKING){captureRequested=false;updateStatus("바닥을 천천히 비춰주세요 · "+camera.getTrackingFailureReason().name(),false);return;}
                observeScan(frame,camera);handleTransform(frame,camera);scanCandidates(frame,camera);commitSuggestion(frame,camera);
                PointF point=tap;tap=null;if(point!=null){for(HitResult hit:frame.hitTest(point.x,point.y)){Trackable track=hit.getTrackable();if(track instanceof Plane&&((Plane)track).getType()==Plane.Type.HORIZONTAL_UPWARD_FACING&&((Plane)track).isPoseInPolygon(hit.getHitPose())){if(roomfit3Mode){
                                    Item item=items.get(selected);
                                    if(!fitsObservedFloor((Plane)track,hit.getHitPose(),item,.02f)){
                                        warn("🟠 감지된 바닥 경계를 벗어납니다. 가구 전체가 바닥 안에 들어오도록 이동해주세요.");break;
                                    }
                                    if(!validPlacement(frame,camera,hit.getHitPose(),item,item.yaw))break;
                                    discardCandidate();
                                }
                                Anchor next=hit.createAnchor();if(roomfit2Mode){
                                Anchor oldAnchor=items.get(0).anchor;if(oldAnchor!=null)oldAnchor.detach();for(Item it:items)it.anchor=next;
                            }else{Item it=items.get(selected);if(it.anchor!=null)it.anchor.detach();it.anchor=next;it.dx=it.dz=0;}break;}}}
                camera.getViewMatrix(view,0);camera.getProjectionMatrix(projection,0,.05f,30);Matrix.multiplyMM(pv,0,projection,0,view,0);GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glDepthMask(true);
                float light=frame.getLightEstimate().getState()==LightEstimate.State.VALID?clamp(frame.getLightEstimate().getPixelIntensity(),.65f,1.2f):1;
                int count=0;for(Item it:items){if(it.anchor==null||it.anchor.getTrackingState()!=TrackingState.TRACKING)continue;count++;it.anchor.getPose().toMatrix(base,0);if(roomfit2Mode){Matrix.translateM(base,0,groupX,0,groupZ);Matrix.rotateM(base,0,groupYaw,0,1,0);}Matrix.translateM(base,0,it.dx,0,it.dz);Matrix.rotateM(base,0,it.yaw,0,1,0);drawItem(it,base,light);}
                if(roomfit3Mode){
                    Item selectedItem=items.get(selected);
                    if(selectedItem.anchor!=null && selectedItem.anchor.getTrackingState()==TrackingState.TRACKING){
                        drawFootprint(placedPose(selectedItem),selectedItem,new float[]{.21f,.83f,.52f});
                    }
                    if(candidateAnchor!=null&&candidateIndex==selected && candidateAnchor.getTrackingState()==TrackingState.TRACKING){
                        drawFootprint(candidateAnchor.getPose(),selectedItem,new float[]{.23f,.98f,.27f});
                    }
                }
                boolean ready=count==items.size();boolean depthRisk=false;
                if(roomfit3Mode && depthSupported && count>0 && (++depthFrames%25==0 || captureRequested)){
                    inspectAllPlaced(frame,camera);
                }
                if(roomfit3Mode){
                    for(int a=0;a<items.size();a++)for(int b=a+1;b<items.size();b++){
                        Item p=items.get(a),q=items.get(b);
                        if(p.anchor!=null&&q.anchor!=null&&ObstacleMath.overlaps(rectangleFor(placedPose(p),p.width,p.depth,p.yaw),rectangleFor(placedPose(q),q.width,q.depth,q.yaw))){depthRisk=true;warn("🔴 배치한 AR 가구가 서로 겹칩니다. 위치를 수정하세요.");}
                    }
                    if(depthSupported && (depthBlocked>0 || depthUnknown>0 || lastDepthVerdict!=ObstacleMath.Verdict.CLEAR))depthRisk=true;
                }
                int detailed=0,failed=0;for(Item it:items){if(it.mesh!=null)detailed++;if(it.modelFailed)failed++;}String stateText=roomfit3Mode?(placementWarning.length()>0&&System.currentTimeMillis()<warningUntil?placementWarning:(depthSupported?"🟢 ARCore Depth 활성 · 화면에 보이는 장애물만 검사합니다.":"🟠 Depth 미지원 · 자동 장애물 검사 없이 미리보기만 제공")):"상품참고 "+detailed+"개 · 단순 "+(items.size()-detailed)+"개"+(failed>0?" · 파일 오류 "+failed+"개":"");
                String action= !ready?"각 가구를 선택하고 바닥을 터치하세요":
                    depthRisk?"충돌 또는 미확인 영역을 다시 검사하세요":"사진 저장 가능";
                updateStatus(stateText+" · 배치 "+count+" / "+items.size()+" · "+action,ready&&!depthRisk);
                if(captureRequested){captureRequested=false;if(ready&&!depthRisk){saveFrame(frame,camera);return;}updateStatus("모든 가구를 안전한 위치에 배치한 뒤 촬영해주세요.",false);}
                // Visual target is omitted from the final framebuffer capture.
                if(!ready){for(HitResult hit:frame.hitTest(width/2f,height/2f)){Trackable t=hit.getTrackable();if(t instanceof Plane&&((Plane)t).getType()==Plane.Type.HORIZONTAL_UPWARD_FACING&&((Plane)t).isPoseInPolygon(hit.getHitPose())){hit.getHitPose().toMatrix(base,0);drawPart(new FurnitureShape.Part(.12f,.003f,.12f,0,.002f,0,0),base,new float[]{.3f,.8f,.5f},1);break;}}}
            }catch(Exception ex){captureRequested=false;updateStatus("AR 상태: "+ex.getClass().getSimpleName()+" · 화면을 천천히 움직여주세요.",false);}
        }
        private void drawBackground(Frame frame){drawBackground(frame,false);}
        private void drawBackground(Frame frame,boolean raw){
            quad.position(0);uv.position(0);frame.transformCoordinates2d(Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,quad,Coordinates2d.TEXTURE_NORMALIZED,uv);quad.position(0);uv.position(0);
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);GLES20.glDepthMask(false);GLES20.glUseProgram(backgroundProgram);int p=GLES20.glGetAttribLocation(backgroundProgram,"aPosition"),t=GLES20.glGetAttribLocation(backgroundProgram,"aUv");GLES20.glEnableVertexAttribArray(p);GLES20.glEnableVertexAttribArray(t);GLES20.glVertexAttribPointer(p,2,GLES20.GL_FLOAT,false,0,quad);GLES20.glVertexAttribPointer(t,2,GLES20.GL_FLOAT,false,0,uv);GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture);GLES20.glUniform1i(GLES20.glGetUniformLocation(backgroundProgram,"uCamera"),0);GLES20.glUniform3fv(GLES20.glGetUniformLocation(backgroundProgram,"uGain"),1,raw?new float[]{1,1,1}:gain,0);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glDisableVertexAttribArray(p);GLES20.glDisableVertexAttribArray(t);GLES20.glDepthMask(true);
        }
        private void drawItem(Item it,float[] transform,float light){if(it.mesh!=null){it.mesh.draw(pv,transform,it.width,light);return;}float[] white={.9f,.91f,.88f},black={.07f,.08f,.07f};float[] productColor=it.name.contains("화이트")?white:it.name.contains("블랙")?black:colors[0];for(FurnitureShape.Part part:FurnitureShape.parts(it.kind,it.width,it.depth,it.height))drawPart(part,transform,productColor,light);}
        private void drawPart(FurnitureShape.Part part,float[] base,float[] color,float light){
            System.arraycopy(base,0,model,0,16);Matrix.translateM(model,0,part.x,part.y,part.z);Matrix.scaleM(model,0,part.w,part.h,part.d);Matrix.multiplyMM(mvp,0,pv,0,model,0);GLES20.glUseProgram(cubeProgram);int p=GLES20.glGetAttribLocation(cubeProgram,"aPosition"),n=GLES20.glGetAttribLocation(cubeProgram,"aNormal");cube.position(0);GLES20.glEnableVertexAttribArray(p);GLES20.glVertexAttribPointer(p,3,GLES20.GL_FLOAT,false,24,cube);cube.position(3);GLES20.glEnableVertexAttribArray(n);GLES20.glVertexAttribPointer(n,3,GLES20.GL_FLOAT,false,24,cube);GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(cubeProgram,"uMvp"),1,false,mvp,0);GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(cubeProgram,"uModel"),1,false,model,0);GLES20.glUniform3fv(GLES20.glGetUniformLocation(cubeProgram,"uColor"),1,color,0);GLES20.glUniform3fv(GLES20.glGetUniformLocation(cubeProgram,"uGain"),1,gain,0);GLES20.glUniform1f(GLES20.glGetUniformLocation(cubeProgram,"uLight"),light);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);GLES20.glDisableVertexAttribArray(p);GLES20.glDisableVertexAttribArray(n);
        }
        private void saveFrame(Frame frame,Camera camera)throws Exception {
            if((long)width*height>16000000)throw new Exception("capture-size");GLES20.glFinish();ByteBuffer pixels=ByteBuffer.allocateDirect(width*height*4).order(ByteOrder.nativeOrder());GLES20.glReadPixels(0,0,width,height,GLES20.GL_RGBA,GLES20.GL_UNSIGNED_BYTE,pixels);if(GLES20.glGetError()!=GLES20.GL_NO_ERROR)throw new Exception("capture-read");
            final ByteBuffer beforePixels=ByteBuffer.allocateDirect(width*height*4).order(ByteOrder.nativeOrder());drawBackground(frame,true);GLES20.glFinish();GLES20.glReadPixels(0,0,width,height,GLES20.GL_RGBA,GLES20.GL_UNSIGNED_BYTE,beforePixels);if(GLES20.glGetError()!=GLES20.GL_NO_ERROR)throw new Exception("before-read");drawBackground(frame);GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT);for(Item it:items){it.anchor.getPose().toMatrix(base,0);if(roomfit2Mode){Matrix.translateM(base,0,groupX,0,groupZ);Matrix.rotateM(base,0,groupYaw,0,1,0);}Matrix.translateM(base,0,it.dx,0,it.dz);Matrix.rotateM(base,0,it.yaw,0,1,0);drawItem(it,base,1);}
            final int w=width,h=height;final JSONObject meta=new JSONObject();JSONArray placed=new JSONArray();for(Item it:items){JSONObject p=new JSONObject(it.product.toString());float[] m=new float[16];it.anchor.getPose().toMatrix(m,0);if(roomfit2Mode){Matrix.translateM(m,0,groupX,0,groupZ);Matrix.rotateM(m,0,groupYaw,0,1,0);}Matrix.translateM(m,0,it.dx,0,it.dz);Matrix.rotateM(m,0,it.yaw,0,1,0);p.put("width",it.width*100);p.put("depth",it.depth*100);p.put("height",it.height*100);p.put("matrix",array(m));p.put("yawDegrees",it.yaw);placed.put(p);}meta.put("scanObservedDirections",scanGuide.directions());meta.put("scanDepthSamples",scanGuide.depthSamples());meta.put("scanFloorSamples",scanGuide.floorSamples());meta.put("roomfitVersion","3.1.1");meta.put("depthBlockedFurnitureCount",depthBlocked);meta.put("depthUnverifiedFurnitureCount",depthUnknown);meta.put("depthSupported",depthSupported);meta.put("depthVerdict",roomfit3Mode?lastDepthVerdict.name():"NOT_CHECKED");meta.put("automaticDetectionLimits","visible depth only; not a full-room safety measurement");meta.put("groupYaw",groupYaw);meta.put("groupX",groupX);meta.put("groupZ",groupZ);meta.put("version",1);meta.put("kind","locked-ar");meta.put("capturedAt",System.currentTimeMillis());meta.put("items",placed);meta.put("style",request.getJSONObject("style"));meta.put("context",request.optJSONObject("context"));meta.put("viewMatrix",array(view));meta.put("projectionMatrix",array(projection));meta.put("tracking","TRACKING");meta.put("sourceWidth",w);meta.put("sourceHeight",h);meta.put("coordinateSystem","ARCore local session metres; not restorable in another session");saving=true;
            new Thread(()->{Bitmap bitmap=null,scaled=null;try{int[] argb=new int[w*h];for(int y=0;y<h;y++)for(int x=0;x<w;x++){int at=4*((h-1-y)*w+x),r=pixels.get(at)&255,g=pixels.get(at+1)&255,b=pixels.get(at+2)&255;argb[y*w+x]=0xff000000|(r<<16)|(g<<8)|b;}bitmap=Bitmap.createBitmap(argb,w,h,Bitmap.Config.ARGB_8888);float scale=Math.min(1,1536f/Math.max(w,h));scaled=scale<1?Bitmap.createScaledBitmap(bitmap,Math.max(1,Math.round(w*scale)),Math.max(1,Math.round(h*scale)),true):bitmap;meta.put("width",scaled.getWidth());meta.put("height",scaled.getHeight());File dir=new File(getFilesDir(),"locked-ar");dir.mkdirs();String id=java.util.UUID.randomUUID().toString();File image=new File(dir,id+".jpg"),json=new File(dir,id+".json");try(FileOutputStream out=new FileOutputStream(image)){if(!scaled.compress(Bitmap.CompressFormat.JPEG,92,out))throw new Exception();}meta.put("captureId",id);meta.put("imageFile",image.getName());File beforeImage=new File(dir,id+"-before.jpg");for(int y=0;y<h;y++)for(int x=0;x<w;x++){int at=4*((h-1-y)*w+x),red=beforePixels.get(at)&255,green=beforePixels.get(at+1)&255,blue=beforePixels.get(at+2)&255;argb[y*w+x]=0xff000000|(red<<16)|(green<<8)|blue;}Bitmap beforeBitmap=Bitmap.createBitmap(argb,w,h,Bitmap.Config.ARGB_8888),beforeScaled=scale<1?Bitmap.createScaledBitmap(beforeBitmap,scaled.getWidth(),scaled.getHeight(),true):beforeBitmap;try(FileOutputStream out=new FileOutputStream(beforeImage)){if(!beforeScaled.compress(Bitmap.CompressFormat.JPEG,92,out))throw new Exception();}finally{if(beforeScaled!=beforeBitmap)beforeScaled.recycle();beforeBitmap.recycle();}meta.put("beforeFile",beforeImage.getName());try(FileOutputStream out=new FileOutputStream(json)){out.write(meta.toString().getBytes("UTF-8"));}getSharedPreferences("locked-ar",0).edit().putString("last",json.getName()).apply();runOnUiThread(()->{setResult(RESULT_OK,new Intent().putExtra("capture",json.getAbsolutePath()));finish();});}catch(Exception ex){saving=false;runOnUiThread(()->{capture.setEnabled(true);Toast.makeText(LockedArActivity.this,"저장 실패: "+ex.getClass().getSimpleName(),Toast.LENGTH_LONG).show();});}finally{if(scaled!=null&&scaled!=bitmap)scaled.recycle();if(bitmap!=null)bitmap.recycle();}}).start();
        }
    }
    private static JSONArray array(float[] x)throws JSONException{JSONArray a=new JSONArray();for(float n:x)a.put((double)n);return a;}
    private static FloatBuffer buffer(float[] x){FloatBuffer b=ByteBuffer.allocateDirect(x.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(x).position(0);return b;}
    private static int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);int[] ok=new int[1];GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw new IllegalStateException(GLES20.glGetShaderInfoLog(s));return s;}
    private static int program(String v,String f){int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,v));GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,f));GLES20.glLinkProgram(p);int[] ok=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0)throw new IllegalStateException(GLES20.glGetProgramInfoLog(p));return p;}
    private static FloatBuffer makeCube(){float[] result=new float[36*6];int pos=0;float[][] normals={{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};float[][][] faces={{{.5f,-.5f,-.5f},{.5f,.5f,-.5f},{.5f,.5f,.5f},{.5f,-.5f,.5f}},{{-.5f,-.5f,.5f},{-.5f,.5f,.5f},{-.5f,.5f,-.5f},{-.5f,-.5f,-.5f}},{{-.5f,.5f,-.5f},{-.5f,.5f,.5f},{.5f,.5f,.5f},{.5f,.5f,-.5f}},{{-.5f,-.5f,.5f},{-.5f,-.5f,-.5f},{.5f,-.5f,-.5f},{.5f,-.5f,.5f}},{{-.5f,-.5f,.5f},{.5f,-.5f,.5f},{.5f,.5f,.5f},{-.5f,.5f,.5f}},{{.5f,-.5f,-.5f},{-.5f,-.5f,-.5f},{-.5f,.5f,-.5f},{.5f,.5f,-.5f}}};for(int f=0;f<6;f++)for(int v:new int[]{0,1,2,0,2,3}){for(float n:faces[f][v])result[pos++]=n;for(float n:normals[f])result[pos++]=n;}return buffer(result);}
}
