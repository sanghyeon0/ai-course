package kr.ac.roomfit.app;

/** Prioritized viewport sample positions; a suggestion is only made when a depth check is CLEAR.
 * These points are not complete-room geometry and their coordinates are fractions of the screen.
 */
public final class EmptySpaceCandidates {
    private EmptySpaceCandidates() {}
    private static final float[][] CELLS = {
        {.50f,.58f}, {.36f,.58f}, {.64f,.58f},
        {.50f,.48f}, {.36f,.48f}, {.64f,.48f},
        {.25f,.65f}, {.75f,.65f}, {.50f,.69f},
        {.25f,.49f}, {.75f,.49f}, {.40f,.72f}, {.60f,.72f}
    };
    public static int count() { return CELLS.length; }
    public static float x(int index) { return CELLS[index][0]; }
    public static float y(int index) { return CELLS[index][1]; }
}
