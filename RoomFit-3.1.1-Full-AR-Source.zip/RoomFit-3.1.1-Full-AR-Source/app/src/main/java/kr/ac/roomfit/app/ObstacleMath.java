package kr.ac.roomfit.app;

/** JVM-testable, conservative footprint classification. Centimetre and depth errors are possible. */
public final class ObstacleMath {
    private ObstacleMath() {}
    public enum Verdict { CLEAR, BLOCKED, UNKNOWN, UNSUPPORTED }
    public static Verdict classify(int observed, int obstacles) {
        if (observed < 6) return Verdict.UNKNOWN;
        return obstacles >= 4 && obstacles * 10 >= observed ? Verdict.BLOCKED : Verdict.CLEAR;
    }
    public static boolean inside(float x, float y, float z, float width, float depth, float height) {
        return Math.abs(x) <= width / 2 + .07f && Math.abs(z) <= depth / 2 + .07f
            && y > .12f && y < height + .12f;
    }
    /** Separating-axis overlap of two rectangles on XZ plane, corners [x,z] x4. */
    public static boolean overlaps(float[] a, float[] b) {
        if (a == null || b == null || a.length != 8 || b.length != 8) return false;
        for (int which=0; which<2; which++) {
            float[] poly = which==0 ? a:b;
            for (int edge=0; edge<4; edge++) {
                int j=(edge+1)%4;
                float nx=-(poly[j*2+1]-poly[edge*2+1]);
                float nz=poly[j*2]-poly[edge*2];
                float amin=Float.POSITIVE_INFINITY, amax=Float.NEGATIVE_INFINITY;
                float bmin=Float.POSITIVE_INFINITY, bmax=Float.NEGATIVE_INFINITY;
                for(int i=0;i<4;i++){
                    float av=a[i*2]*nx+a[i*2+1]*nz, bv=b[i*2]*nx+b[i*2+1]*nz;
                    amin=Math.min(amin,av);amax=Math.max(amax,av);
                    bmin=Math.min(bmin,bv);bmax=Math.max(bmax,bv);
                }
                // 2 cm tolerance: edge contact is not overlap; leave a very small margin.
                if(amax <= bmin + .02f || bmax <= amin + .02f)return false;
            }
        }
        return true;
    }
}
