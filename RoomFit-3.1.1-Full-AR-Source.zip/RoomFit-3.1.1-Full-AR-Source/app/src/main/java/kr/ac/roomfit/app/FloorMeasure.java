package kr.ac.roomfit.app;
/** Horizontal distance in metres converted to cm. This is not a calibrated survey. */
final class FloorMeasure {
 static float distanceCm(float ax,float ay,float az,float bx,float by,float bz){
  if(!Float.isFinite(ax)||!Float.isFinite(ay)||!Float.isFinite(az)||!Float.isFinite(bx)||!Float.isFinite(by)||!Float.isFinite(bz)||Math.abs(ay-by)>.05f)return Float.NaN;
  float cm=(float)Math.hypot(bx-ax,bz-az)*100;
  return cm>=10&&cm<=1000?cm:Float.NaN;
 }
 static boolean validInput(float width,float margin){return Float.isFinite(width)&&Float.isFinite(margin)&&width>=10&&width<=1000&&margin>=0&&margin<=100&&width-margin>=1;}
}
