package kr.ac.roomfit.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Base64;
import android.window.OnBackInvokedDispatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/** Installable hybrid app: bundled RoomFit UI, same-origin online API, native Android handoffs. */
public final class MainActivity extends Activity {
    private static final String ORIGIN = "https://roomfit-lifestyle-sanghyun.glossy-otter-9481.chatgpt.site";
    private static final String HOST = "roomfit-lifestyle-sanghyun.glossy-otter-9481.chatgpt.site";
    private static final int PICK_PHOTO = 101, SAVE_FILE = 102, LOCKED_AR = 103, AR_MEASURE = 104;
    private WebView web;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingSave;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(248,248,244));
        setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        web = new WebView(this);
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1,6,Gravity.TOP);
        root.addView(progress,pp);
        web.setBackgroundColor(Color.rgb(248,248,244));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        // 사진 선택기가 돌려주는 content:// 사진을 <input type=file>로 읽기 위해 유지합니다.
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.getSettings().setSafeBrowsingEnabled(true);
        web.getSettings().setSupportMultipleWindows(true);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setUserAgentString(web.getSettings().getUserAgentString()+" RoomFitAndroid/3.1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        web.addJavascriptInterface(new NativeBridge(),"RoomfitNative");
        web.setWebViewClient(new AppClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int value) { progress.setProgress(value);progress.setVisibility(value==100?View.GONE:View.VISIBLE); }
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
                if(fileCallback!=null)fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent choose=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                choose.addCategory(Intent.CATEGORY_OPENABLE);String[] accept=params.getAcceptTypes();boolean json=false;if(accept!=null)for(String type:accept)if(type!=null&&(type.contains("json")||type.contains(".json")))json=true;choose.setType(json?"application/json":"image/*");
                try { startActivityForResult(choose,PICK_PHOTO); } catch(ActivityNotFoundException ex) { fileCallback.onReceiveValue(null);fileCallback=null;toast("사진 선택 앱을 찾지 못했어요."); }
                return true;
            }
            @Override public boolean onCreateWindow(WebView view,boolean dialog,boolean gesture,Message result) {
                if(!gesture)return false;
                WebView child=new WebView(MainActivity.this);
                child.setWebViewClient(new WebViewClient(){
                    @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){routePopup(r.getUrl());v.destroy();return true;}
                    @Override public boolean shouldOverrideUrlLoading(WebView v,String url){routePopup(Uri.parse(url));v.destroy();return true;}
                });
                ((WebView.WebViewTransport)result.obj).setWebView(child);result.sendToTarget();return true;
            }
        });
        web.setDownloadListener((url,ua,disposition,mime,length) -> {
            if(url.startsWith("https://"))external(Uri.parse(url));
            else if(url.startsWith("data:"))new NativeBridge().saveDataUrl(url,"roomfit-download");
            else toast("다운로드 버튼을 다시 눌러주세요.");
        });
        // Android 13+ 예측형 뒤로가기: onBackPressed 대신 OnBackInvokedCallback 사용
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::handleBack);
        if(state==null)web.loadUrl(ORIGIN+"/roomfit3.html?app=android");else if(web.restoreState(state)==null)web.loadUrl(ORIGIN+"/roomfit3.html?app=android");
    }

    private boolean own(Uri u){return "https".equals(u.getScheme()) && HOST.equals(u.getHost()) && (u.getPort()==-1||u.getPort()==443);}
    private boolean modelPath(Uri u){String p=u.getPath();return own(u)&&p!=null&&(p.startsWith("/api/furniture-model/")||p.matches("/product-models/[a-z0-9-]+\\.glb"));}
    private void routePopup(Uri u){if(own(u))web.loadUrl(u.toString());else openLink(u);}
    private boolean openLink(Uri u){
        if("intent".equals(u.getScheme())){launchAR(u.toString());return true;}
        if(own(u))return false;
        if("https".equals(u.getScheme())||"http".equals(u.getScheme())){external(u);return true;}
        return true;
    }
    private void external(Uri u){try{startActivity(new Intent(Intent.ACTION_VIEW,u).addCategory(Intent.CATEGORY_BROWSABLE));}catch(ActivityNotFoundException ex){toast("링크를 열 브라우저가 없어요.");}}
    private void launchAR(String uri){
        try{
            Intent intent=Intent.parseUri(uri,Intent.URI_INTENT_SCHEME);
            Uri data=intent.getData();String pkg=intent.getPackage();
            if(data==null||!"https".equals(data.getScheme())||!"arvr.google.com".equals(data.getHost())||!data.getPath().startsWith("/scene-viewer/")||!("com.google.android.googlequicksearchbox".equals(pkg)||"com.google.ar.core".equals(pkg))) {toast("허용되지 않는 AR 링크예요.");return;}
            String file=data.getQueryParameter("file");
            if(file==null||!modelPath(Uri.parse(file))){toast("가구 모델 주소를 확인해주세요.");return;}
            intent.setComponent(null);intent.setSelector(null);intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.removeExtra("browser_fallback_url");
            startActivity(intent);
        }catch(Exception ex){
            new AlertDialog.Builder(this).setTitle("AR 실행 준비").setMessage("기기에서 AR 뷰어를 열지 못했어요. Google 앱과 Google Play AR 서비스가 설치되어 있어야 하며, AR 지원 기기가 필요해요.")
                .setPositiveButton("AR 서비스 확인",(d,w)->external(Uri.parse("https://play.google.com/store/apps/details?id=com.google.ar.core")))
                .setNegativeButton("닫기",null).show();
        }
    }
    private final class AppClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return openLink(r.getUrl());}
        @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return openLink(Uri.parse(url));}
        @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest request){
            Uri u=request.getUrl();if(!own(u)||!"GET".equals(request.getMethod()))return null;
            String path=u.getPath();if(path==null||path.contains("..")||path.startsWith("/api/"))return null;
            if(path.equals("/"))path="/roomfit3.html";
            if(!path.matches("/[A-Za-z0-9_./-]+"))return null;
            try{
                InputStream stream=getAssets().open("web"+path);
                Map<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-cache");headers.put("X-Content-Type-Options","nosniff");
                return new WebResourceResponse(mime(path),path.endsWith(".jpg")||path.endsWith(".png")||path.endsWith(".glb")?null:"UTF-8",200,"OK",headers,stream);
            }catch(Exception ex){return null;}
        }
    }
    private String mime(String p){if(p.endsWith(".glb"))return "model/gltf-binary";if(p.endsWith(".html"))return "text/html";if(p.endsWith(".js"))return "application/javascript";if(p.endsWith(".css"))return "text/css";if(p.endsWith(".json"))return "application/json";if(p.endsWith(".svg"))return "image/svg+xml";if(p.endsWith(".jpg"))return "image/jpeg";if(p.endsWith(".png"))return "image/png";return "application/octet-stream";}
    public final class NativeBridge {
        @JavascriptInterface public void openARMeasure(final String raw){if(raw==null||raw.length()>500)return;runOnUiThread(()->{try{org.json.JSONObject config=new org.json.JSONObject(raw);String category=config.getString("category");if(category.isEmpty()||category.length()>40)throw new Exception();startActivityForResult(new Intent(MainActivity.this,ArMeasureActivity.class).putExtra("category",category),AR_MEASURE);}catch(Exception ex){toast("측정 화면을 열지 못했어요. 직접 입력으로 계속해주세요.");}});}

        @JavascriptInterface public void openLockedAR(final String scene){if(scene==null||scene.length()>32000)return;runOnUiThread(()->{try{new org.json.JSONObject(scene);startActivityForResult(new Intent(MainActivity.this,LockedArActivity.class).putExtra("scene",scene),LOCKED_AR);}catch(Exception ex){toast("배치 화면을 열지 못했어요.");}});}
        @JavascriptInterface public void restoreLockedAR(){String name=getSharedPreferences("locked-ar",0).getString("last","");if(name.matches("[A-Za-z0-9-]+\\.json"))deliverLockedCapture(new File(new File(getFilesDir(),"locked-ar"),name).getAbsolutePath(),true);else toast("저장된 배치 사진이 없어요.");}
        @JavascriptInterface public void openFurnitureAR(final String model,final String title){
            if(model==null||model.length()>2000)return;
            final Uri file=Uri.parse(model);
            if(!modelPath(file))return;
            runOnUiThread(()->{
                Uri scene=new Uri.Builder().scheme("https").authority("arvr.google.com").path("/scene-viewer/1.0")
                    .appendQueryParameter("file",model).appendQueryParameter("mode","ar_only")
                    .appendQueryParameter("resizable","false").appendQueryParameter("title",title==null?"RoomFit":title.substring(0,Math.min(120,title.length()))).build();
                Intent intent=new Intent(Intent.ACTION_VIEW,scene).setPackage("com.google.ar.core");
                try{startActivity(intent);}catch(ActivityNotFoundException ex){toast("Google AR 뷰어를 열지 못했어요. 외부 브라우저로 열기를 이용해주세요.");}
            });
        }
        /** Google documentation sample, independently hosted from RoomFit. */
        @JavascriptInterface public void testSampleAR(){runOnUiThread(()->{
            Uri scene=new Uri.Builder().scheme("https").authority("arvr.google.com").path("/scene-viewer/1.0")
                .appendQueryParameter("file","https://storage.googleapis.com/ar-answers-in-search-models/static/Tiger/model.glb")
                .appendQueryParameter("mode","ar_only").appendQueryParameter("title","RoomFit AR sample test").build();
            try{startActivity(new Intent(Intent.ACTION_VIEW,scene).setPackage("com.google.ar.core"));}
            catch(ActivityNotFoundException ex){toast("AR 서비스 실행 화면을 찾지 못했어요. AR 서비스 설치·업데이트를 확인해주세요.");}
        });}
        @JavascriptInterface public void checkModelConnection(final String url){
            if(url==null||url.length()>2000)return;Uri u=Uri.parse(url);
            if(!modelPath(u))return;
            new Thread(()->{
                java.net.HttpURLConnection connection=null;String result;
                try{
                    connection=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();
                    connection.setConnectTimeout(15000);connection.setReadTimeout(15000);connection.setInstanceFollowRedirects(false);
                    int status=connection.getResponseCode();
                    if(status!=200)result="서버 응답: HTTP "+status+"\n모델 파일을 받지 못했어요.";
                    else{byte[] magic=new byte[4];int read=0;try(InputStream input=connection.getInputStream()){while(read<4){int n=input.read(magic,read,4-read);if(n<0)break;read+=n;}}
                        boolean glb=read==4&&magic[0]==103&&magic[1]==108&&magic[2]==84&&magic[3]==70;
                        result="서버 응답: HTTP 200\n"+(glb?"3D 파일(GLB) 응답 확인":"3D 파일 대신 다른 응답이 왔어요.");}
                }catch(Exception ex){result="모델 서버 연결 실패: "+ex.getClass().getSimpleName();}
                finally{if(connection!=null)connection.disconnect();}
                final String message=result+"\n\n이 검사는 룸핏 앱에서의 연결만 확인해요. Google 뷰어의 연결이나 AR 작동을 보장하지 않아요.";
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())new AlertDialog.Builder(MainActivity.this).setTitle("모델 연결 검사").setMessage(message).setPositiveButton("닫기",null).show();});
            }).start();
        }
        @JavascriptInterface public void open3DInBrowser(final String url){
            if(url==null||url.length()>4000)return;Uri u=Uri.parse(url);
            if(own(u)&&"/furniture-3d.html".equals(u.getPath()))runOnUiThread(()->external(u));
        }
        private boolean installed(String name){try{getPackageManager().getPackageInfo(name,0);return true;}catch(Exception ex){return false;}}
        @JavascriptInterface public void arDiagnostics(){runOnUiThread(()->new AlertDialog.Builder(MainActivity.this)
            .setTitle("AR 연결 확인 · 앱 1.7.2")
            .setMessage("기기: "+Build.MANUFACTURER+" "+Build.MODEL+"\nAndroid: "+Build.VERSION.RELEASE
              +"\nGoogle 앱: "+(installed("com.google.android.googlequicksearchbox")?"설치됨":"없음")
              +"\nGoogle Play AR 서비스: "+(installed("com.google.ar.core")?"설치됨":"없음")
              +"\n\n설치 여부만 확인한 결과예요. 실제 AR 작동을 보장하지 않아요. 검은 화면이 계속되면 외부 브라우저로 열기를 이용해주세요.")
            .setPositiveButton("AR 서비스 확인",(d,w)->external(Uri.parse("https://play.google.com/store/apps/details?id=com.google.ar.core")))
            .setNegativeButton("닫기",null).show());}

        @JavascriptInterface public void copyLink(final String text){if(text==null||text.length()>16000)return;runOnUiThread(()->{ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("룸핏",text));toast("링크를 복사했어요.");});}
        @JavascriptInterface public void saveDataUrl(String data,String name){
            if(data==null||data.length()>24000000)return;
            try{
                int comma=data.indexOf(',');if(comma<0||!data.substring(0,comma).contains(";base64"))return;
                final String type=data.substring(5,data.indexOf(';'));
                if(!(type.equals("image/png")||type.equals("image/jpeg")||type.equals("text/csv")||type.equals("application/json")||type.equals("application/octet-stream")))return;
                final byte[] bytes=Base64.decode(data.substring(comma+1),Base64.DEFAULT);
                String clean=(name==null?"roomfit":name).replaceAll("[^A-Za-z0-9._가-힣-]","_");
                final String filename=clean.length()>100?clean.substring(0,100):clean;
                runOnUiThread(()->{if(pendingSave!=null){toast("현재 파일 저장을 먼저 완료해주세요.");return;}pendingSave=bytes;Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.addCategory(Intent.CATEGORY_OPENABLE);save.setType(type);save.putExtra(Intent.EXTRA_TITLE,filename);try{startActivityForResult(save,SAVE_FILE);}catch(Exception ex){pendingSave=null;toast("파일 저장 화면을 열지 못했어요.");}});
            }catch(Exception ex){toast("파일을 준비하지 못했어요.");}
        }
        /** Share an AR camera capture (JPEG) through Android Sharesheet. */
        @JavascriptInterface public void shareDataUrl(String data){
            if(data==null||data.length()>16000000||!data.startsWith("data:image/jpeg;base64,"))return;
            new Thread(()->{
                try{
                    byte[] bytes=Base64.decode(data.substring(data.indexOf(',')+1),Base64.DEFAULT);
                    if(bytes.length>6000000)return;
                    File file=new File(ShareProvider.shareDir(MainActivity.this),"roomfit-ar-"+java.util.UUID.randomUUID()+".jpg");
                    try(FileOutputStream out=new FileOutputStream(file)){out.write(bytes);}
                    runOnUiThread(()->{
                        Uri uri=ShareProvider.uriFor(file.getName());
                        Intent send=new Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        send.setClipData(ClipData.newRawUri("룸핏 AR 결과",uri));
                        try{startActivity(Intent.createChooser(send,"AR 배치 사진 공유"));}catch(ActivityNotFoundException ex){toast("공유할 앱이 없습니다.");}
                    });
                }catch(Exception ex){toast("AR 공유 사진을 준비하지 못했어요.");}
            }).start();
        }
        /** 결과 카드 PNG를 캐시에 쓰고 시스템 공유 창을 엽니다. */
        @JavascriptInterface public void shareImage(String data,final String text){
            if(data==null||data.length()>24000000||!data.startsWith("data:image/png;base64,"))return;
            try{
                final byte[] bytes=Base64.decode(data.substring(data.indexOf(',')+1),Base64.DEFAULT);
                final String message=text==null?"":(text.length()>500?text.substring(0,500):text);
                new Thread(()->{
                    File file=new File(ShareProvider.shareDir(MainActivity.this),"roomfit-plan-"+java.util.UUID.randomUUID()+".png");
                    try(FileOutputStream out=new FileOutputStream(file)){out.write(bytes);}catch(Exception ex){toast("공유 이미지를 만들지 못했어요.");return;}
                    runOnUiThread(()->{
                        Uri uri=ShareProvider.uriFor(file.getName());
                        Intent send=new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM,uri).putExtra(Intent.EXTRA_TEXT,message).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        send.setClipData(ClipData.newRawUri("룸핏",uri));
                        try{startActivity(Intent.createChooser(send,"룸핏 결과 공유"));}catch(ActivityNotFoundException ex){toast("공유할 앱을 찾지 못했어요.");}
                    });
                }).start();
            }catch(Exception ex){toast("공유 이미지를 준비하지 못했어요.");}
        }
    }
    private void deliverLockedCapture(final String path,final boolean restored){if(path==null)return;new Thread(()->{try{
        File dir=new File(getFilesDir(),"locked-ar").getCanonicalFile(),meta=new File(path).getCanonicalFile();if(!dir.equals(meta.getParentFile())||!meta.isFile()||meta.length()>150000)throw new Exception();
        org.json.JSONObject value=new org.json.JSONObject(new String(java.nio.file.Files.readAllBytes(meta.toPath()),"UTF-8"));String imageName=value.getString("imageFile");if(!imageName.matches("[A-Za-z0-9-]+\\.jpg"))throw new Exception();File image=new File(dir,imageName);if(!image.isFile()||image.length()>4500000)throw new Exception();
        value.put("restored",restored);value.put("image","data:image/jpeg;base64,"+Base64.encodeToString(java.nio.file.Files.readAllBytes(image.toPath()),Base64.NO_WRAP));value.remove("imageFile");String beforeName=value.optString("beforeFile");if(beforeName.matches("[A-Za-z0-9-]+\\.jpg")){File before=new File(dir,beforeName);if(before.isFile()&&before.length()<4500000)value.put("before","data:image/jpeg;base64,"+Base64.encodeToString(java.nio.file.Files.readAllBytes(before.toPath()),Base64.NO_WRAP));}value.remove("beforeFile");final String json=value.toString();
        runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())web.evaluateJavascript("(function(v){if(window.receiveLockedARResult)window.receiveLockedARResult(v);else window.pendingLockedARResult=v;})("+json+")",null);});
    }catch(Exception ex){toast("저장한 배치 사진을 읽지 못했어요.");}}).start();}
    private void toast(final String text){runOnUiThread(()->Toast.makeText(this,text,Toast.LENGTH_SHORT).show());}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==AR_MEASURE){if(result==RESULT_OK&&data!=null){try{String raw=data.getStringExtra("measurement");if(raw==null||raw.length()>2000)throw new Exception();org.json.JSONObject value=new org.json.JSONObject(raw);web.evaluateJavascript("(function(v){if(window.receiveARMeasurement)window.receiveARMeasurement(v);else window.pendingARMeasurement=v;})("+value.toString()+")",null);}catch(Exception ex){toast("측정 결과를 읽지 못했어요.");}}else web.evaluateJavascript("if(window.cancelARMeasurement)window.cancelARMeasurement()",null);return;}
        if(request==LOCKED_AR&&result==RESULT_OK&&data!=null){deliverLockedCapture(data.getStringExtra("capture"),false);return;}
        if(request==PICK_PHOTO&&fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);fileCallback=null;}
        if(request==SAVE_FILE){final byte[] bytes=pendingSave;pendingSave=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null&&bytes!=null){final Uri target=data.getData();new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(target)){if(out==null)throw new Exception();out.write(bytes);toast("파일을 저장했어요.");}catch(Exception ex){toast("파일 저장에 실패했어요.");}}).start();}}
    }
    /** 웹 화면에 먼저 뒤로가기를 맡기고(대화상자 닫기·이전 단계), 처리할 게 없으면 앱을 닫습니다. */
    private void handleBack(){
        web.evaluateJavascript("(function(){try{if(window.roomfitBack)return roomfitBack();var d=document.querySelector('dialog[open]');if(d){d.close();return true;}}catch(e){}return false;})()",value->{if(!"true".equals(value)){if(web.canGoBack())web.goBack();else finish();}});
    }
    @SuppressWarnings("deprecation")
    @Override public void onBackPressed(){handleBack();} // Android 12 이하
    @Override protected void onSaveInstanceState(Bundle state){web.saveState(state);super.onSaveInstanceState(state);}
    @Override protected void onDestroy(){if(fileCallback!=null)fileCallback.onReceiveValue(null);web.removeJavascriptInterface("RoomfitNative");web.destroy();super.onDestroy();}
}
