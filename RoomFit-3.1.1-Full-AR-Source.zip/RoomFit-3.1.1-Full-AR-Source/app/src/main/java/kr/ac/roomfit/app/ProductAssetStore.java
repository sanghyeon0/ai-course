package kr.ac.roomfit.app;
import android.content.Context;
import org.json.*;
import java.io.*;
final class ProductAssetStore {
 static final class Entry {final String key,label,type;final GlbAsset model;Entry(String k,String l,String t,GlbAsset m){key=k;label=l;type=t;model=m;}}
 private final Context context;private final JSONObject catalog;
 ProductAssetStore(Context c)throws Exception {context=c;catalog=new JSONObject(new String(read(c,"web/product-models.json",100000),"UTF-8"));}
 Entry load(String productId)throws Exception {if(!catalog.has(productId))return null;JSONObject spec=catalog.getJSONObject(productId);String key=spec.getString("asset");if(!key.matches("[a-z0-9-]{1,60}"))throw new Exception("model key");GlbAsset model=GlbAsset.parse(read(context,"web/product-models/"+key+".glb",GlbAsset.MAX_BYTES));JSONArray d=spec.getJSONArray("dimensionsCm");float[] size={model.width()*100,model.depth()*100,model.height()*100};for(int i=0;i<3;i++)if(Math.abs(size[i]-d.getDouble(i))>.15)throw new Exception("model dimension mismatch");return new Entry(key,spec.getString("label"),spec.getString("type"),model);}
 private static byte[] read(Context c,String path,int limit)throws Exception {try(InputStream in=c.getAssets().open(path);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] block=new byte[8192];for(int n;(n=in.read(block))>=0;){if(out.size()+n>limit)throw new Exception("asset size");out.write(block,0,n);}return out.toByteArray();}}
}
